@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
if not exist ".venv\Scripts\python.exe" (
  echo [FAIL] Run SETUP_WINDOWS.cmd first to install this version.
  pause
  exit /b 2
)
echo Close other hh agent windows before checking access.
".venv\Scripts\python.exe" -m app.cli check-access
set "HH_ACCESS_RESULT=%errorlevel%"
pause
exit /b %HH_ACCESS_RESULT%
