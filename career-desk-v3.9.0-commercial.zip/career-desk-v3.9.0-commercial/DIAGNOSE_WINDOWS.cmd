@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

if not exist ".venv\Scripts\python.exe" (
  echo [FAIL] The isolated environment is missing. Run SETUP_WINDOWS.cmd first.
  pause
  exit /b 2
)

".venv\Scripts\python.exe" -m app.cli diagnose --live
set EXIT_CODE=%ERRORLEVEL%
pause
exit /b %EXIT_CODE%

