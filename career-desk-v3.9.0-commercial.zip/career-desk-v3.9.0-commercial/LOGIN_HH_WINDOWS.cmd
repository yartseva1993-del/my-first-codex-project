@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

if not exist ".venv\Scripts\python.exe" (
  echo [FAIL] Run SETUP_WINDOWS.cmd first.
  pause
  exit /b 2
)

".venv\Scripts\python.exe" -m app.cli login
set EXIT_CODE=%ERRORLEVEL%
pause
exit /b %EXIT_CODE%

