@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

if not exist ".venv\Scripts\python.exe" (
  echo [FAIL] Run SETUP_WINDOWS.cmd first.
  pause
  exit /b 2
)

".venv\Scripts\python.exe" -m compileall -q app tests
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m unittest discover -v
if errorlevel 1 goto :fail
echo [PASS] All tests passed.
pause
exit /b 0

:fail
echo [FAIL] Tests failed. Do not submit applications.
pause
exit /b 2

