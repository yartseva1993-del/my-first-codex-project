@echo off
setlocal EnableExtensions
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"
chcp 65001 >nul

echo ========================================================================
echo Career Desk 3.9.0 - clean safe setup
echo ========================================================================

if not exist "%SCRIPT_DIR%requirements.txt" goto :incomplete_archive
if not exist "%SCRIPT_DIR%app\__main__.py" goto :incomplete_archive
if not exist "%SCRIPT_DIR%START_AGENT_WINDOWS.cmd" goto :incomplete_archive

where py >nul 2>nul
if errorlevel 1 (
  echo [FAIL] Python launcher was not found.
  echo Install Python 3.11 or newer from python.org and enable the py launcher.
  pause
  exit /b 2
)

py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo [FAIL] Python 3.11 or newer is required.
  pause
  exit /b 2
)

if not exist ".venv\Scripts\python.exe" (
  echo [INFO] Creating an isolated Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :fail
)

echo [INFO] Checking runtime dependencies...
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,playwright,psutil,httpx,pypdf,cryptography" >nul 2>nul
if errorlevel 1 (
  echo [INFO] Installing runtime dependencies...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --prefer-binary --retries 5 --timeout 120 -r "%SCRIPT_DIR%requirements.txt"
  if errorlevel 1 (
    ".venv\Scripts\python.exe" -c "import fastapi,uvicorn,playwright,psutil,httpx,pypdf,cryptography" >nul 2>nul
    if errorlevel 1 goto :fail
  )
)

echo [INFO] Checking Playwright Chromium...
".venv\Scripts\python.exe" -c "from app.diagnostics import _chromium_health; ok,_=_chromium_health(); raise SystemExit(0 if ok else 1)" >nul 2>nul
if errorlevel 1 (
  echo [INFO] Installing Playwright Chromium...
  ".venv\Scripts\python.exe" -m playwright install chromium
  if errorlevel 1 goto :fail
)

echo [INFO] Running the packaged smoke checks...
".venv\Scripts\python.exe" -m unittest discover -v
if errorlevel 1 goto :fail

if /I "%~1"=="--update-only" goto :update

echo [INFO] Starting guided safe setup...
".venv\Scripts\python.exe" -m app.cli setup
if errorlevel 1 goto :fail

echo.
echo [PASS] Setup completed. Starting Career Desk...
start "" "%~dp0START_AGENT_WINDOWS.cmd"
exit /b 0

:update
".venv\Scripts\python.exe" -m app.cli update
if errorlevel 1 goto :fail
echo [PASS] Update completed. Starting Career Desk...
start "" "%~dp0START_AGENT_WINDOWS.cmd"
exit /b 0

:fail
echo.
echo [FAIL] Safe setup stopped before the agent was allowed to run.
echo Run DIAGNOSE_WINDOWS.cmd after resolving the message above.
pause
exit /b 2

:incomplete_archive
echo.
echo [FAIL] The release folder is incomplete: required project files are missing.
echo Do not run SETUP_WINDOWS.cmd from inside the ZIP or copy this CMD alone.
echo Right-click the complete release ZIP, choose Extract All, then run SETUP_WINDOWS.cmd there.
pause
exit /b 2
