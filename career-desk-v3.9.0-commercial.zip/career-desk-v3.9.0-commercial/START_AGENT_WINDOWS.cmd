@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

if not exist ".venv\Scripts\python.exe" (
  echo [FAIL] The isolated environment is missing. Run SETUP_WINDOWS.cmd first.
  pause
  exit /b 2
)

".venv\Scripts\python.exe" -c "import fastapi,uvicorn,playwright,psutil" >nul 2>nul
if errorlevel 1 (
  echo [FAIL] Dependencies are incomplete. Run SETUP_WINDOWS.cmd again.
  pause
  exit /b 2
)

".venv\Scripts\python.exe" -m app.cli serve
set EXIT_CODE=%ERRORLEVEL%
if not "%EXIT_CODE%"=="0" pause
exit /b %EXIT_CODE%

