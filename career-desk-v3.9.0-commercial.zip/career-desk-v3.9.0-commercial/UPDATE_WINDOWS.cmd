@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call SETUP_WINDOWS.cmd --update-only
exit /b %ERRORLEVEL%
