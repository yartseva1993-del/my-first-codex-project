"""HH AI Recruiter v3: human-controlled vacancy scout and submitter."""

__version__ = "3.9.0"
