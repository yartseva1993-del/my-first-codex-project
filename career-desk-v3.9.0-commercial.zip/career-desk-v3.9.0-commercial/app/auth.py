from __future__ import annotations

from typing import Any

from .browser_submitter import is_hh_host
from .paths import BROWSER_PROFILE, ensure_directories
from .resume_refs import document_resume_refs, resume_ref


RESUMES_URL = "https://hh.ru/applicant/resumes"
LOGIN_URL_MARKERS = ("/account/login", "/account/signup")


class GuidedLoginError(RuntimeError):
    pass


def _resume_card_label(value: str) -> str:
    """Keep real resume titles, never the recommendations counter label."""
    label = " ".join(str(value or "").split())[:120]
    lowered = label.casefold()
    if not label or ("ваканс" in lowered and any(char.isdigit() for char in label)):
        return ""
    return label


def _launch_context(playwright: Any) -> Any:
    return playwright.chromium.launch_persistent_context(
        user_data_dir=str(BROWSER_PROFILE),
        headless=False,
        locale="ru-RU",
        viewport={"width": 1360, "height": 900},
    )


def _close_context(context: Any | None) -> None:
    if context is None:
        return
    try:
        context.close()
    except Exception:
        # Closing an already closed persistent context is intentionally harmless.
        pass


def _active_page(context: Any) -> Any:
    """Return a currently open page, preferring the newest hh.ru page."""
    pages = []
    for page in context.pages:
        try:
            if not page.is_closed():
                pages.append(page)
        except Exception:
            continue
    for page in reversed(pages):
        try:
            if is_hh_host(page.url):
                return page
        except Exception:
            continue
    return pages[-1] if pages else context.new_page()


def _open_resumes(context: Any) -> Any:
    page = _active_page(context)
    page.goto(RESUMES_URL, wait_until="domcontentloaded", timeout=60000)
    return page


def _target_was_closed(exc: BaseException) -> bool:
    message = f"{type(exc).__name__}: {exc}".casefold()
    return "targetclosed" in message or "page, context or browser has been closed" in message


def _login_is_confirmed(page: Any) -> bool:
    url = str(page.url or "")
    lower_url = url.casefold()
    return is_hh_host(url) and not any(marker in lower_url for marker in LOGIN_URL_MARKERS)


def guided_login_and_resume_selection(settings: dict[str, Any]) -> str:
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise GuidedLoginError("Playwright is not installed") from exc
    ensure_directories()
    print("A dedicated Chromium window will open. Log in to hh.ru manually.")
    print("The agent never asks for or stores your hh.ru password.")
    candidates: dict[str, str] = {}
    with sync_playwright() as playwright:
        context = None
        recovered = False

        def open_resumes_with_recovery() -> Any:
            nonlocal context, recovered
            try:
                return _open_resumes(context)
            except PlaywrightError as exc:
                if recovered or not _target_was_closed(exc):
                    raise
                recovered = True
                print("[INFO] The login tab was replaced or closed. Reopening the dedicated Chromium profile once...")
                _close_context(context)
                context = _launch_context(playwright)
                return _open_resumes(context)

        try:
            context = _launch_context(playwright)
            open_resumes_with_recovery()
            input("After login, keep this Chromium window open, return here and press Enter...")
            page = open_resumes_with_recovery()
            if not _login_is_confirmed(page):
                raise GuidedLoginError("hh.ru login was not confirmed; keep the dedicated Chromium window open and finish login")
            links = page.locator(
                'a[href*="/resume/"], a[href*="resume="], '
                '[data-resume-id], [data-resume-hash], [data-hh-resume-hash]'
            )
            for index in range(links.count()):
                item = links.nth(index)
                resume_id = ""
                for key in ("href", "data-resume-id", "data-resume-hash", "data-hh-resume-hash"):
                    resume_id = resume_ref(item.get_attribute(key) or "", str(page.url or RESUMES_URL))
                    if resume_id and not resume_id.isdecimal():
                        break
                if not resume_id or resume_id.isdecimal():
                    continue
                label = _resume_card_label(item.inner_text() or "")
                candidates.setdefault(resume_id, label)
            try:
                # New HH layouts can keep the public hash in page state while
                # rendering the resume card without a direct /resume/ anchor.
                for resume_id in document_resume_refs(page.content(), str(page.url or RESUMES_URL)):
                    candidates.setdefault(resume_id, resume_id)
            except Exception:
                pass
        except GuidedLoginError:
            raise
        except PlaywrightError as exc:
            raise GuidedLoginError(f"guided hh.ru login failed: {exc}") from exc
        finally:
            _close_context(context)
    if not candidates:
        print("No resume id was detected. Submission will remain blocked on forms with multiple resumes.")
        return ""
    if len(candidates) == 1:
        resume_id = next(iter(candidates))
        label = candidates[resume_id]
        print(f"Selected the only detected resume{': ' + label if label else '.'}")
        return resume_id
    print("Available resumes:")
    entries = list(candidates.items())
    for index, (_, label) in enumerate(entries, start=1):
        print(f"  {index}. {label or 'Резюме ' + str(index)}")
    raw = input("Choose resume number: ").strip()
    try:
        selected = entries[int(raw) - 1][0]
    except (ValueError, IndexError) as exc:
        raise GuidedLoginError("invalid resume selection") from exc
    return selected


def manual_search_access_check(settings: dict[str, Any]) -> None:
    """Open the real search page and wait for the user; never click its controls."""
    from .hh_web import search_page_url
    from .hh_api import HHApiError

    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise GuidedLoginError("Playwright is not installed; run SETUP_WINDOWS.cmd") from exc
    regions = sorted((item for item in settings["search"]["regions"] if item.get("enabled")), key=lambda item: int(item.get("priority", 0)), reverse=True)
    query = next((str(item).strip() for item in settings["search"]["queries"] if str(item).strip()), "")
    if not regions:
        raise GuidedLoginError("Enable a search region in settings first")
    try:
        target = search_page_url(query, str(regions[0].get("area_id") or ""), int(settings["search"]["days"]))
    except HHApiError as exc:
        raise GuidedLoginError(str(exc)) from exc
    ensure_directories()
    with sync_playwright() as playwright:
        context = None
        try:
            context = _launch_context(playwright)
            page = _active_page(context)
            try:
                page.goto(target, wait_until="domcontentloaded", timeout=60000)
            except PlaywrightError:
                print("The search page did not finish loading. Inspect the open browser window.")
            print("Inspect the hh.ru search page in this dedicated Chromium window.")
            print("Any login or visible access check must be completed manually.")
            input("When finished, return here and press Enter to close the window...")
        except PlaywrightError as exc:
            raise GuidedLoginError(f"Cannot open the dedicated profile ({type(exc).__name__}); close its other windows and retry") from exc
        finally:
            _close_context(context)
    print("Run DIAGNOSE_WINDOWS.cmd to verify access. Opening the window alone is not a PASS.")
