"""Explicitly confirmed groups: at most two independent browser sessions.

The coordinator holds the dedicated profile lease for the whole group. Workers
never open that profile; its state is copied in RAM, not saved to disk.
"""
import copy
import queue
import secrets
import threading
import time
from contextlib import contextmanager
from .browser_access import PROFILE_ACCESS
from .browser_submitter import BrowserSubmitter
from .db import StateError
from .hh_web import BrowserHHWebClient
from .licensing import require_license
from .paths import BROWSER_PROFILE


class IsolatedReader(BrowserHHWebClient):
    def __init__(self, storage):
        super().__init__();self.storage=storage
    def _ensure_page(self):
        if self._context is not None:
            try:
                pages=[page for page in self._context.pages if not page.is_closed()]
                self._page=pages[-1] if pages else self._context.new_page()
                return self._page
            except Exception:
                self.close()
        from playwright.sync_api import sync_playwright
        self._playwright=sync_playwright().start()
        browser=self._playwright.chromium.launch(headless=False)
        self._context=browser.new_context(storage_state=self.storage,locale='ru-RU',service_workers='block')
        self._context.route('**/*',self._read_only_route)
        self._page=self._context.new_page()
        return self._page


@contextmanager
def session_snapshot():
    from playwright.sync_api import sync_playwright
    with PROFILE_ACCESS.hold('групповая отправка подтверждённых откликов'):
        with sync_playwright() as p:
            context=p.chromium.launch_persistent_context(str(BROWSER_PROFILE),headless=False,locale='ru-RU',service_workers='block')
            try:storage=context.storage_state()
            finally:context.close()
        try:yield storage
        finally:storage.clear()


def worker_factory(db, settings, controller, storage, stop):
    state=copy.deepcopy(storage)
    worker=BrowserSubmitter(db,settings,controller,IsolatedReader(state))
    worker.isolated_state=state;worker.cancel_event=stop
    return worker


class BatchController:
    def __init__(self, db, settings, controller, *, session=session_snapshot, factory=worker_factory):
        self.db,self.settings,self.controller=db,settings,controller
        self.session,self.factory=session,factory
        self.lock=threading.RLock();self.stop_event=threading.Event();self.thread=None
        self.data={'running':False,'items':[]};self.start_interval=3

    def preview(self, items):
        if not isinstance(items,list) or not 1 <= len(items) <= 20:
            raise StateError('Выберите от 1 до 20 одобренных вакансий.')
        if any(not isinstance(x,dict) for x in items):raise StateError('Некорректная группа.')
        ids=[str(x.get('id','')) for x in items]
        if len(set(ids))!=len(ids):raise StateError('В группе повторяются вакансии.')
        result=[]
        for item in items:
            row=self.db.get_submission_snapshot(str(item.get('id','')))
            if not row or not item.get('letter_sha256') or not item.get('content_hash'):
                raise StateError('Обновите выбранные карточки.')
            if (row['content_hash']!=item['content_hash'] or row['current_hash']!=item['letter_sha256']
                or row['approved_hash']!=row['current_hash'] or not row['vacancy_approved_at'] or not row['letter_approved_at']):
                raise StateError('Вакансия или письмо изменились. Одобрите актуальную версию.')
            result.append({'id':str(item['id']),'content_hash':row['content_hash'],'letter_sha256':row['current_hash'],
                           'title':row['name'],'letter':row['letter_text']})
        return result

    def start(self, items, workers=2):
        require_license()
        with self.lock:
            if self.data['running'] or PROFILE_ACCESS.status()['busy']:raise StateError('Браузер или группа заняты.')
            if type(workers) is not int or workers not in (1,2):raise StateError('Разрешены 1 или 2 окна.')
            prepared=self.preview(items)
            if not self.settings['submit'].get('resume_id'):raise StateError('Выберите резюме hh.ru.')
            for item in prepared:item['attempt_id']=secrets.token_hex(16)
            snapshots=self.db.prepare_batch(prepared,int(self.settings['submit']['daily_limit']))
            self.stop_event.clear()
            self.data={'running':True,'workers':workers,'error':'','items':[{'id':x['id'],'attempt_id':x['attempt_id']} for x in prepared]}
            jobs=list(zip(prepared,snapshots));resume_id=str(self.settings['submit']['resume_id'])
            self.thread=threading.Thread(target=self._run,args=(jobs,workers,resume_id),daemon=True,name='confirmed-batch')
            self.thread.start()
            return self.status()

    def _run(self, jobs, workers, resume_id):
        pending=queue.Queue()
        for item in jobs:pending.put(item)
        deadline=time.monotonic()+900
        def run(storage):
            while not self.stop_event.is_set():
                try:item,snapshot=pending.get_nowait()
                except queue.Empty:return
                try:
                    if self.stop_event.is_set():raise StateError('Группа остановлена.')
                    if time.monotonic()>deadline:raise StateError('Истекло 15 минут подтверждения группы.')
                    if self.settings['submit'].get('resume_id')!=resume_id:raise StateError('Выбранное резюме изменилось.')
                    require_license()
                    permit=self.controller.vault.issue(item['attempt_id'],item['id'],snapshot['approved_hash'],
                        snapshot['vacancy_approval_version'],snapshot['letter_approval_version'],
                        int(self.settings['submit']['permit_ttl_seconds']),resume_id)
                    worker=self.factory(self.db,self.settings,self.controller,storage,self.stop_event)
                    worker(permit)
                    if (self.db.submission_status(item['id']) or {}).get('state')!='confirmed':
                        self.stop_event.set()
                except Exception:
                    state=(self.db.submission_status(item['id']) or {}).get('state')
                    if state in {'queued','running'}:
                        self.db.set_submission_state(item['attempt_id'],'unknown' if state=='running' else 'cancelled',error='Обработка группы остановлена. Проверьте состояние отклика.')
                    self.stop_event.set()
                finally:pending.task_done()
        try:
            with self.session() as storage:
                threads=[]
                for _ in range(workers):
                    if self.stop_event.is_set():break
                    t=threading.Thread(target=run,args=(storage,),daemon=True);threads.append(t);t.start()
                    if workers>1:self.stop_event.wait(self.start_interval)
                for t in threads:t.join()
        except Exception:
            with self.lock:self.data['error']='Не удалось открыть рабочую сессию. Проверьте вход через LOGIN_HH_WINDOWS.cmd.'
            self.stop_event.set()
        finally:
            while not pending.empty():
                item,_=pending.get_nowait()
                self.db.set_submission_state(item['attempt_id'],'cancelled',error='Группа остановлена до запуска этого отклика.')
                pending.task_done()
            with self.lock:self.data['running']=False

    def stop(self):self.stop_event.set()

    def status(self):
        with self.lock:
            result=copy.deepcopy(self.data)
        result['stopping']=bool(result['running'] and self.stop_event.is_set())
        for item in result['items']:item['state']=(self.db.submission_status(item['id']) or {}).get('state')
        return result
