"""Serialize access to the dedicated profile, including nested live reads.

The lock is held only while a browser is open, never during local AI work.
It is not a submission permission: the submitter still needs its one-shot permit.
"""
from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import Iterator


class BrowserBusyError(RuntimeError):
    pass


class BrowserAccess:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._state_lock = threading.Lock()
        self._depth = 0
        self._activity = ""

    def acquire(self, activity: str) -> None:
        if not self._lock.acquire(blocking=False):
            raise BrowserBusyError("Браузер занят: " + self.status()["activity"] + ". Дождитесь освобождения и повторите действие.")
        with self._state_lock:
            if not self._depth:
                self._activity = activity
            self._depth += 1

    def release(self) -> None:
        with self._state_lock:
            self._depth -= 1
            if not self._depth:
                self._activity = ""
            self._lock.release()

    @contextmanager
    def hold(self, activity: str) -> Iterator[None]:
        self.acquire(activity)
        try:
            yield
        finally:
            self.release()

    def status(self) -> dict:
        with self._state_lock:
            return {"busy": self._depth > 0, "activity": self._activity}


PROFILE_ACCESS = BrowserAccess()
