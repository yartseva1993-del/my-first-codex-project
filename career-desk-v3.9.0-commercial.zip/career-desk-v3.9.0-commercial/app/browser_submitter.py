from __future__ import annotations

import json
import logging
import time
import re
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .db import Database, StateError, letter_hash, manual_override_active, vacancy_actions_allowed, vacancy_content_hash
from .browser_access import BrowserBusyError, PROFILE_ACCESS
from .hh_api import HHApiClient, HHApiError, HybridHHClient
from .letters import LetterPolicyError, validate_cover_letter
from .paths import BROWSER_PROFILE, DIAGNOSTICS_DIR, ensure_directories
from .policy import live_profession_guard
from .resume_refs import document_resume_refs, resume_ref
from .submission import SubmissionController, SubmissionPermit


LOGGER = logging.getLogger(__name__)

# Read-only DOM inspection. Never copy values, HTML, resume links or page text
# into a diagnostic report. Labels are used only to identify this control.
CONTROL_INFO_JS = r"""el => {
    const clean = value => (value || '').replace(/\s+/g, ' ').trim();
    const isLetter = text => /^(?:сопроводительное(?: письмо)?|cover letter)\s*[:*]?$/i.test(clean(text));
    const response = el.closest('[data-qa*="vacancy-response"]');
    const letterParent = el.closest('[data-qa*="vacancy-response"][data-qa*="letter"]');
    let letterSection = !!letterParent;
    for (let parent = el.parentElement, depth = 0; parent && depth < 4; parent = parent.parentElement, depth++) {
        if (parent.matches('form, main, body, [role="dialog"]')) break;
        const captions = [...parent.querySelectorAll('label, legend, h2, h3, h4, p, span, div, [data-qa*="title"]')];
        if (captions.some(caption => isLetter(caption.textContent)) &&
            parent.querySelectorAll('textarea, [contenteditable="true"]').length <= 1) {
            letterSection = true;
            break;
        }
    }
    const labels = [...(el.labels || [])].map(label => clean(label.textContent));
    for (const id of (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean)) {
        const label = el.ownerDocument.getElementById(id);
        if (label) labels.push(clean(label.textContent));
    }
    const control = el.tagName === 'LABEL' ? el.control : null;
    return {
        tag: el.tagName.toLowerCase(), kind: el.type || '', role: el.getAttribute('role') || '',
        name: el.getAttribute('name') || '', qa: el.getAttribute('data-qa') || '',
        aria: clean(el.getAttribute('aria-label')), labels,
        placeholder: clean(el.getAttribute('placeholder')),
        text: ['BUTTON', 'A', 'SUMMARY', 'LABEL'].includes(el.tagName) || el.getAttribute('role') === 'button' ? clean(el.textContent) : '',
        editable: !!el.isContentEditable, readonly: !!el.readOnly,
        response: !!response, letterSection,
        question: !!el.closest('[data-qa*="question"], [data-qa*="test-answer"]'),
        chat: !!el.closest('[data-qa*="chat"], [data-qa*="messenger"]'),
        form: !!el.form, formAction: el.form ? el.form.getAttribute('action') || '' : '',
        href: el.getAttribute('href') || '', expanded: el.getAttribute('aria-expanded'),
        detailsOpen: el.tagName === 'SUMMARY' && !!el.parentElement.open,
        controlKind: control ? control.type : '', controlChecked: !!(control && control.checked),
        controlDisabled: !!(control && control.disabled)
    };
}"""


def _normalized_label(value: str) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip().lower().lstrip('+ ').rstrip(':* ')


def _is_cover_control(info: dict[str, Any], response_page: bool) -> bool:
    if info.get('tag') != 'textarea' and not info.get('editable'):
        return False
    if info.get('question') or info.get('chat'):
        return False
    qa = str(info.get('qa') or '').lower()
    labels = [info.get('aria'), info.get('placeholder'), *info.get('labels', [])]
    labelled = any(re.match(r'^(?:сопроводительн\w*(?: письмо)?|cover letter)(?:\b|\s)', _normalized_label(label)) for label in labels)
    known_qa = qa.startswith('vacancy-response-') and 'letter' in qa.split('-')
    in_response = response_page or info.get('response') or '/applicant/vacancy_response' in str(info.get('formAction') or '')
    named = str(info.get('name') or '').lower() in {'message', 'letter', 'coverletter', 'cover_letter'}
    return bool(known_qa or labelled or info.get('letterSection') or (named and in_response))


def _is_letter_opener(info: dict[str, Any]) -> bool:
    if info.get('question') or info.get('chat') or info.get('expanded') == 'true' or info.get('detailsOpen'):
        return False
    names = {_normalized_label(info.get('text')), _normalized_label(info.get('aria'))}
    qa_tokens = str(info.get('qa') or '').lower().split('-')
    known_toggle = qa_tokens[:2] == ['vacancy', 'response'] and {'letter', 'toggle'} <= set(qa_tokens)
    explicit = any(re.fullmatch(r'(?:добавить|написать|приложить) сопроводительное(?: письмо)?|(?:add|write) (?:a )?cover letter', name) for name in names)
    contextual = bool(info.get('letterSection')) and bool(names & {'добавить', 'написать', 'add', 'write'})
    disclosure = bool(names & {'сопроводительное письмо', 'сопроводительное', 'cover letter'})
    if not (known_toggle or explicit or contextual or disclosure):
        return False
    tag = info.get('tag')
    if tag == 'button':
        # A button without a type submits its parent form by default.
        return not info.get('form') or info.get('kind') == 'button'
    if tag == 'a':
        return str(info.get('href') or '') in {'', '#'}
    if tag == 'summary':
        return True
    if tag == 'label':
        return info.get('controlKind') == 'checkbox' and not info.get('controlChecked') and not info.get('controlDisabled')
    return info.get('role') == 'button' and tag not in {'input', 'textarea'}


def _url_vacancy_ids(url: str) -> set[str]:
    """Return only exact vacancy identifiers carried by a trusted URL shape."""
    try:
        parsed = urllib.parse.urlsplit(url)
    except ValueError:
        return set()
    ids = {value for name, value in urllib.parse.parse_qsl(parsed.query) if name.lower() in {'vacancyid', 'vacancy_id'}}
    match = re.fullmatch(r'/vacancy/(\d+)/?', parsed.path)
    if match:
        ids.add(match.group(1))
    return ids


def _is_response_entry_action(info: dict[str, Any], page_url: str, vacancy_id: str) -> bool:
    """Recognize HH's explicit response entry point on the exact vacancy card.

    This action is never used without the write-request barrier below: HH may
    otherwise interpret it as an immediate application when a letter is
    optional.
    """
    if _url_vacancy_ids(page_url) != {str(vacancy_id)}:
        return False
    parsed = urllib.parse.urlsplit(page_url)
    if not re.fullmatch(r'/vacancy/\d+/?', parsed.path):
        return False
    if str(info.get('qa') or '') not in {'vacancy-response-link-top', 'vacancy-response-link-bottom'}:
        return False
    if info.get('tag') not in {'a', 'button'} and info.get('role') != 'button':
        return False
    names = {_normalized_label(info.get('text')), _normalized_label(info.get('aria'))}
    if 'откликнуться' not in names:
        return False
    href = str(info.get('href') or '').strip()
    if href and href != '#':
        absolute = urllib.parse.urljoin(page_url, href)
        if not is_hh_host(absolute) or _url_vacancy_ids(absolute) != {str(vacancy_id)}:
            return False
    return True


def is_hh_host(url: str) -> bool:
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
        if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in {None, 443}:
            return False
    except ValueError:
        return False
    return host == "hh.ru" or host.endswith(".hh.ru")


def _safe_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    path = re.sub(r'/resume/[^/]+', '/resume/redacted', parsed.path)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.hostname or '', path, "", ""))


def _scrub_path(path: str) -> str:
    """Sanitized request path for diagnostics: no ids, no query, no host."""
    path = re.sub(r'/resume/[^/]+', '/resume/<id>', path)
    path = re.sub(r'[0-9a-f]{8,}', '<id>', path, flags=re.IGNORECASE)
    return re.sub(r'\d{4,}', '<id>', path)[:120]


def _is_true(value: Any) -> bool:
    return value is True or str(value).strip().lower() in {"1", "true", "yes"}


@dataclass
class FormReport:
    vacancy_id: str
    url: str = ""
    cover_candidates: int = 0
    cover_hidden: int = 0
    cover_expanders: int = 0
    cover_expansions: int = 0
    response_actions: int = 0
    response_action_duplicates: int = 0
    response_action_clicks: int = 0
    blocked_writes: int = 0
    write_requests: list[dict[str, Any]] = field(default_factory=list)
    delivery_verified: bool = False
    delivery_blocked: bool = False
    delivery_reason: str = ""
    delivery_http_status: int = 0
    recoveries: int = 0
    live_recheck_retries: int = 0
    stage: str = "starting"
    http_status: int = 0
    controls: list[dict[str, Any]] = field(default_factory=list)
    required_unanswered: int = 0
    owned_resumes: int = 0
    resume_owned: bool = False
    resume_options: int = 0
    resume_proof: str = ""
    submit_buttons: int = 0
    submit_match: str = ""
    employer_questions: int = 0
    success_markers: int = 0
    clicked: bool = False
    error_kind: str = ""
    error_status: int = 0
    outcome: str = ""

    def save(self, attempt_id: str) -> None:
        ensure_directories()
        path = DIAGNOSTICS_DIR / f"form-{attempt_id}.json"
        path.write_text(json.dumps(self.__dict__, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class _ExistingResponseDetected(StateError):
    """HH changed to an already-responded view before letter preparation."""


class _WriteRequestBarrier:
    """Guard application writes and verify a single approved delivery payload.

    HH form-loading POSTs are allowed only at explicit observed paths. Their
    success alone never counts as application or letter delivery. This adapter
    does not manufacture requests or retry an application after a click.
    """

    SAFE_METHODS = {'GET', 'HEAD', 'OPTIONS'}
    FORM_PATHS = {
        '/applicant/vacancy_response/popup', '/applicant/vacancy_response/form',
        '/applicant/vacancy_response/validate', '/shards/vacancy/response_popup',
    }
    BLOCKED_SAMPLE_LIMIT = 40

    def __init__(self, context: Any, report: FormReport):
        self.context = context
        self.report = report
        self.active = False
        self._handler = self._handle
        self.armed = False
        self.sent_request = None
        self.accepted = False
        self.expected_letter = ''
        self.expected_resume = '' 

    @classmethod
    def _is_submission_request(cls, url: str) -> bool:
        path = urllib.parse.unquote(urllib.parse.urlsplit(url).path).casefold().rstrip('/')
        if path in cls.FORM_PATHS:
            return False
        return bool(re.search(r'(vacancy[_/-]response|negotiations|applicant/response|response/submit)', path))

    @staticmethod
    def _fields(request: Any) -> dict[str, list[str]]:
        from email.parser import BytesParser
        from email.policy import default
        fields: dict[str, list[str]] = {}
        def add(key: str, value: Any) -> None:
            key = re.sub(r'[^a-z]', '', str(key).casefold())
            fields.setdefault(key, []).append(str(value))
        def walk(obj: Any) -> None:
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if isinstance(value, (dict, list)): walk(value)
                    elif value is not None: add(key, value)
            elif isinstance(obj, list):
                for item in obj: walk(item)
        for key, value in urllib.parse.parse_qsl(urllib.parse.urlsplit(request.url).query, keep_blank_values=True):
            add(key, value)
        data = request.post_data or ''
        content_type = request.headers.get('content-type', '')
        if 'json' in content_type:
            walk(json.loads(data))
        elif 'multipart/form-data' in content_type:
            raw = b'Content-Type: ' + content_type.encode() + b'\r\nMIME-Version: 1.0\r\n\r\n' + (request.post_data_buffer or b'')
            for part in BytesParser(policy=default).parsebytes(raw).iter_parts():
                name = part.get_param('name', header='content-disposition')
                if name and part.get_filename() is None:
                    add(name, (part.get_payload(decode=True) or b'').decode(part.get_content_charset() or 'utf-8'))
        else:
            for key, value in urllib.parse.parse_qsl(data, keep_blank_values=True): add(key, value)
        return fields

    def _matches(self, request: Any) -> tuple[bool, str]:
        try:
            fields = self._fields(request)
        except (ValueError, TypeError, UnicodeError):
            return False, 'unreadable_payload'
        def values(keys: set[str]) -> list[str]:
            return [value for key in keys for value in fields.get(key, [])]
        letters = values({'message', 'letter', 'coverletter', 'lettertext'})
        # Browser form encoding uses CRLF; compare the logical approved text.
        normalize = lambda text: text.replace('\r\n', '\n').replace('\r', '\n')
        if not letters or any(normalize(text) != normalize(self.expected_letter) for text in letters):
            return False, 'approved_letter_missing_or_changed'
        ids = values({'vacancyid'})
        if not ids or set(ids) != {str(self.report.vacancy_id)}:
            return False, 'vacancy_payload_mismatch'
        resumes = values({'resumeid', 'resumehash', 'resume'})
        if not resumes or {resume_ref(value) for value in resumes} != {resume_ref(self.expected_resume)}:
            return False, 'resume_payload_mismatch'
        return True, 'exact_payload'

    def arm(self, letter: str, resume: str) -> None:
        if not self.active:
            raise StateError('Проверка исходящего письма недоступна. Отправки не было.')
        self.expected_letter, self.expected_resume = letter, resume
        self.armed = True
        self.context.on('response', self._response)

    def _response(self, response: Any) -> None:
        if response.request != self.sent_request:
            return
        self.report.delivery_http_status = response.status
        # HTTP 2xx may contain application validation errors; DOM confirmation
        # is also required upstream. Do not treat redirects or timeouts as success.
        if 200 <= response.status < 300:
            try:
                if 'json' in response.headers.get('content-type', ''):
                    data = response.json()
                    if isinstance(data, dict) and (data.get('errors') or data.get('error') or data.get('success') is False or data.get('ok') is False):
                        self.report.delivery_reason = 'hh_rejected_payload'
                        return
            except (ValueError, TypeError):
                self.report.delivery_reason = 'unreadable_confirmation'
                return
            self.accepted = True
            self.report.delivery_verified = True

    def _handle(self, route: Any) -> None:
        request = route.request
        method = str(request.method or '').upper()
        url = str(request.url or '')
        path = urllib.parse.urlsplit(url).path.casefold().rstrip('/')
        candidate = self._is_submission_request(url)
        # After the final click, popup endpoints must meet the same exact
        # payload requirement; a before-form popup is only a rendering request.
        if self.armed and path in self.FORM_PATHS and method not in self.SAFE_METHODS:
            candidate = True
        # GraphQL mutations are not documented by this adapter. Queries may load UI.
        graphql_mutation = 'graphql' in path and 'mutation' in str(request.post_data or '').casefold()
        if graphql_mutation:
            candidate = True
        if not candidate:
            if method not in self.SAFE_METHODS:
                self._record(method, url, allowed=True)
            route.fallback()
            return
        # GET navigation to a response page is read-only. Delivery requires POST.
        if method in self.SAFE_METHODS:
            route.fallback()
            return
        valid, reason = self._matches(request) if self.armed else (False, 'before_final_click')
        if valid and is_hh_host(url) and method == 'POST' and self.sent_request is None:
            self.sent_request = request
            self.report.delivery_reason = reason
            self._record(method, url, allowed=True)
            route.fallback()
            return
        self.report.blocked_writes += 1
        if self.armed:
            self.report.delivery_blocked = True
            self.report.delivery_reason = 'duplicate_request_blocked' if self.sent_request else reason
        self._record(method, url, allowed=False)
        route.abort(error_code='blockedbyclient')

    def _record(self, method: str, url: str, *, allowed: bool) -> None:
        if len(self.report.write_requests) >= self.BLOCKED_SAMPLE_LIMIT:
            if allowed and not self._is_submission_request(url):
                return
            self.report.write_requests.pop(0)
        path = urllib.parse.urlsplit(url).path
        self.report.write_requests.append({
            'method': method[:10],
            'path': _scrub_path(path),
            'allowed': allowed,
        })

    def install(self) -> None:
        if not self.active:
            self.context.route('**/*', self._handler)
            self.active = True

    def disable(self) -> None:
        if self.active:
            # A failure to remove the barrier must stop the final click. It is
            # safer to leave the application unsent than to guess route state.
            self.context.unroute('**/*', self._handler)
            self.active = False


class _TargetClosedBeforeSubmit(RuntimeError):
    """Internal signal that permits one fresh pre-click browser attempt."""


class BrowserSubmitter:
    """The only runtime component allowed to perform the physical submit click."""

    FORM_WAIT_SECONDS = 18.0
    TEXT_CONTROLS = 'textarea, [contenteditable="true"]'
    SUBMIT_SELECTORS = (
        'button[data-qa*="vacancy-response-submit"]',
        '[role="button"][data-qa*="vacancy-response-submit"]',
        'input[type="submit"][data-qa*="vacancy-response-submit"]',
        'button[data-qa="vacancy-response-submit-popup"]',
        '[role="button"][data-qa="vacancy-response-submit-popup"]',
        'input[type="submit"][data-qa="vacancy-response-submit-popup"]',
        'button[data-qa="vacancy-response-submit"]',
        '[role="button"][data-qa="vacancy-response-submit"]',
        'input[type="submit"][data-qa="vacancy-response-submit"]',
        'button:text-is("Отправить отклик")',
        'button[type="submit"]:text-is("Отправить")',
        'button:text-is("Откликнуться")',
    )
    # Visible captions of the real submit control, checked when the data-qa
    # selectors above find nothing. On 04.09 hh.ru served a response form
    # where every button's data-qa had been renamed, so the qa-based
    # selectors matched zero elements while the form was fully loaded and
    # the letter was in place. A button's visible caption survives a
    # design-system rename; its data-qa does not.
    SUBMIT_LABELS = (
        "отправить отклик",
        "откликнуться",
        "отправить",
        "подтвердить отклик",
    )
    # Captions that must never be treated as the submit control even when
    # they contain a submit word. Matched on the full caption, so a
    # "Отправить" button is unaffected.
    SUBMIT_LABEL_BLOCKLIST = (
        "отправить сообщение",
        "отправить резюме на почту",
        "написать сообщение",
        "отменить",
        "закрыть",
        "назад",
        "редактировать",
        "изменить резюме",
        "добавить сопроводительное",
        "сопроводительное письмо",
        "показать контакты",
        "пожаловаться",
    )
    CAPTCHA_MARKERS = ("captcha", "капча", "подтвердите что вы не робот", "я не робот")
    LOGIN_MARKERS = ("/account/login", "/account/signup")
    SUCCESS_MARKERS = ("отклик отправлен", "вы откликнулись", "резюме отправлено")
    SUCCESS_SELECTORS = (
        '[data-qa="vacancy-response-success"]',
        '[data-qa="vacancy-response-link-view-topic"]',
    )
    ALREADY_MARKERS = ("вы уже откликались", "уже есть отклик")
    RESUMES_URL = "https://hh.ru/applicant/resumes"

    def __init__(
        self,
        db: Database,
        settings: dict[str, Any],
        controller: SubmissionController,
        hh: HHApiClient | HybridHHClient | None = None,
    ):
        self.db = db
        self.settings = settings
        self.controller = controller
        self.hh = hh or HybridHHClient()
        self.isolated_state = None
        self.cancel_event = None

    def __call__(self, permit: SubmissionPermit) -> None:
        report = FormReport(permit.vacancy_id)
        clicked = False
        acquired = False
        try:
            self.controller.consume_for_submitter(permit)
            if self.isolated_state is None:
                PROFILE_ACCESS.acquire("ручная отправка отклика")
                acquired = True
            self.db.set_submission_state(permit.attempt_id, "running")
            snapshot = self.db.get_submission_snapshot(permit.vacancy_id)
            self._verify_snapshot(snapshot, permit)
            snapshot["_resume_id_at_confirmation"] = permit.resume_id
            snapshot["_permit_expires_at"] = permit.expires_at
            report.stage = "live_recheck"
            live = self._read_live_vacancy(
                permit.vacancy_id,
                snapshot["raw"].get("_source"),
                report,
            )
            if _is_true(live.get("archived")):
                raise StateError("Вакансия уже закрыта или перенесена в архив. Отправки не было.")
            if _is_true(live.get("has_test")):
                raise StateError("vacancy requires a test; the agent will not answer or bypass it")
            if vacancy_content_hash(live) != str(snapshot.get("content_hash") or ""):
                raise StateError("live vacancy changed after approval; run Scout and approve the updated vacancy again")
            guard = live_profession_guard(live, self.settings)
            if (guard.profession_decision != "ALLOW" or guard.decision == "BLOCK") and not manual_override_active(snapshot):
                raise StateError("live profession guard blocked the vacancy: " + "; ".join(guard.reasons))
            # Always enter through the exact live vacancy card. A legacy deep
            # response URL can omit the resume picker and the final button.
            # The card action is opened later behind the write barrier.
            target_url = str(live.get("alternate_url") or f"https://hh.ru/vacancy/{permit.vacancy_id}")
            if not self._is_vacancy_card(target_url, permit.vacancy_id):
                target_url = f"https://hh.ru/vacancy/{permit.vacancy_id}"
            outcome, clicked = self._browser_submit(target_url, snapshot, report)
            report.clicked = clicked
            report.outcome = outcome
            if outcome == "confirmed":
                self.db.set_submission_state(permit.attempt_id, "confirmed", result=outcome)
            elif outcome == "already_applied":
                self.db.set_submission_state(permit.attempt_id, "unknown", result=outcome,
                    error="На этой вакансии уже есть отклик. Текущее письмо не отправлялось. Проверьте переписку на hh.ru.")
            elif clicked:
                self.db.set_submission_state(permit.attempt_id, "unknown", result=outcome, error="Клик выполнен, но получение отклика с точным письмом не подтверждено. Проверьте переписку на hh.ru перед дальнейшими действиями.")
            else:
                self.db.set_submission_state(permit.attempt_id, "blocked", result=outcome)
        except _ExistingResponseDetected as exc:
            self.db.set_submission_state(permit.attempt_id, "unknown", result="already_applied", error=str(exc))
            report.outcome = "already_applied"
        except (StateError, BrowserBusyError) as exc:
            clicked = clicked or report.clicked
            LOGGER.warning("Submission blocked for %s: %s", permit.vacancy_id, exc)
            try:
                self.db.set_submission_state(permit.attempt_id, "unknown" if clicked else "blocked", error=str(exc))
            except StateError:
                pass
            report.outcome = str(exc)
        except HHApiError as exc:
            clicked = clicked or report.clicked
            report.error_kind = str(exc.kind or "http")[:40]
            report.error_status = int(exc.status_code or 0)
            LOGGER.warning(
                "Submission live recheck blocked for %s: kind=%s status=%s reason=%s",
                permit.vacancy_id, report.error_kind, report.error_status, exc,
            )
            if exc.status_code in {404, 410}:
                error = "Вакансия больше недоступна на hh.ru (закрыта или удалена). Отправки не было."
                state = "unknown" if clicked else "blocked"
            else:
                error = f"Живая проверка вакансии не завершена: {exc}. Отправки не было; повторите после проверки hh.ru."
                state = "unknown" if clicked else "failed"
            try:
                self.db.set_submission_state(permit.attempt_id, state, error=error)
            except StateError:
                pass
            report.outcome = error
        except Exception as exc:
            clicked = clicked or report.clicked
            LOGGER.error("Submission attempt failed for %s (%s)", permit.vacancy_id, type(exc).__name__)
            error = f"Не удалось завершить проверку формы ({type(exc).__name__}). Проверьте hh.ru и сведения о форме в диагностике."
            try:
                self.db.set_submission_state(permit.attempt_id, "unknown" if clicked else "failed", error=error)
            except StateError:
                pass
            report.outcome = error
        finally:
            if acquired:
                PROFILE_ACCESS.release()
            report.clicked = report.clicked or clicked
            try:
                report.save(permit.attempt_id)
            except OSError:
                LOGGER.exception("Could not save sanitized form report")

    def _read_live_vacancy(
        self,
        vacancy_id: str,
        source: str | None,
        report: FormReport | None = None,
    ) -> dict[str, Any]:
        """Read the live card and retry one transient pre-click navigation.

        The retry happens before the response form is opened and before any
        physical submit click.  A real redirect away from HH, CAPTCHA, rate
        limit, 404/410 or another policy error is never retried here.
        """
        for attempt in range(2):
            try:
                if isinstance(self.hh, HybridHHClient):
                    return self.hh.vacancy(vacancy_id, source=source)
                return self.hh.vacancy(vacancy_id)
            except HHApiError as exc:
                if attempt or not self._retryable_live_read_error(exc):
                    raise
                if report is not None:
                    report.live_recheck_retries += 1
                LOGGER.warning(
                    "Transient live vacancy navigation failed before form entry; "
                    "reopening the dedicated profile once"
                )
            finally:
                close = getattr(self.hh, "close", None)
                if callable(close):
                    close()
        raise HHApiError("Живая проверка вакансии не завершена", kind="browser")

    @staticmethod
    def _retryable_live_read_error(exc: HHApiError) -> bool:
        message = str(exc).casefold()
        if "targetclosederror" in message or "has been closed" in message:
            return True
        if exc.kind == "network":
            return True
        # ``chrome-error://chromewebdata/`` is Chromium's internal failed
        # navigation page.  The 05.09 diagnostics showed it once, followed by
        # a successful HH vacancy health check thirty seconds later.  Retrying
        # this exact internal page once is safe because no form has been
        # opened and no write request is possible at this stage.
        return exc.kind == "access" and any(
            marker in message
            for marker in (
                "chrome-error://chromewebdata/",
                "chrome-error://chromewebdata",
                "about:blank",
                "фактический адрес: (адрес пуст)",
            )
        )

    def _verify_snapshot(self, snapshot: dict[str, Any], permit: SubmissionPermit) -> None:
        if str(self.settings["submit"].get("resume_id") or "") != permit.resume_id:
            raise StateError("Выбранное резюме изменилось после подтверждения. Подтвердите отклик заново.")
        if str(snapshot["id"]) != permit.vacancy_id:
            raise StateError("vacancy id changed")
        if not vacancy_actions_allowed(snapshot):
            raise StateError("database policy no longer permits submission")
        text = str(snapshot.get("letter_text") or "")
        if not snapshot.get("letter_approved_at") or snapshot.get("approved_hash") != permit.letter_hash:
            raise StateError("approved letter snapshot does not match permit")
        if snapshot.get("current_hash") != permit.letter_hash or letter_hash(text) != permit.letter_hash:
            raise StateError("cover letter changed after final approval")
        if int(snapshot.get("vacancy_approval_version") or 0) != permit.vacancy_approval_version:
            raise StateError("vacancy approval version changed after final click")
        if int(snapshot.get("letter_approval_version") or 0) != permit.letter_approval_version:
            raise StateError("letter approval version changed after final click")
        if not 80 <= len(text.strip()) <= 4000:
            raise StateError("cover letter length is unsafe")
        try:
            validate_cover_letter(text, self.settings)
        except LetterPolicyError as exc:
            raise StateError(str(exc)) from exc

    def _browser_submit(self, target_url: str, snapshot: dict[str, Any], report: FormReport) -> tuple[str, bool]:
        while True:
            try:
                return self._browser_submit_attempt(target_url, snapshot, report)
            except Exception as exc:
                still_valid = time.monotonic() < float(snapshot.get('_permit_expires_at') or 0) - 3
                if not report.clicked and report.recoveries == 0 and still_valid and self._is_target_closed_error(exc):
                    report.recoveries += 1
                    report.stage = 'recovering_closed_browser'
                    LOGGER.warning('Submission page closed before the physical click; reopening the dedicated profile once')
                    continue
                raise

    def _launch_context(self, playwright):
        options = dict(headless=False)
        if self.isolated_state is not None:
            browser = playwright.chromium.launch(**options)
            return browser.new_context(storage_state=self.isolated_state, locale='ru-RU',
                viewport={'width':1360,'height':900}, service_workers='block')
        return playwright.chromium.launch_persistent_context(user_data_dir=str(BROWSER_PROFILE),
            **options, locale='ru-RU', viewport={'width':1360,'height':900}, service_workers='block')

    def _browser_submit_attempt(self, target_url: str, snapshot: dict[str, Any], report: FormReport) -> tuple[str, bool]:
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise RuntimeError("Playwright is not installed") from exc

        clicked = False
        try:
            with sync_playwright() as playwright:
                context = self._launch_context(playwright)
                page = None
                barrier: _WriteRequestBarrier | None = None
                try:
                    page = self._single_hh_page(context)
                    self._confirm_resume_ownership(page, snapshot["_resume_id_at_confirmation"], report)
                    report.stage = 'opening'
                    barrier = _WriteRequestBarrier(context, report)
                    barrier.install()
                    response = page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
                    if response is not None and isinstance(response.status, int):
                        report.http_status = response.status
                        if response.status in {401, 403, 429}:
                            raise StateError(f'hh.ru ограничил доступ к форме (HTTP {response.status}). Проверьте доступ вручную; отправки не было.')
                    report.url = _safe_url(page.url)
                    # Preserve a sanitized structural snapshot before HH has a
                    # chance to replace or close this tab.
                    self._record_form_layout(page, report)
                    self._guard_page(page, snapshot["id"])
                    existing = self._bound_success_count(page, snapshot['id'])
                    if existing:
                        report.success_markers = existing
                        return "already_applied", False
                    deadline = min(time.monotonic() + self.FORM_WAIT_SECONDS, float(snapshot.get('_permit_expires_at') or 0) - 5)
                    # HH can redirect the legacy response URL back to the
                    # vacancy card. Its main action may submit immediately when
                    # a letter is optional. Known application requests stay
                    # blocked until the exact editor and text are verified.
                    if self._is_vacancy_card(page.url, snapshot['id']) and not self._cover_candidates(page, report):
                        page = self._open_response_entry(context, page, report, barrier, deadline=deadline)
                        self._record_form_layout(page, report)
                    cover = self._cover_field(page, report, deadline=deadline)
                    self._select_resume(page, report, cover)
                    # Selecting another resume can replace or collapse the editor.
                    cover = self._cover_field(page, report, deadline=deadline)
                    self._select_resume(page, report, cover, verify_only=True)
                    self._verify_form_binding(page, cover, snapshot['id'])
                    self._assert_no_required_questions(page, cover, report)
                    letter = str(snapshot["letter_text"])
                    report.stage = 'filling_letter'
                    cover.fill(letter, timeout=10000)
                    cover_handle = cover.element_handle()
                    if cover_handle is None or self._cover_text(cover) != letter:
                        raise StateError('Поле hh.ru не сохранило точный одобренный текст письма. Отправки не было.')
                    self._assert_no_required_questions(page, cover, report)
                    button = self._submit_button(page, report, cover).element_handle()
                    if button is None:
                        raise StateError('Кнопка отправки исчезла из формы hh.ru. Отправки не было.')
                    self._guard_page(page, snapshot["id"])
                    self._select_resume(page, report, cover, verify_only=True)
                    with self.db.submission_guard(snapshot):
                        # These checks do not reopen or refill anything. A replaced
                        # editor or button requires a fresh final confirmation.
                        current_button = self._submit_button(page, report, cover)
                        if not self._same_element(current_button, button):
                            raise StateError('Форма hh.ru изменилась перед отправкой. Подтвердите отклик заново.')
                        self._verify_form_binding(page, cover, snapshot['id'])
                        self._select_resume(page, report, cover, verify_only=True)
                        self._verify_live_cover(page, cover_handle, letter, report)
                        if str(self.settings["submit"].get("resume_id") or "") != snapshot.get("_resume_id_at_confirmation"):
                            raise StateError("Выбранное резюме изменилось. Подтвердите отклик заново.")
                        if time.monotonic() > float(snapshot.get("_permit_expires_at") or 0):
                            raise StateError("Время финального подтверждения истекло. Подтвердите отклик ещё раз.")
                        # A failure to remove the response-entry barrier stops
                        # here; the physical send control remains untouched.
                        from .licensing import require_license
                        require_license()
                        if self.cancel_event is not None and self.cancel_event.is_set():
                            raise StateError('Групповая отправка остановлена до клика.')
                        barrier.arm(letter, snapshot['_resume_id_at_confirmation'])
                        # Mark uncertainty before invoking the click itself.
                        report.stage = 'clicking_submit'
                        clicked = True
                        report.clicked = True
                        button.click(timeout=30000)
                    report.stage = 'checking_confirmation'
                    # Pump browser events while awaiting a matching request AND
                    # HH confirmation. No second click or direct API replay.
                    until = time.monotonic() + 12
                    while time.monotonic() < until:
                        page.wait_for_timeout(200)
                        successes = self._bound_success_count(page, snapshot['id'])
                        report.success_markers = successes
                        if barrier.accepted and successes:
                            return "confirmed", True
                        if report.delivery_blocked:
                            return "delivery_payload_blocked", True
                    return "letter_delivery_not_proven", True
                finally:
                    if page is not None:
                        self._record_form_layout(page, report)
                    try:
                        context.close()
                    except Exception:
                        LOGGER.exception("Could not close submission browser context")
        except PlaywrightTimeoutError as exc:
            if clicked:
                return "timeout_after_click", True
            raise StateError("hh.ru не завершил открытие или проверку формы за отведённое время. Отправка не выполнена.") from exc

    @staticmethod
    def _is_target_closed_error(exc: Exception) -> bool:
        if isinstance(exc, _TargetClosedBeforeSubmit) or type(exc).__name__ == 'TargetClosedError':
            return True
        message = str(exc).lower()
        return 'target page, context or browser has been closed' in message or 'targetclosederror' in message

    @staticmethod
    def _page_is_closed(page: Any) -> bool:
        check = getattr(page, 'is_closed', None)
        try:
            return bool(check()) if callable(check) else bool(getattr(page, 'closed', False))
        except Exception:
            return True

    @staticmethod
    def _is_vacancy_card(url: str, vacancy_id: str) -> bool:
        try:
            parsed = urllib.parse.urlsplit(url)
        except ValueError:
            return False
        return (
            is_hh_host(url)
            and re.fullmatch(r'/vacancy/\d+/?', parsed.path) is not None
            and _url_vacancy_ids(url) == {str(vacancy_id)}
        )

    def _response_entry_action(self, page: Any, report: FormReport) -> Any:
        controls = page.locator('a, button, [role="button"]')
        infos = controls.evaluate_all('els => els.map(' + CONTROL_INFO_JS + ')')
        candidates: list[tuple[Any, dict[str, Any]]] = []
        for index, info in enumerate(infos):
            item = controls.nth(index)
            if _is_response_entry_action(info, page.url, report.vacancy_id) and item.is_visible() and item.is_enabled():
                candidates.append((item, info))
        report.response_actions = len(candidates)
        # Group by data-qa first: hh.ru's own marker is the strongest signal
        # that two controls are the same action rendered twice.
        top = [(item, info) for item, info in candidates if info.get('qa') == 'vacancy-response-link-top']
        if not top and len(candidates) > 1:
            # Newer layouts use a different response data-qa on both copies.
            marked = [
                (item, info) for item, info in candidates
                if 'vacancy-response' in str(info.get('qa') or '').casefold()
            ]
            if marked:
                top = marked
        if len(top) == 1:
            return top[0][0]
        if len(top) > 1:
            # Current HH layouts can render desktop and sticky-header copies
            # of the same anchor at once.  They are safe aliases only when
            # every copy has the same explicit, trusted destination.  Empty
            # button actions or distinct URLs remain ambiguous and stop.
            signatures = {
                self._response_entry_signature(info, page.url, report.vacancy_id)
                for _, info in top
            }
            if None not in signatures and len(signatures) == 1:
                report.response_action_duplicates = len(top) - 1
                return top[0][0]
        if len(top) > 1 or len(candidates) != 1:
            raise StateError(f'На карточке hh.ru не найдена единственная безопасная точка открытия формы (найдено: {len(candidates)}). Отправки не было.')
        return candidates[0][0]

    @staticmethod
    def _response_entry_signature(
        info: dict[str, Any],
        page_url: str,
        vacancy_id: str,
    ) -> tuple[str, str, str, tuple[str, ...]] | None:
        """Identify exact duplicate HH response entry points.

        hh.ru renders the same "Откликнуться" action twice - in the card and
        in the sticky header. On 05.09 both copies were <button> elements
        with no href, so this returned None for each, the caller saw two
        ambiguous candidates and refused to open the form at all.

        An anchor is identified by its resolved destination. A button has no
        destination, so it is identified by its data-qa plus visible caption:
        two buttons carrying the same hh.ru response data-qa and the same
        caption on the same vacancy page are the same action. Anything
        without a data-qa stays unidentifiable and still stops the attempt.
        """
        names = tuple(sorted({
            _normalized_label(info.get('text')),
            _normalized_label(info.get('aria')),
        } - {''}))
        qa = str(info.get('qa') or '')
        tag = str(info.get('tag') or '')

        if tag == 'a':
            href = str(info.get('href') or '').strip()
            if not href or href == '#':
                return None
            absolute = urllib.parse.urldefrag(urllib.parse.urljoin(page_url, href))[0]
            if not is_hh_host(absolute) or _url_vacancy_ids(absolute) != {str(vacancy_id)}:
                return None
            return (qa, tag, absolute, names)

        # Buttons carry no destination; require an explicit hh.ru response
        # marker and a caption so unrelated buttons cannot be merged.
        if not qa or 'vacancy-response' not in qa.casefold() or not names:
            return None
        return (qa, tag, '', names)

    def _matching_vacancy_page(self, context: Any, vacancy_id: str, preferred: Any = None) -> Any:
        pages = [
            page for page in context.pages
            if not self._page_is_closed(page)
            and is_hh_host(page.url)
            and _url_vacancy_ids(page.url) == {str(vacancy_id)}
        ]
        if not pages:
            raise _TargetClosedBeforeSubmit('No open HH page remained before the physical submit click')
        response_pages = [
            page for page in pages
            if urllib.parse.urlsplit(page.url).path.rstrip('/') == '/applicant/vacancy_response'
        ]
        if response_pages:
            return response_pages[-1]
        if preferred in pages:
            return preferred
        return pages[-1]

    def _open_response_entry(
        self,
        context: Any,
        page: Any,
        report: FormReport,
        barrier: _WriteRequestBarrier,
        *,
        deadline: float,
    ) -> Any:
        report.stage = 'opening_response_form'
        action = self._response_entry_action(page, report)
        handle = action.element_handle()
        if handle is None or not _is_response_entry_action(handle.evaluate(CONTROL_INFO_JS), page.url, report.vacancy_id):
            raise StateError('Кнопка открытия формы hh.ru изменилась. Отправки не было.')
        barrier.install()
        report.response_action_clicks += 1
        try:
            action.click(timeout=min(10000, max(1, (deadline - time.monotonic()) * 1000)))
        except Exception as exc:
            if not self._is_target_closed_error(exc):
                raise
        # HH can close the vacancy tab just before mounting its replacement.
        # The entry action has already been clicked, so only wait; never click
        # a second time during this hand-off.
        while time.monotonic() < deadline:
            try:
                page = self._matching_vacancy_page(context, report.vacancy_id, page)
                page.wait_for_timeout(min(250, max(1, (deadline - time.monotonic()) * 1000)))
                return self._matching_vacancy_page(context, report.vacancy_id, page)
            except Exception as exc:
                if not self._is_target_closed_error(exc):
                    raise
                waiter = next((item for item in context.pages if not self._page_is_closed(item)), None)
                if waiter is not None:
                    waiter.wait_for_timeout(min(100, max(1, (deadline - time.monotonic()) * 1000)))
                else:
                    try:
                        context.wait_for_event('page', timeout=max(1, (deadline - time.monotonic()) * 1000))
                    except Exception as exc:
                        raise _TargetClosedBeforeSubmit('HH did not open a replacement page') from exc
        raise _TargetClosedBeforeSubmit('HH did not mount a replacement response page before the deadline')

    def _single_hh_page(self, context: Any) -> Any:
        open_pages = [page for page in context.pages if not self._page_is_closed(page)]
        hh_pages = [page for page in open_pages if is_hh_host(page.url)]
        return hh_pages[-1] if hh_pages else (open_pages[-1] if open_pages else context.new_page())

    def _confirm_resume_ownership(self, page: Any, wanted: str, report: FormReport) -> None:
        """Prove the configured resume still belongs to this Chromium session.

        The proof is refreshed for every final click. Only explicit resume
        references on HH's owner pages (``/applicant/resumes`` or the current
        ``/applicant/profile/me`` route) are considered; account-menu links
        and text labels are insufficient.
        """
        if not wanted:
            raise StateError('Сначала выберите резюме через LOGIN_HH_WINDOWS.cmd.')
        report.stage = 'checking_resume'
        response = page.goto(self.RESUMES_URL, wait_until='domcontentloaded', timeout=45000)
        status = int(response.status) if response is not None and isinstance(response.status, int) else 0
        report.http_status = status
        current = str(page.url or '')
        owner_path = urllib.parse.urlsplit(current).path.rstrip('/')
        # Since September 2026 HH redirects the former /applicant/resumes
        # address to /applicant/profile/me.  The diagnostic page was fully
        # authenticated and contained the "Резюме и профиль" navigation, but
        # 3.3.0 rejected it before inspecting the exact Resume ID.
        if not is_hh_host(current) or owner_path not in {'/applicant/resumes', '/applicant/profile/me'}:
            raise StateError('Сессия hh.ru или выбранное резюме изменились. Запустите LOGIN_HH_WINDOWS.cmd при закрытом агенте.')
        if status != 200:
            raise StateError(f'hh.ru не подтвердил список резюме (HTTP {status or "нет ответа"}). Отправки не было.')
        body = page.locator('body').inner_text(timeout=10000).casefold()
        if any(marker in body for marker in self.CAPTCHA_MARKERS) or 'vpn мешает работе сайта' in body:
            raise StateError('hh.ru запросил ручную проверку доступа. Завершите её через LOGIN_HH_WINDOWS.cmd; отправки не было.')
        links = page.locator(
            'a[href*="/resume/"], a[href*="resume="], '
            '[data-resume-id], [data-resume-hash], [data-hh-resume-hash]'
        )
        # The resume list is rendered client-side. A single read can land
        # before hydration and return zero links, which is "not read yet",
        # not "this resume is not yours". On 04.09 that difference was
        # invisible: the user was told the Resume ID was wrong while the
        # real cause was an unrendered list, and every submission failed.
        references: set[str] = set()
        for attempt in range(4):
            try:
                links.first.wait_for(state='attached', timeout=5000)
            except Exception:
                pass
            references = set()
            for index in range(links.count()):
                item = links.nth(index)
                for key in ('href', 'data-resume-id', 'data-resume-hash', 'data-hh-resume-hash'):
                    reference = self._resume_ref(item.get_attribute(key) or '')
                    if reference and not reference.isdecimal():
                        references.add(reference)
            try:
                # Current React layouts can keep the public hash in page JSON
                # or in the recommendations URL while rendering no direct
                # /resume/<hash> anchor.  This is the same owner-page proof
                # used by guided login; arbitrary account-menu text is ignored.
                references.update(document_resume_refs(page.content(), current))
            except Exception:
                pass
            if references:
                break
            if attempt < 3:
                page.wait_for_timeout(1500)
        report.owned_resumes = len(references)
        report.resume_owned = wanted in references
        if not references:
            raise StateError(
                'Не удалось прочитать список резюме на hh.ru (страница «Мои резюме» не отдала ни одной ссылки). '
                'Отправки не было. Откройте hh.ru в браузере агента и убедитесь, что список резюме открывается; '
                'при необходимости запустите LOGIN_HH_WINDOWS.cmd при закрытом агенте.'
            )
        if not report.resume_owned:
            raise StateError('Выбранный Resume ID не найден в текущем аккаунте hh.ru. Закройте агент, запустите LOGIN_HH_WINDOWS.cmd и выберите резюме заново.')

    def _guard_page(self, page: Any, vacancy_id: str) -> None:
        current = page.url
        if not is_hh_host(current):
            raise StateError("browser left hh.ru during submission")
        lower_url = current.lower()
        if any(marker in lower_url for marker in self.LOGIN_MARKERS):
            raise StateError("hh.ru session is not authenticated; run guided login")
        body = page.locator("body").inner_text(timeout=10000).lower()
        if any(marker in lower_url or marker in body for marker in self.CAPTCHA_MARKERS):
            raise StateError("CAPTCHA or anti-bot verification detected; manual action required")
        if any(marker in body for marker in ('vpn мешает работе сайта', 'доступ временно ограничен', 'слишком много запросов')):
            raise StateError('hh.ru ограничил доступ к форме. Пройдите видимую проверку вручную; отправки не было.')
        if any(marker in lower_url for marker in ("/applicant/test", "/applicant/assessment")) or any(marker in body for marker in ("для отклика необходимо пройти тест", "чтобы откликнуться, пройдите тест", "пройти тестирование")):
            raise StateError("hh.ru requires a test; manual completion is required")
        ids = _url_vacancy_ids(current)
        if ids:
            if ids != {str(vacancy_id)}:
                raise StateError('hh.ru открыл другую вакансию. Отправки не было.')
        else:
            hidden = page.locator('input[type="hidden"][name="vacancyId" i], input[type="hidden"][name="vacancy_id" i]')
            values = {hidden.nth(i).input_value() for i in range(hidden.count()) if hidden.nth(i).is_enabled()}
            if values != {str(vacancy_id)}:
                raise StateError('Не удалось связать открытую форму hh.ru с одобренной вакансией. Отправки не было.')

    def _verify_form_binding(self, page: Any, cover: Any, vacancy_id: str) -> None:
        scope = self._form_scope(page, cover)
        hidden = scope.locator('input[type="hidden"][name="vacancyId" i], input[type="hidden"][name="vacancy_id" i]')
        values = {hidden.nth(i).input_value() for i in range(hidden.count()) if hidden.nth(i).is_enabled()}
        if values and values != {str(vacancy_id)}:
            raise StateError('Форма с письмом относится к другой вакансии. Отправки не было.')

    def _visible_locators(self, page: Any, selectors: tuple[str, ...]) -> list[Any]:
        # CSS union deduplicates the same DOM node without merging different
        # controls that happen to have identical HTML.
        locator = page.locator(', '.join(selectors))
        return [locator.nth(i) for i in range(locator.count()) if locator.nth(i).is_visible() and locator.nth(i).is_enabled()]

    def _cover_candidates(self, page: Any, report: FormReport) -> list[Any]:
        response_page = urllib.parse.urlsplit(page.url).path.rstrip('/') == '/applicant/vacancy_response'
        controls = page.locator(self.TEXT_CONTROLS)
        infos = controls.evaluate_all('els => els.map(' + CONTROL_INFO_JS + ')')
        fields = []
        hidden = 0
        for index, info in enumerate(infos):
            item = controls.nth(index)
            if not _is_cover_control(info, response_page):
                continue
            if item.is_visible() and item.is_enabled() and item.is_editable():
                fields.append(item)
            else:
                hidden += 1
        report.cover_candidates = len(fields)
        report.cover_hidden = hidden
        if len(fields) > 1:
            raise StateError(f'На hh.ru найдено несколько полей сопроводительного письма ({len(fields)}). Отправки не было; сведения о форме сохранены в логе.')
        return fields

    def _letter_openers(self, page: Any, report: FormReport) -> list[Any]:
        controls = page.locator('button, a, summary, label, [role="button"]')
        infos = controls.evaluate_all('els => els.map(' + CONTROL_INFO_JS + ')')
        candidates = []
        for index, info in enumerate(infos):
            item = controls.nth(index)
            if _is_letter_opener(info) and item.is_visible() and item.is_enabled():
                candidates.append(item)
        report.cover_expanders = len(candidates)
        if len(candidates) > 1:
            raise StateError('На hh.ru несколько элементов добавления письма. Закройте лишние формы и подтвердите отклик заново; отправки не было.')
        return candidates

    def _cover_field(self, page: Any, report: FormReport, *, deadline: float | None = None) -> Any:
        deadline = deadline if deadline is not None else time.monotonic() + self.FORM_WAIT_SECONDS
        expanded = False
        resume_prepared = False
        report.stage = 'waiting_for_letter'
        while time.monotonic() < deadline:
            self._guard_page(page, report.vacancy_id)
            existing = self._bound_success_count(page, report.vacancy_id)
            if existing:
                report.success_markers = existing
                raise _ExistingResponseDetected('hh.ru уже показывает отклик на эту вакансию. Доставка текущего письма не подтверждена. Проверьте переписку на hh.ru; повтор автоматически не выполняется.')
            fields = self._cover_candidates(page, report)
            if fields:
                report.stage = 'letter_ready'
                return fields[0]
            # Some response forms reveal the letter only after selecting a
            # resume. Use exactly the configured resume, never the first option.
            if not resume_prepared:
                resume_controls = page.locator('input[type="radio"][name*="resume" i], input[type="radio"][data-qa*="resume" i], select[name*="resume" i], [role="radio"][data-qa*="resume" i], [role="option"][data-qa*="resume" i]')
                if any(resume_controls.nth(i).is_enabled() for i in range(resume_controls.count())):
                    self._select_resume(page, report)
                    resume_prepared = True
                    continue
            if not expanded:
                openers = self._letter_openers(page, report)
                if openers:
                    report.stage = 'opening_letter'
                    # No application/submit control is used to open a letter.
                    opener = openers[0].element_handle()
                    if opener is None or not _is_letter_opener(opener.evaluate(CONTROL_INFO_JS)):
                        raise StateError('Элемент добавления письма изменился. Подтвердите отклик заново.')
                    opener.click(timeout=min(5000, max(1, (deadline - time.monotonic()) * 1000)))
                    report.cover_expansions += 1
                    expanded = True
                    continue
            page.wait_for_timeout(min(250, max(1, (deadline - time.monotonic()) * 1000)))
        report.stage = 'letter_unavailable'
        if report.response_action_clicks and report.blocked_writes:
            reason = ('Страница hh.ru попыталась изменить данные до появления поля письма; '
                      'агент безопасно заблокировал этот запрос.')
        elif report.cover_hidden:
            reason = 'Поле сопроводительного письма осталось скрытым или недоступным.'
        else:
            reason = 'hh.ru не показал поле сопроводительного письма в форме отклика.'
        raise StateError(reason + ' Отправки не было. Сведения о форме включены в «Скачать лог». Проверьте форму hh.ru и подтвердите отклик заново.')

    @staticmethod
    def _cover_text(cover: Any) -> str:
        return cover.evaluate("el => el.tagName === 'TEXTAREA' ? el.value : el.innerText")

    @staticmethod
    def _same_element(item: Any, handle: Any) -> bool:
        return bool(item.evaluate('(el, other) => el === other', handle))

    def _verify_live_cover(self, page: Any, handle: Any, letter: str, report: FormReport) -> None:
        fields = self._cover_candidates(page, report)
        if len(fields) != 1 or not self._same_element(fields[0], handle) or self._cover_text(fields[0]) != letter:
            raise StateError('Поле или текст письма изменились перед отправкой. Отправки не было; подтвердите отклик заново.')

    @staticmethod
    def _form_scope(page: Any, cover: Any) -> Any:
        for selector in ('xpath=ancestor::*[@role="dialog" or @aria-modal="true" or self::dialog][1]', 'xpath=ancestor::*[@data-qa="vacancy-response-popup-form" or @data-qa="vacancy-response-form"][1]', 'xpath=ancestor::form[1]'):
            scope = cover.locator(selector)
            if scope.count() == 1:
                return scope
        return page

    # Control labels that are hh.ru's own UI chrome. Recording these is what
    # makes the bundle diagnostic; they are markup, not user data.
    LABEL_LIMIT = 40

    def _record_form_layout(self, page: Any, report: FormReport) -> None:
        try:
            report.url = _safe_url(page.url)
            controls = page.locator('input, textarea, select, button, a, [role="button"], [contenteditable="true"]')
            safe_names = {'text', 'message', 'letter', 'coverletter', 'cover_letter', 'resume', 'resumeid', 'resume_id', 'vacancyid', 'vacancy_id'}
            report.controls = []
            prioritized = []
            for index in range(controls.count()):
                item = controls.nth(index)
                info = item.evaluate(CONTROL_INFO_JS)
                if info.get('response') or info.get('letterSection') or info.get('tag') == 'textarea' or _normalized_label(info.get('text')) in self.SUBMIT_LABELS:
                    priority = 0
                else:
                    priority = 1
                prioritized.append((priority, index))
            for _, index in sorted(prioritized)[:60]:
                item = controls.nth(index)
                tag = item.evaluate('el => el.tagName.toLowerCase()')
                name = str(item.get_attribute('name') or '').lower()
                qa = str(item.get_attribute('data-qa') or '').lower()
                kind = str(item.get_attribute('type') or '').lower()
                report.controls.append({
                    'tag': tag if tag in {'input', 'textarea', 'select', 'button', 'a', 'div', 'span'} else 'other',
                    'kind': kind if kind in {'text', 'hidden', 'radio', 'checkbox', 'submit', 'button', 'search', 'email', 'tel', 'password'} else 'other',
                    'name': name if name in safe_names else ('other' if name else ''),
                    # data-qa values are static identifiers from hh.ru's own
                    # frontend build. The previous token whitelist collapsed
                    # every button to "other" - on 04.09 that hid the one fact
                    # needed to fix the submit selectors after hh.ru renamed
                    # its design-system hooks. Structural names are kept;
                    # embedded ids (resume hashes, numeric ids) are scrubbed.
                    'qa': self._scrub_identifiers(qa),
                    # Visible label of buttons and links only. Never read from
                    # inputs/textareas, whose content is what the user typed.
                    'label': self._safe_diagnostic_label(item, tag),
                    'visible': item.is_visible(), 'enabled': item.is_enabled(),
                    'required': item.get_attribute('required') is not None or item.get_attribute('aria-required') == 'true',
                })
        except Exception:
            # Diagnostics must never replace the actual outcome or leak DOM data.
            LOGGER.debug('Could not finish sanitized response-form diagnostics')

    # Runs that look like an id rather than a markup name: resume hashes,
    # numeric ids, uuids. Scrubbed out of anything written to diagnostics.
    _IDENTIFIER_RUN = re.compile(r'[0-9a-f]{6,}|\d{4,}', re.IGNORECASE)

    @classmethod
    def _scrub_identifiers(cls, value: str) -> str:
        return cls._IDENTIFIER_RUN.sub('<id>', value)

    def _control_label(self, item: Any, tag: str) -> str:
        """Visible caption of an actionable control, for diagnostics only."""
        if tag not in {'button', 'a'}:
            # Inputs and textareas hold user-entered text; never captured.
            return ''
        try:
            text = str(item.inner_text(timeout=1000) or '').strip()
            if not text:
                text = str(item.get_attribute('aria-label') or '').strip()
            return self._scrub_identifiers(' '.join(text.split())[:self.LABEL_LIMIT])
        except Exception:
            return ''

    @staticmethod
    def _resume_ref(value: str) -> str:
        return resume_ref(value)

    def _resume_matches(self, item: Any, wanted: str, *, native: bool = False) -> bool:
        value = item.input_value() if native else str(item.get_attribute('value') or '')
        values = [value] + [str(item.get_attribute(key) or '') for key in ('data-resume-id', 'data-resume-hash', 'href')]
        # Label links associate an internal numeric form value with the public
        # resume hash. This association must belong to this exact control.
        selector = 'a[href*="/resume/"], a[href*="resume="]'
        links = item.locator('xpath=ancestor::label[1]').locator(selector) if native else item.locator(selector)
        for index in range(links.count()):
            values.append(links.nth(index).get_attribute('href') or '')
        references = {self._resume_ref(value) for value in values if value}
        public = {value for value in references if value and not value.isdecimal()}
        if public and public != {wanted}:
            return False
        return wanted in references

    def _select_resume(self, page: Any, report: FormReport, cover: Any = None, *, verify_only: bool = False) -> None:
        wanted = str(self.settings['submit'].get('resume_id') or '')
        if not wanted:
            raise StateError('Сначала выберите резюме в настройках.')
        scope = page
        in_form = False
        if cover is not None:
            forms = cover.locator('xpath=ancestor::form[1]')
            if forms.count() == 1:
                scope = forms
                in_form = True
            else:
                dialogs = cover.locator('xpath=ancestor::*[@role="dialog"][1]')
                if dialogs.count() == 1:
                    scope = dialogs
        radios = scope.locator('input[type="radio"][name*="resume" i], input[type="radio"][data-qa*="resume" i]')
        enabled = [radios.nth(i) for i in range(radios.count()) if radios.nth(i).is_enabled()]
        report.resume_options = len(enabled)
        if enabled:
            matches = [item for item in enabled if self._resume_matches(item, wanted, native=True)]
            if len(matches) != 1:
                raise StateError('Выбранное резюме не найдено однозначно среди вариантов формы hh.ru. Проверьте Resume ID.')
            chosen = matches[0]
            if not chosen.is_checked() and not verify_only:
                if chosen.is_visible():
                    chosen.check()
                else:
                    # HH styles native radios as hidden controls; their visible
                    # label is the supported UI action, no force-click or DOM edit.
                    label = chosen.locator('xpath=ancestor::label[1]')
                    if label.count() != 1 or not label.is_visible():
                        control_id = chosen.get_attribute('id')
                        label = scope.locator('label[for=' + json.dumps(control_id) + ']') if control_id else label
                    if label.count() != 1 or not label.is_visible():
                        raise StateError('hh.ru не показал элемент выбора резюме. Отправка не выполнена.')
                    label.click()
            checked = [item for item in enabled if item.is_checked()]
            if len(checked) == 1 and self._resume_matches(checked[0], wanted, native=True):
                report.resume_proof = 'checked_radio'
                return
            raise StateError('Выбранное резюме не сохранилось в форме hh.ru. Отправка не выполнена.')
        selects = scope.locator('select[name*="resume" i]')
        enabled_selects = [selects.nth(i) for i in range(selects.count()) if selects.nth(i).is_enabled()]
        if enabled_selects:
            if len(enabled_selects) != 1:
                raise StateError('В форме найдено несколько полей выбора резюме.')
            select = enabled_selects[0]
            if self._resume_ref(select.input_value()) != wanted and not verify_only:
                options = select.locator('option')
                values = [options.nth(i).get_attribute('value') for i in range(options.count()) if options.nth(i).is_enabled() and self._resume_ref(options.nth(i).get_attribute('value') or '') == wanted]
                if len(values) == 1:
                    select.select_option(value=values[0])
            if self._resume_ref(select.input_value()) == wanted:
                report.resume_proof = 'selected_option'
                return
            raise StateError('В выпадающем списке hh.ru не выбрано нужное резюме.')
        # Hidden inputs are meaningful only inside the same form as the letter.
        # A link elsewhere on the page was previously (incorrectly) enough.
        hidden = scope.locator('input[type="hidden"][name*="resume" i]') if in_form else None
        if hidden is not None and hidden.count():
            values = {self._resume_ref(hidden.nth(i).input_value()) for i in range(hidden.count()) if hidden.nth(i).is_enabled() and hidden.nth(i).input_value()}
            if values == {wanted}:
                report.resume_proof = 'form_value'
                return
        choices = scope.locator('[role="radio"][data-qa*="resume" i], [role="option"][data-qa*="resume" i], [data-qa*="resume" i][aria-checked], [data-qa*="resume" i][aria-selected]')
        available = [choices.nth(i) for i in range(choices.count()) if choices.nth(i).is_visible()]
        if available:
            matches = [item for item in available if self._resume_matches(item, wanted)]
            if len(matches) == 1 and not verify_only and not any(matches[0].get_attribute(key) == 'true' for key in ('aria-checked', 'aria-selected')):
                matches[0].click()
            selected = [item for item in available if any(item.get_attribute(key) == 'true' for key in ('aria-checked', 'aria-selected'))]
            if len(selected) == 1 and self._resume_matches(selected[0], wanted):
                report.resume_proof = 'selected_accessible_option'
                return
            raise StateError('hh.ru не подтвердил выбор нужного резюме. Отправка не выполнена.')
        summary = scope.locator('[data-qa="vacancy-response-selected-resume"], [data-qa="vacancy-response-resume-selected"]')
        visible_summary = [summary.nth(i) for i in range(summary.count()) if summary.nth(i).is_visible()]
        if len(visible_summary) == 1 and self._resume_matches(visible_summary[0], wanted):
            report.resume_proof = 'selected_resume_summary'
            return
        # On a single-resume form HH can show no picker: the one public resume
        # link inside this exact form/dialog is then the only identity proof.
        # A link elsewhere on the page is deliberately insufficient.
        if cover is not None and scope is not page:
            links = scope.locator('a[href*="/resume/"], a[href*="resume="]')
            references = {self._resume_ref(links.nth(i).get_attribute('href') or '') for i in range(links.count())}
            references.discard('')
            if references == {wanted}:
                report.resume_proof = 'single_form_resume_link'
                return
        # HH omits a picker when the authenticated account owns exactly one
        # resume. Ownership was proven immediately before this form was opened,
        # so there is no alternative resume the form could attach.
        if report.resume_owned and report.owned_resumes == 1:
            report.resume_proof = 'single_owned_resume'
            return
        report.resume_proof = 'unrecognized'
        raise StateError('hh.ru не предоставил проверяемый выбор резюме в форме. Если резюме менялось, закройте агент и запустите LOGIN_HH_WINDOWS.cmd; отправки не было.')

    def _assert_no_required_questions(self, page: Any, cover: Any, report: FormReport) -> None:
        scope = self._form_scope(page, cover)
        explicit_questions = scope.locator(
            'textarea[name^="task_"], input[name^="task_"], select[name^="task_"], '
            '[data-qa*="question"] input:not([type="hidden"]), '
            '[data-qa*="question"] textarea, [data-qa*="question"] select, '
            '[data-qa*="test-answer"] input:not([type="hidden"]), '
            '[data-qa*="test-answer"] textarea, [data-qa*="test-answer"] select'
        )
        cover_handle = cover.element_handle()
        questions = 0
        for index in range(explicit_questions.count()):
            item = explicit_questions.nth(index)
            try:
                if item.is_visible() and item.is_enabled() and not self._same_element(item, cover_handle):
                    questions += 1
            except Exception:
                questions += 1
        report.employer_questions = questions
        if questions:
            raise StateError(f'В форме hh.ru найдено вопросов работодателя: {questions}. Агент не будет угадывать ответы; отправки не было.')
        body = scope.inner_text(timeout=10000).lower() if scope is not page else page.locator('body').inner_text(timeout=10000).lower()
        if "обязательный вопрос" in body or "вопросы работодателя" in body:
            possible_questions = scope.locator('input:not([type="hidden"]):not([type="submit"]), textarea, select, [contenteditable="true"]')
            non_cover_visible = 0
            for index in range(possible_questions.count()):
                item = possible_questions.nth(index)
                try:
                    if item.is_visible() and item.is_enabled() and not self._same_element(item, cover_handle):
                        non_cover_visible += 1
                except Exception:
                    non_cover_visible += 1
            if non_cover_visible:
                report.required_unanswered = non_cover_visible
                raise StateError("employer questions are present; the agent will not guess answers")
        required = scope.locator('input[required], textarea[required], select[required], [aria-required="true"]')
        unanswered = 0
        for index in range(required.count()):
            item = required.nth(index)
            try:
                if not item.is_visible() or not item.is_enabled():
                    continue
                if self._same_element(item, cover_handle):
                    continue
                tag = item.evaluate("el => el.tagName.toLowerCase()")
                kind = (item.get_attribute("type") or "").lower()
                if kind in {"submit", "button", "hidden"}:
                    continue
                if kind in {"radio", "checkbox"}:
                    name = item.get_attribute("name") or ""
                    checked = scope.locator('input[name=' + json.dumps(name) + ']:checked').count() > 0 if name else item.is_checked()
                    if not checked:
                        unanswered += 1
                elif tag == "select":
                    if not item.input_value():
                        unanswered += 1
                else:
                    if not item.input_value().strip():
                        unanswered += 1
            except Exception:
                unanswered += 1
        report.required_unanswered = unanswered
        if unanswered:
            raise StateError(f"live hh.ru form has {unanswered} unanswered required question(s); the agent will not guess answers")

    def _submit_button(self, page: Any, report: FormReport, cover: Any) -> Any:
        scope = self._form_scope(page, cover)
        candidates = self._visible_locators(scope, self.SUBMIT_SELECTORS) if scope is not page else []
        if not candidates and scope is not page:
            candidates = self._labelled_submit_buttons(scope)
        if not candidates:
            # Relate a portal footer or form= control to THIS editor. Captions
            # elsewhere on the page, including recommendations, confer no trust.
            candidates = self._related_submit_buttons(page, cover)
            report.submit_match = 'editor_relation'
        else:
            report.submit_match = 'editor_scope'
        candidates = [item for item in candidates if 'vacancy-response-link' not in
                      str(item.get_attribute('data-qa') or '').casefold()]
        report.submit_buttons = len(candidates)
        if len(candidates) != 1:
            raise StateError(f'С формой сопроводительного письма связано кнопок отправки: {len(candidates)}. '
                             'Отправки не было. Сведения о форме сохранены в диагностике.')
        return candidates[0]

    def _related_submit_buttons(self, page: Any, cover: Any) -> list[Any]:
        handle = cover.element_handle()
        if handle is None:
            return []
        controls = page.locator('button, [role="button"], input[type="submit"]')
        found = []
        for index in range(controls.count()):
            item = controls.nth(index)
            if not item.is_visible() or not item.is_enabled():
                continue
            info = item.evaluate(CONTROL_INFO_JS)
            caption = _normalized_label(info.get('text') or info.get('aria') or item.get_attribute('value'))
            qa = str(info.get('qa') or '')
            if 'vacancy-response-link' in qa or info.get('chat') or info.get('question'):
                continue
            if caption not in self.SUBMIT_LABELS and 'vacancy-response-submit' not in qa:
                continue
            related = item.evaluate(r"""(button, editor) => {
                if (!editor || !editor.isConnected) return false;
                if (button.form && editor.form && button.form === editor.form) return true;
                // Walk from the editor, never from a background button. The
                // nearest shared component must have exactly one letter editor.
                for (let p = editor.parentElement; p && !p.matches('body, main, html'); p = p.parentElement) {
                    if (!p.contains(button)) continue;
                    if (p.querySelectorAll('textarea, [contenteditable="true"]').length !== 1) return false;
                    if (p.querySelector('nav, [data-qa="vacancy-serp__vacancy"], [data-qa="vacancy-recommendation"]')) return false;
                    const buttons = [...p.querySelectorAll('button, [role="button"], input[type="submit"]')];
                    const entries = buttons.some(b => (b.getAttribute('data-qa') || '').includes('vacancy-response-link'));
                    if (entries) return false;
                    // Explicit response component, or a small editor component
                    // with a resume control. Never accept page-wide proximity.
                    return p.matches('[role="dialog"], [aria-modal="true"], dialog, [data-qa*="vacancy-response"]') ||
                        !!p.querySelector('[name*="resume" i], [data-qa*="resume-select"], [data-qa*="resume-title"]');
                }
                return false;
            }""", handle)
            if related:
                found.append(item)
        return found

    def _labelled_submit_buttons(self, scope: Any) -> list[Any]:
        """Actionable controls whose visible caption is a submit caption."""
        controls = scope.locator('button, [role="button"], input[type="submit"]')
        found: list[tuple[Any, str, bool]] = []
        for index in range(min(controls.count(), 80)):
            item = controls.nth(index)
            try:
                if not (item.is_visible() and item.is_enabled()):
                    continue
                info = item.evaluate(CONTROL_INFO_JS)
                # The response popup is rendered over the vacancy card. HH
                # keeps one or more responsive copies of the card's original
                # "Откликнуться" entry point visible behind that popup. Those
                # controls have the same caption as a possible final submit,
                # but clicking them only reopens/replaces the form. 3.5.0
                # counted the background copies together with the real submit
                # button and stopped with 2-10 matches. Never treat a known
                # response *entry link* as the terminal action.
                qa = str(info.get('qa') or '').casefold()
                if 'vacancy-response-link' in qa:
                    continue
                caption = str(item.inner_text(timeout=1000) or '').strip()
                if not caption:
                    caption = str(item.get_attribute('value') or item.get_attribute('aria-label') or '')
            except Exception:
                continue
            caption = ' '.join(caption.split()).lower().replace('ё', 'е')
            if not caption or caption in self.SUBMIT_LABEL_BLOCKLIST:
                continue
            if caption in self.SUBMIT_LABELS:
                found.append((item, caption, bool(info.get('form'))))
        return [item for item, _, _ in found]

    def _bound_success_count(self, page: Any, vacancy_id: str) -> int:
        if not is_hh_host(page.url) or _url_vacancy_ids(page.url) != {str(vacancy_id)}:
            return 0
        return page.locator(', '.join(self.SUCCESS_SELECTORS)).evaluate_all(r"""(els, id) => {
            return els.filter(el => {
                if (!el.getClientRects().length || el.closest('[hidden], [aria-hidden="true"]')) return false;
                const card = el.closest('[data-qa="vacancy-serp__vacancy"], [data-qa*="recommendation"], article');
                if (card) {
                    const links = [...card.querySelectorAll('a[href*="/vacancy/"]')];
                    if (!links.some(a => new URL(a.href).pathname === '/vacancy/' + id)) return false;
                }
                const explicit = el.closest('[data-vacancy-id]');
                if (explicit && explicit.getAttribute('data-vacancy-id') !== id) return false;
                return true;
            }).length;
        }""", str(vacancy_id))

    def _safe_diagnostic_label(self, item: Any, tag: str) -> str:
        value = _normalized_label(self._control_label(item, tag))
        labels = set(self.SUBMIT_LABELS) | {'добавить сопроводительное письмо', 'написать сопроводительное', 'чат', 'закрыть', 'отмена'}
        return value if value in labels else ('other' if value else '')
