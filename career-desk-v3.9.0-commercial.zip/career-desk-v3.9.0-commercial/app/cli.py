from __future__ import annotations

import argparse
import json
import sys
import threading
import webbrowser

from .auth import GuidedLoginError, guided_login_and_resume_selection, manual_search_access_check
from .db import Database
from .diagnostics import health_report
from .instance_lock import AlreadyRunningError, SingleInstanceLock
from .legacy import find_legacy_processes, interactive_legacy_guard
from .logging_setup import configure_logging
from .paths import DB_FILE, SETTINGS_FILE
from .edition import EDITION
from .settings import load_settings, save_settings


def command_setup() -> int:
    configure_logging()
    print("Career Desk 3.9.0 - clean safe setup")
    print("No database, approvals, jobs, or browser profile is imported from older agents.")
    if EDITION == "personal":
        interactive_legacy_guard()
    settings = load_settings()
    Database().cancel_stale_work()
    try:
        resume_id = guided_login_and_resume_selection(settings)
    except GuidedLoginError as exc:
        print(f"[FAIL] {exc}")
        print("Run LOGIN_HH_WINDOWS.cmd and keep the dedicated Chromium window open until it finishes.")
        return 2
    if resume_id:
        settings["submit"]["resume_id"] = resume_id
        save_settings(settings)
    report = health_report(settings, Database(), live_search=True)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["result"] != "PASS":
        print("Setup is incomplete. Run DIAGNOSE_WINDOWS.cmd after resolving FAIL items.")
        return 2
    print("Setup completed.")
    return 0


def command_login() -> int:
    settings = load_settings()
    try:
        resume_id = guided_login_and_resume_selection(settings)
    except GuidedLoginError as exc:
        print(f"[FAIL] {exc}")
        return 2
    if resume_id:
        settings["submit"]["resume_id"] = resume_id
        save_settings(settings)
    return 0


def command_update() -> int:
    """Upgrade an existing v3 state without repeating sign-in or live HH checks."""
    if not DB_FILE.is_file() or not SETTINGS_FILE.is_file():
        print("[FAIL] Existing v3 data was not found. Run SETUP_WINDOWS.cmd for first setup.")
        return 2
    lock = SingleInstanceLock()
    try:
        lock.acquire()
    except AlreadyRunningError as exc:
        print(f"[FAIL] {exc}")
        print("Close the running agent, then run UPDATE_WINDOWS.cmd again.")
        return 3
    try:
        load_settings()
        Database()
        print("[PASS] Existing v3 settings, vacancies, letters and history are preserved.")
        print("[INFO] Live HH and Ollama checks were not run by this update command.")
        print("The Windows updater will start the agent now. Use DIAGNOSE_WINDOWS.cmd for live checks.")
        return 0
    finally:
        lock.release()


def command_check_access() -> int:
    try:
        manual_search_access_check(load_settings())
    except GuidedLoginError as exc:
        print(f"[FAIL] {exc}")
        return 2
    return 0


def command_diagnose(live: bool) -> int:
    configure_logging()
    report = health_report(load_settings(), Database(), live_search=live)
    print("Career Desk 3.9.0 diagnostics")
    print("=" * 72)
    for item in report["checks"]:
        print(f"[{item['status']}] {item['name']}: {item['detail']}")
    print("=" * 72)
    print("RESULT:", report["result"])
    print("AUTO SUBMIT CODEPATH: FALSE")
    return 0 if report["result"] == "PASS" else 2


def command_serve() -> int:
    configure_logging()
    legacy = find_legacy_processes() if EDITION == "personal" else []
    if legacy:
        print("Refusing to start while legacy hh agent processes are running:")
        for item in legacy:
            print(f"PID {item.pid}: {item.command}")
        print("Run SETUP_WINDOWS.cmd and approve stopping only the listed legacy processes.")
        return 3
    settings = load_settings()
    db = Database()
    db.cancel_stale_work()
    try:
        import uvicorn
    except ImportError:
        print("Uvicorn is not installed. Run SETUP_WINDOWS.cmd.")
        return 2
    from .webapp import create_app
    lock = SingleInstanceLock()
    try:
        lock.acquire()
    except AlreadyRunningError as exc:
        print(str(exc))
        return 3
    host = settings["ui"]["host"]
    port = int(settings["ui"]["port"])
    threading.Timer(1.2, lambda: webbrowser.open(f"http://{host}:{port}")).start()
    try:
        uvicorn.run(create_app(settings, db), host=host, port=port, log_level="info", workers=1)
    finally:
        lock.release()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hh-ai-recruiter")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("login")
    sub.add_parser("update")
    sub.add_parser("check-access")
    diagnose = sub.add_parser("diagnose")
    diagnose.add_argument("--live", action="store_true")
    sub.add_parser("serve")
    args = parser.parse_args(argv)
    if args.command == "setup":
        return command_setup()
    if args.command == "login":
        return command_login()
    if args.command == "update":
        return command_update()
    if args.command == "check-access":
        return command_check_access()
    if args.command == "diagnose":
        return command_diagnose(args.live)
    if args.command == "serve":
        return command_serve()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
