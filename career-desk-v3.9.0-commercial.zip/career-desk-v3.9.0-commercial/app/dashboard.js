const csrf = "__CSRF__";
let state = null;
let pendingSend = null;
let pendingOverride = null;
let settingsInitialized = false;
let settingsDirty = false;
let resumeDetail = null;
let resumeLoading = false;
let resumeFetchGeneration = 0;
let loading = null;
let selectedVacancy = '';
const expandedCards = new Set();
const batchSelection = new Map();
let pendingBatch = null;
let viewPage = 1;
let viewGeneration = 0;
const noteEdits = new Map();
const filterIds = {query:'filterQuery',city:'filterCity',status:'vacancyFilter',policy:'filterPolicy',salary_min:'filterSalary',salary_mode:'filterSalaryMode',days:'filterDays',fit_min:'filterFit',coverage_min:'filterCoverage',sort:'filterSort'};
const edits = new Map();
const messages = new Map();
const working = new Set();
const byId = id => document.getElementById(id);
const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const itemById = id => state.vacancies.find(v => String(v.id) === String(id));
const locked = v => ['send_queued', 'sending', 'sent', 'verify_on_hh'].includes(v.status);
const allowed = v => v.actions_allowed === true || (v.actions_allowed == null && v.policy_decision !== 'BLOCK' && v.profession_decision === 'ALLOW');
const blockedByRules = v => v.policy_decision === 'BLOCK' || v.profession_decision !== 'ALLOW';
const editable = v => !v.rejected_at && !locked(v) && allowed(v);
const drafting = v => ['queued', 'running'].includes(v.draft_state);

function sendBlockReason(v) {
  if (v.rejected_at) return 'Вакансия отклонена вами.';
  if (locked(v)) return v.status === 'verify_on_hh' ? 'Результат предыдущего отклика нужно проверить на hh.ru. Повтор недоступен.' : (statusNames[v.status] || 'Отправка уже выполняется.');
  if (v.retry_approval_available) return 'Предыдущая попытка остановилась до клика. Нажмите «Повторить одобрение», затем заново подтвердите вакансию и письмо.';
  if (!editable(v)) return 'Отправка недоступна по правилам этой вакансии.';
  if (working.has(String(v.id))) return 'Сохраняю ваше действие…';
  if (edits.has(String(v.id))) return 'Сохраните изменённое письмо и одобрите его точный текст.';
  if (v.letter_error) return v.letter_error;
  if (drafting(v)) return 'Дождитесь подготовки письма или сохраните свой текст вручную.';
  if (!v.vacancy_approved_at) return 'Шаг 1: одобрите вакансию.';
  if (!v.current_hash) return 'Сначала подготовьте и сохраните сопроводительное письмо.';

  if (!v.letter_approved_at || v.approved_hash !== v.current_hash) return 'Шаг 2: одобрите точный текст письма.';
  if (!state.settings.submit.resume_id) return 'Выберите резюме в настройках.';
  if (state.browser?.busy) return 'Браузер занят: ' + state.browser.activity + '. Отправка станет доступна после его освобождения.';
  return '';
}

async function api(path, options = {}) {
  options.headers = Object.assign({'Content-Type':'application/json', 'X-HH-CSRF':csrf}, options.headers || {});
  const response = await fetch(path, options);
  if (!response.ok) {
    let detail = await response.text();
    try { detail = JSON.parse(detail).detail || detail; } catch (_) {}
    throw new Error(typeof detail === 'string' ? detail : 'Запрос не принят. Обновите страницу.');
  }
  return response.json();
}
const post = (path, body) => api(path, {method:'POST', ...(body === undefined ? {} : {body:JSON.stringify(body)})});

function notice(id, text, ok) {
  byId(id).innerHTML = '<div class="' + (ok ? 'ok' : 'error') + '">' + esc(text) + '</div>';
}
function cardNotice(id, text, ok) {
  messages.set(String(id), {text, ok});
  const node = Array.from(byId('vacancyList').querySelectorAll('article')).find(n => n.dataset.id === String(id));
  if (node) node.querySelector('.cardNotice').innerHTML = '<div class="' + (ok ? 'ok' : 'error') + '">' + esc(text) + '</div>';
}

async function load() {
  // One request at a time prevents an older response from replacing newer state.
  if (loading) return loading;
  loading = (async () => {
    const generation = viewGeneration;
    const response = await api(stateUrl());
    if (generation !== viewGeneration) return;
    state = response;
    renderViewControls();
    renderStats();
    renderHealth();
    renderScoutStatus();
    renderDraftStatus();
    renderResumeStatus();
    renderBatchStatus();
    renderVacancies();
    if (!settingsInitialized) { renderSettings(); settingsInitialized = true; }
  })();
  try { await loading; } finally { loading = null; }
}
async function refreshAfterAction() {
  if (loading) await loading;
  await load();
}

function renderStats() {
  const vacancies = state.vacancies;
  byId('sAll').textContent = state.view?.total ?? vacancies.length;
  byId('sReview').textContent = state.view ? (state.view.counts.review || 0) + (state.view.counts.vacancy_approved || 0) : vacancies.filter(v => !v.rejected_at && ['review','vacancy_approved'].includes(v.status)).length;
  byId('sReady').textContent = state.view?.counts.ready_for_final_click || vacancies.filter(v => !v.rejected_at && v.status === 'ready_for_final_click').length;
  byId('sSent').textContent = state.view?.counts.sent || vacancies.filter(v => v.status === 'sent').length;
}
function renderScoutStatus() {
  const scout = state.scout || {};
  byId('searchNow').disabled = !!scout.running || !!state.browser?.busy;
  byId('stopSearch').hidden = !scout.running;
  byId('stopSearch').disabled = !!scout.stopping;
  if (scout.running) {
    const p = scout.progress || {};
    byId('scoutStatus').textContent = scout.stopping ? 'Останавливаю поиск после текущего запроса…' :
      scout.phase === 'analyzing' ? 'Оценка ИИ: ' + (p.done || 0) + ' из ' + (p.total || 0) + '. Одобренные письма уже можно отправлять.' :
      scout.phase === 'fetching' ? 'Читаю вакансии: ' + (p.fetched || 0) + ' из ' + (p.total || 0) + '. Затем браузер освободится для откликов.' : 'Ищу вакансии: выполнено запросов ' + (p.searches || 0) + (p.recommendation_found ? '; из подборки резюме: ' + p.recommendation_found : '') + '.';
    return;
  }
  if (scout.last_error) { notice('scoutStatus', scout.last_error, false); return; }
  const r = scout.last_result;
  if (r) notice('scoutStatus', (r.cancelled ? 'Поиск остановлен. ' : 'Поиск завершён. ') + 'Сохранено: ' + r.saved + '. Из подборки выбранного резюме прочитано: ' + (r.recommendation_found || 0) + '. Заблокировано: ' + r.blocked + '. Пропущено отклонённых: ' + (r.rejected || 0) + '. Ошибок поиска: ' + r.errors + '. Для ' + (r.ai_errors || 0) + ' вакансий Ollama не завершила ответ — использованы программные правила. После двух таких ответов без ИИ оценено ещё: ' + (r.ai_skipped || 0) + '.', r.errors === 0);
}
function renderDraftStatus() {
  const d = state.drafts || {};
  const counts = d.counts || {};
  let text;
  if (!d.enabled) text = 'ИИ отключён. Кнопка «Сгенерировать сопроводительное письмо» работает из сохранённого профиля.';
  else {
    text = d.automatic ? 'Черновики автоматически создаются из профиля без ожидания ИИ. Переработка через Ollama — кнопкой в карточке.' : 'Автоматическая подготовка выключена; доступна кнопка «Сгенерировать сопроводительное письмо».';
    text += ' В очереди: ' + (counts.queued || 0) + ' · Готовится: ' + (counts.running || 0) + ' · Подготовлено: ' + (counts.ready || 0) + ' · Ошибок: ' + (counts.error || 0) + '.';
    if (counts.error) text += ' Причина и повтор создания — в карточке вакансии.';
    if (d.last_error && !counts.error) text += ' ' + d.last_error;
  }
  byId('draftStatus').textContent = text;
  byId('draftStatusOverview').textContent = text;
}
function renderHealth() {
  const health = state.health;
  byId('health').innerHTML = '<div class="badges"><span class="badge allow">AUTO SUBMIT CODEPATH: FALSE</span><span class="badge ' + (health.result === 'PASS' ? 'allow' : 'review') + '">' + esc(health.result) + '</span></div>' + health.checks.map(x => '<div><b>' + esc(x.status) + '</b> · ' + esc(x.name) + ' — <span class="muted">' + esc(x.detail) + '</span></div>').join('');
}

function scoreLabel(v) {
  if (v.score_source === 'ai') return 'Оценка ИИ: Fit ' + v.fit + ' · Coverage ' + v.coverage;
  if (v.score_source === 'rules' && state?.settings?.policy?.profession_mode === 'general' && v.policy_decision !== 'BLOCK') return 'Соответствие требованиям ещё не оценено';
  if (v.score_source === 'rules') return 'По правилам: Fit ' + v.fit + ' · Coverage ' + v.coverage;
  if (v.score_source === 'legacy') return 'Оценка старой версии — обновите поиском';
  return 'Оценка ИИ не выполнялась';
}
const statusNames = {
  review:'К рассмотрению', vacancy_approved:'Вакансия одобрена', ready_for_final_click:'Текст одобрен',
  blocked:'Заблокирована', rejected:'Отклонена вами', send_queued:'Отправка в очереди', sending:'Отправляется',
  sent:'Отклик подтверждён', verify_on_hh:'Проверьте отклик на hh.ru', send_blocked:'Отправка остановлена', send_failed:'Ошибка отправки'
};
function metadata(v) {
  const policy = {ALLOW:'Проверки пройдены', REVIEW:'Нужна проверка', BLOCK:'Заблокирована'}[v.policy_decision] || v.policy_decision;
  return '<a class="vac-title" target="_blank" rel="noreferrer" href="' + esc('https://hh.ru/vacancy/' + encodeURIComponent(v.id)) + '">' + esc(v.name) + '</a>' +
    '<div>' + esc(v.employer) + ' · ' + esc(v.area) + '</div><div class="badges"><span class="badge ' + esc(v.policy_decision.toLowerCase()) + '">' + esc(policy) +
    '</span><span class="badge">' + esc(scoreLabel(v)) + '</span><span class="badge">' + esc(statusNames[v.status] || v.status) + '</span>' + (v.manual_override_active ? '<span class="badge review">Ручное исключение</span>' : '') + '</div>' +
    '<p class="muted">' + esc((v.reasons || []).join('; ')) + '</p>' +
    (v.ai_summary ? '<p class="' + (v.ai_decision === 'ERROR' ? 'error' : 'muted') + '"><b>' + (v.ai_decision === 'ERROR' ? 'Оценка ИИ недоступна: ' : (v.ai_decision === 'NOT_RUN' ? 'Оценка: ' : 'ИИ: ')) + '</b>' + esc(v.ai_summary) + '</p>' : '');
}
function createCard(v) {
  const node = document.createElement('article');
  node.className = 'vacancy';
  node.dataset.id = String(v.id);
  node.innerHTML = '<div class="row-summary"></div><div class="vac-detail" hidden><div class="metadata"></div><details class="evidence-box"><summary>Как получилась оценка</summary><div class="ai-evidence"></div></details><details class="description-box"><summary>Описание вакансии и требования</summary><div class="job-description"></div></details><div class="personal-note"><label>Моя заметка<textarea class="user-note" maxlength="2000" placeholder="Например: уточнить жильё на собеседовании"></textarea></label><button class="btn" data-action="save-note">Сохранить заметку</button></div><div class="rejected-note" hidden>Вы отклонили вакансию. Письма для неё не создаются, отклик недоступен. Решение сохраняется при повторном поиске.</div>' +
    '<div class="editor"><div class="steps"></div><div class="draft-progress" role="status"></div><div class="actions generation-actions"><button class="btn blue" data-action="generate-letter">Сгенерировать сопроводительное письмо</button><button class="btn" data-action="generate-ai-letter">Переписать с ИИ</button></div><p class="generation-help">Генерация из профиля — сразу. ИИ переработает письмо в фоне. Каждый вариант нужно проверить перед отправкой.</p><label class="letter-label">Сопроводительное письмо<textarea class="letter" aria-label="Сопроводительное письмо" placeholder="Здесь появится черновик. Можно написать свой текст."></textarea></label><div class="edit-status"></div></div>' +
    '<div class="send-hint" role="status"></div><div class="submission-note"></div><div class="actions card-actions"><button class="btn" data-action="override-block" hidden>Рассмотреть вопреки блокировке</button><button class="btn" data-action="restart-approval" hidden>Повторить одобрение</button><button class="btn" data-action="approve">Одобрить вакансию</button><button class="btn" data-action="letter">Сохранить письмо</button><button class="btn" data-action="approve-letter">Одобрить точный текст</button><button class="btn red" data-action="send">Отправить отклик</button><button class="btn reject" data-action="reject">Отклонить — не откликаться</button><button class="btn" data-action="restore" hidden>Вернуть к рассмотрению</button></div><div class="cardNotice" role="status"></div></div>';
  node.querySelector('.user-note').addEventListener('input', event => noteEdits.set(String(v.id), event.target.value));
  const textarea = node.querySelector('.letter');
  textarea.addEventListener('input', () => {
    const current = itemById(v.id);
    if (textarea.value === (current.letter_text || '')) edits.delete(String(v.id));
    else edits.set(String(v.id), textarea.value);
    updateCard(node, current);
  });
  return node;
}
function updateCard(node, v) {
  const id = String(v.id), rejected = !!v.rejected_at, dirty = edits.has(id), busy = working.has(id);
  const sendReason = sendBlockReason(v);
  const detail = node.querySelector('.vac-detail');
  detail.hidden = !expandedCards.has(id);
  const summary = node.querySelector('.row-summary');
  summary.innerHTML = '<button class="row-open" data-action="toggle-detail" aria-expanded="' + !detail.hidden + '"><span class="row-title">' + esc(v.name) + '</span><span class="row-company">' + esc(v.employer) + ' · ' + esc(v.area) + '</span><span class="row-facts"><b>' + esc(salaryLabel(v.salary)) + '</b> · ' + esc(dateLabel(v.published_at)) + '</span></button><div class="row-meta"><span class="badge ' + esc(v.policy_decision.toLowerCase()) + '">' + esc(statusNames[v.status] || v.status) + '</span><span class="row-score">' + esc(scoreLabel(v)) + '</span><button class="star" data-action="favorite" aria-pressed="' + !!v.favorite + '" aria-label="Избранное">' + (v.favorite ? '★' : '☆') + '</button></div>';
  node.querySelector('.metadata').innerHTML = metadata(v);
  node.querySelector('.ai-evidence').innerHTML = (v.ai_requirements || []).length ? '<p class="muted">Разбор ИИ из последнего поиска. Сверьте подтверждения с вашим резюме.</p><table><thead><tr><th>Требование</th><th>Совпадение</th><th>Основание по мнению ИИ</th></tr></thead><tbody>' + v.ai_requirements.map(r => '<tr><td>' + esc(r.requirement) + (r.critical ? ' · обязательное' : '') + '</td><td>' + esc({confirmed:'Есть',partial:'Частично',missing:'Не найдено'}[r.verdict] || 'Неизвестно') + '</td><td>' + esc(r.evidence || '—') + '</td></tr>').join('') + '</tbody></table>' : '<p class="muted">Подробный разбор ИИ не сохранён. Он появится после следующего поиска с включённой Ollama. Программные правила перечислены выше.</p>';
  node.querySelector('.job-description').textContent = v.description || 'Описание пока не загружено. Обновите поиск или откройте вакансию на hh.ru.';
  summary.innerHTML += '<div class="quick-actions"><button class="btn" data-action="quick-approve" title="Одобрить только вакансию; письмо проверяется отдельно">' + (v.vacancy_approved_at ? '✓ Вакансия одобрена' : 'Одобрить вакансию') + '</button><button class="btn reject" data-action="quick-reject">Отклонить</button><button class="btn" data-action="quick-restore" hidden>Вернуть</button></div>';
  summary.innerHTML += '<button class="btn" data-action="batch-select" '+((sendBlockReason(v) && !batchSelection.has(id)) ? 'disabled' : '')+'>'+ (batchSelection.has(id) ? '✓ В группе' : 'В группу') +'</button>';
  const note = node.querySelector('.user-note');
  const noteValue = noteEdits.has(id) ? noteEdits.get(id) : (v.user_note || '');
  if (note.value !== noteValue) note.value = noteValue;
  node.querySelector('.rejected-note').hidden = !rejected;
  node.querySelector('.editor').hidden = rejected;
  const textarea = node.querySelector('.letter');
  const desiredText = dirty ? edits.get(id) : (v.letter_text || '');
  // Keep the same textarea node and leave its value/caret alone while typing.
  if (textarea.value !== desiredText) textarea.value = desiredText;
  textarea.disabled = !editable(v) || busy;
  node.querySelector('.edit-status').textContent = dirty ? 'Есть несохранённые изменения. Сохраните письмо перед одобрением и отправкой.' : '';
  node.querySelector('.steps').innerHTML = '<span class="step ' + (v.vacancy_approved_at ? 'done' : '') + '">1 · вакансия</span><span class="step ' + (v.letter_approved_at ? 'done' : '') + '">2 · точный текст</span><span class="step ' + (v.status === 'sent' ? 'done' : '') + '">3 · отправка</span>';
  let progress = '';
  if (v.draft_state === 'queued') progress = v.draft_automatic ? 'Черновик из профиля в очереди. Можно сгенерировать его сразу кнопкой ниже.' : 'Переработка через ИИ в очереди. Генерация из профиля доступна без ожидания.';
  else if (v.draft_state === 'running') progress = v.draft_automatic ? 'Готовлю черновик из профиля…' : 'ИИ готовит письмо и проверяет факты. Для немедленного текста нажмите генерацию из профиля.';
  else if (v.draft_state === 'error') progress = 'ИИ не завершил переработку: ' + (v.draft_error || 'неизвестная ошибка') + (v.letter_text ? ' Сохранённый текст оставлен в поле.' : ' Можно сгенерировать письмо из профиля кнопкой ниже.');
  else if (v.letter_text) progress = (v.letter_source === 'profile' ? 'Черновик из вашего профиля.' : v.letter_source === 'ai' ? 'Черновик подготовлен и проверен через ИИ.' : 'Текст сохранён.') + ' Проверьте его перед одобрением.';
  else if (!editable(v)) progress = 'Подготовка письма недоступна для этой вакансии.';
  else if (state.settings.ai.enabled && state.settings.ai.auto_draft_letters !== false) progress = 'Черновик будет подготовлен автоматически.';
  else progress = 'Нажмите «Сгенерировать сопроводительное письмо» или напишите свой текст.';
  if (v.letter_note) progress += ' ' + v.letter_note;
  node.querySelector('.draft-progress').textContent = progress;
  node.querySelector('.send-hint').textContent = sendReason || 'Вакансия и письмо одобрены. Нажмите «Отправить отклик» для финального подтверждения.';
  node.querySelector('.submission-note').textContent = v.submission_error ? 'Предыдущая попытка: ' + v.submission_error : '';
  node.querySelectorAll('[data-action]').forEach(button => {
    const action = button.dataset.action.replace(/^quick-/, '');
    if (action === 'batch-select') { button.disabled = !!sendBlockReason(v) && !batchSelection.has(id); return; }
    if (['favorite','toggle-detail','save-note'].includes(action)) { button.disabled = busy; return; }
    if (rejected) button.hidden = action !== 'restore';
    else if (action === 'restore') button.hidden = true;
    else if (action === 'override-block') button.hidden = !blockedByRules(v) || !!v.manual_override_active || locked(v);
    else if (action === 'restart-approval') button.hidden = !v.retry_approval_available;
    else button.hidden = false;
    if (action === 'reject' || action === 'restore') button.disabled = locked(v) || busy;
    else if (action === 'override-block') button.disabled = busy || locked(v) || !blockedByRules(v);
    else if (action === 'restart-approval') button.disabled = busy || !v.retry_approval_available;
    else if (action === 'approve') button.disabled = !editable(v) || busy || !!v.vacancy_approved_at;
    else if (action === 'generate-letter') {
      button.disabled = !editable(v) || busy || dirty;
      button.textContent = v.letter_text ? 'Сгенерировать письмо заново' : 'Сгенерировать сопроводительное письмо';
      button.title = dirty ? 'Сохраните свой текст перед заменой.' : 'Создать письмо из профиля сразу, без ожидания Ollama.';
    } else if (action === 'generate-ai-letter') {
      button.disabled = !editable(v) || busy || dirty || v.draft_state === 'running' || !state.settings.ai.enabled;
      button.textContent = v.draft_state === 'queued' && !v.draft_automatic ? 'Поднять запрос ИИ в очереди' : 'Переписать с ИИ';
    } else if (action === 'letter') button.disabled = !editable(v) || busy || !dirty;
    else if (action === 'approve-letter') button.disabled = !editable(v) || busy || dirty || drafting(v) || !!v.letter_error || !v.vacancy_approved_at || !v.current_hash || v.approved_hash === v.current_hash;
    else if (action === 'send') { button.disabled = !!sendReason; button.title = sendReason || 'Открыть финальное подтверждение'; }
  });
  const message = messages.get(id);
  node.querySelector('.cardNotice').innerHTML = message ? '<div class="' + (message.ok ? 'ok' : 'error') + '">' + esc(message.text) + '</div>' : '';
}
function renderVacancies() {
  const root = byId('vacancyList'), mode = byId('vacancyFilter').value;
  const rows = state.view ? state.vacancies : state.vacancies.filter(v => mode === 'all' || (mode === 'rejected' ? !!v.rejected_at : !v.rejected_at && v.status !== 'sent'));
  const keep = new Set(rows.map(v => String(v.id)));
  root.querySelectorAll('article').forEach(node => { if (!keep.has(node.dataset.id)) node.remove(); });
  const empty = root.querySelector('.empty-list');
  if (empty) empty.remove();
  rows.forEach((v, index) => {
    let node = Array.from(root.querySelectorAll('article')).find(n => n.dataset.id === String(v.id));
    if (!node) node = createCard(v);
    updateCard(node, v);
    if (root.children[index] !== node) root.insertBefore(node, root.children[index] || null);
  });
  byId('vacancyCount').textContent = state.view ? 'Найдено ' + state.view.filtered + ' из ' + state.view.total + ' · на странице ' + rows.length : 'Показано: ' + rows.length;
  if (!rows.length) {
    const p = document.createElement('p');
    p.className = 'muted empty-list';
    p.textContent = mode === 'rejected' ? 'Отклонённых вакансий нет.' : 'В этом списке пока нет вакансий.';
    root.appendChild(p);
  }
}

byId('vacancyList').addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button || button.disabled) return;
  const node = button.closest('article'), id = node.dataset.id, action = button.dataset.action.replace(/^quick-/, ''), v = itemById(id);
  if (action === 'toggle-detail') {
    if (expandedCards.has(id)) expandedCards.delete(id); else expandedCards.add(id);
    selectedVacancy = expandedCards.has(id) ? id : '';
    renderVacancies(); return;
  }
  if (action === 'batch-select') {
    if (batchSelection.has(id)) batchSelection.delete(id);
    else if (!sendBlockReason(v)) batchSelection.set(id,{id,content_hash:v.content_hash,letter_sha256:v.current_hash});
    renderVacancies(); renderBatchStatus(); return;
  }
  if (action === 'favorite' || action === 'save-note') {
    try {
      await post('/api/vacancies/' + id + '/annotate', action === 'favorite' ? {favorite:!v.favorite} : {note:node.querySelector('.user-note').value});
      if (action === 'save-note') { noteEdits.delete(id); cardNotice(id, 'Заметка сохранена.', true); }
      await refreshAfterAction();
    } catch (error) { notice('notice', error.message, false); }
    return;
  }
  if (action === 'send') {
    pendingSend = {id, letterHash:v.current_hash, contentHash:v.content_hash};
    byId('sendTitle').textContent = v.name + ' — ' + v.employer + ' · ' + v.area;
    byId('sendLetter').textContent = v.letter_text;
    byId('sendLength').textContent = v.letter_text.length + ' символов · одобренный текст';
    byId('sendDialog').showModal();
    return;
  }
  if (action === 'override-block') {
    pendingOverride = {id, contentHash:v.content_hash};
    byId('overrideTitle').textContent = v.name + ' — ' + v.employer;
    byId('overrideDialog').showModal();
    return;
  }
  if (working.has(id)) return;
  working.add(id); updateCard(node, v);
  try {
    let body;
    if (action === 'letter') body = {text:node.querySelector('.letter').value};
    if (action === 'approve') body = {content_hash:v.content_hash};
    if (action === 'approve-letter') body = {sha256:v.current_hash};
    if (action === 'generate-letter' || action === 'generate-ai-letter') body = {content_hash:v.content_hash, letter_sha256:v.current_hash || null};
    const result = await post('/api/vacancies/' + id + '/' + action, body);
    if (action === 'letter' || action === 'reject') edits.delete(id);
    if (['reject','restore','restart-approval'].includes(action)) batchSelection.delete(id);
    const text = {approve:'Вакансия одобрена.', letter:'Письмо сохранено. Одобрите точный текст после проверки.', 'generate-letter':'Письмо создано из профиля. Проверьте и одобрите точный текст.', 'generate-ai-letter':'Переработка через ИИ поставлена в начало очереди.', 'approve-letter':'Точный текст одобрен.', 'restart-approval':'Согласование начато заново. Одобрите вакансию и точный текст ещё раз.', reject:'Вакансия отклонена. Она доступна в списке «Отклонённые».', restore:'Вакансия возвращена к рассмотрению. Одобрения нужно дать заново.'}[action];
    cardNotice(id, result.message || text, true);
    if (['approve','reject','restore','restart-approval'].includes(action)) notice('notice', result.message || text, true);
  } catch (error) { cardNotice(id, error.message, false); if (!expandedCards.has(id)) notice('notice', error.message, false); }
  finally { working.delete(id); await refreshAfterAction().catch(error => notice('notice', error.message, false)); }
});
function salaryLabel(salary) {
  if (!salary || (salary.from == null && salary.to == null)) return 'Зарплата не указана';
  const n = value => Number(value).toLocaleString('ru-RU');
  const range = salary.from != null && salary.to != null ? n(salary.from) + '–' + n(salary.to) : salary.from != null ? 'от ' + n(salary.from) : 'до ' + n(salary.to);
  return range + ' ' + (['RUR','RUB'].includes(salary.currency) ? '₽' : salary.currency || '') + (salary.gross === true ? ' до налогов' : salary.gross === false ? ' на руки' : ' · налоги не уточнены');
}
function dateLabel(value) {
  const parsed = value ? new Date(value) : null;
  return parsed && !Number.isNaN(parsed.getTime()) ? 'Опубликована ' + parsed.toLocaleDateString('ru-RU') : 'Дата не указана';
}
function stateUrl() {
  const params = [];
  Object.entries(filterIds).forEach(([key,id]) => {
    const value = byId(id)?.value;
    if (value && !(key === 'status' && value === 'active') && !(key === 'sort' && value === 'recommended') && !(key === 'salary_mode' && value === 'any')) params.push(key + '=' + encodeURIComponent(value));
  });
  if (byId('filterFavorite')?.checked) params.push('favorite=1');
  if (viewPage > 1) params.push('page=' + viewPage);
  return '/api/state' + (params.length ? '?' + params.join('&') : '');
}
function renderViewControls() {
  if (!state.view) return;
  viewPage = state.view.page;
  byId('pageLabel').textContent = viewPage + ' / ' + state.view.pages;
  byId('previousPage').disabled = viewPage <= 1;
  byId('nextPage').disabled = viewPage >= state.view.pages;
  const city = byId('filterCity'), saved = city.value;
  city.innerHTML = '<option value="">Все города</option><option value="@spb">Только Санкт-Петербург</option>' + state.view.cities.map(name => '<option value="' + esc(name) + '">' + esc(name) + '</option>').join('');
  // A saved city absent from this DB should remain an explicit empty-result filter.
  if (saved && saved !== '@spb' && !state.view.cities.includes(saved)) city.innerHTML += '<option value="' + esc(saved) + '">' + esc(saved) + '</option>';
  city.value = saved;
}
async function changeView(resetPage = true) {
  if (resetPage) viewPage = 1;
  viewGeneration++;
  try {
    const saved = Object.fromEntries(Object.values(filterIds).map(id => [id,byId(id).value]));
    saved.filterFavorite = byId('filterFavorite').checked;
    window.localStorage?.setItem('hh-view-v1', JSON.stringify(saved));
  } catch (_) {}
  await refreshAfterAction().catch(error => notice('notice', error.message, false));
}
Object.values(filterIds).forEach(id => byId(id).addEventListener('change', () => changeView()));
byId('filterFavorite').addEventListener('change', () => changeView());
byId('applyFilters').onclick = () => changeView();
byId('filterQuery').addEventListener('keydown', event => { if (event.key === 'Enter') changeView(); });
byId('clearFilters').onclick = () => {
  Object.values(filterIds).forEach(id => { byId(id).value = ''; });
  byId('vacancyFilter').value = 'active'; byId('filterSort').value = 'recommended'; byId('filterSalaryMode').value = 'any';
  byId('filterFavorite').checked = false; changeView();
};
byId('previousPage').onclick = () => { if (viewPage > 1) { viewPage--; changeView(false); } };
byId('nextPage').onclick = () => { if (viewPage < (state.view?.pages || 1)) { viewPage++; changeView(false); } };
try {
  const saved = JSON.parse(window.localStorage?.getItem('hh-view-v1') || '{}');
  Object.values(filterIds).forEach(id => { if (typeof saved[id] === 'string') byId(id).value = saved[id]; });
  byId('filterFavorite').checked = saved.filterFavorite === true;
} catch (_) {}


// Back-to-top for the vacancy list: it runs to hundreds of cards, and the
// approval controls sit at the bottom of each one.
function updateBackToTop() {
  const button = byId('backToTop');
  if (!button) return;
  const onVacancies = byId('vacancies') && byId('vacancies').classList
    && byId('vacancies').classList.contains('active');
  const scrolled = (typeof window !== 'undefined' ? (window.scrollY || 0) : 0) > 400;
  button.hidden = !(onVacancies && scrolled);
}
if (typeof window !== 'undefined' && window.addEventListener) {
  window.addEventListener('scroll', updateBackToTop, {passive: true});
}
if (byId('backToTop')) {
  byId('backToTop').onclick = () => {
    if (typeof window !== 'undefined' && window.scrollTo) {
      window.scrollTo({top: 0, behavior: 'smooth'});
    }
    updateBackToTop();
  };
}
byId('stopSearch').onclick = async () => {
  try { const result = await post('/api/search/stop'); notice('notice', result.message, true); await refreshAfterAction(); }
  catch (error) { notice('notice', error.message, false); }
};
function renderSettings() {
  const s = state.settings;
  const values = {professionMode:s.policy.profession_mode || 'general',candidateName:s.candidate.full_name || '', candidateHeadline:s.candidate.headline || '', candidateYears:s.candidate.years_experience || 0, candidateAchievements:(s.candidate.achievements || []).join('\n'), salaryMin:s.candidate.public_salary_min, salaryTarget:s.candidate.internal_salary_target,
    profile:s.candidate.profile, queries:s.search.queries.join('\n'), stopCompanies:s.policy.stop_companies.join('\n'),
    model:s.ai.model, resumeId:s.submit.resume_id, schedule:s.search.schedule_local, aiTimeout:s.ai.timeout_seconds,
    resumeRecommendationPages:s.search.resume_recommendation_pages || 3, searchDays:s.search.days || 1, searchPerQuery:s.search.per_query || 20,
    promptA:s.ai.profession_prompt, promptB:s.ai.fit_prompt, promptC:s.ai.letter_prompt, promptD:s.ai.critic_prompt};
  Object.entries(values).forEach(([id, value]) => { byId(id).value = value; });
  byId('aiEnabled').checked = s.ai.enabled;
  byId('autoDraftLetters').checked = s.ai.auto_draft_letters !== false;
  byId('resumeRecommendations').checked = s.search.resume_recommendations !== false;
  byId('regions').innerHTML = '';
  s.search.regions.forEach(addRegionRow);
}
function addRegionRow(r = {name:'',area_id:'',priority:30,relocation:'review',enabled:true}) {
  const row = document.createElement('div'); row.className = 'region';
  row.innerHTML = '<input class="rName" placeholder="Регион" value="' + esc(r.name) + '"><input class="rId" placeholder="HH area ID или пусто" value="' + esc(r.area_id) + '"><input class="rPriority" type="number" min="0" max="100" value="' + esc(r.priority) + '"><label class="enabled"><input class="rEnabled" type="checkbox">Вкл</label><select class="rRel"><option value="not_required">Без релокации</option><option value="review">Показать мне</option><option value="package_or_housing">Пакет/жильё</option><option value="full_package">Полный пакет</option></select><button class="btn remove" aria-label="Удалить регион">×</button>';
  row.querySelector('.rRel').value = r.relocation;
  row.querySelector('.rEnabled').checked = r.enabled !== false;
  row.querySelector('.remove').onclick = () => row.remove();
  byId('regions').appendChild(row);
}
byId('addRegion').onclick = () => addRegionRow();
byId('saveSettings').onclick = async () => {
  try {
    const s = JSON.parse(JSON.stringify(state.settings));
    s.candidate.public_salary_min = Number(byId('salaryMin').value);
    s.candidate.internal_salary_target = Number(byId('salaryTarget').value);
    s.candidate.profile = byId('profile').value;
    s.candidate.full_name = byId('candidateName').value.trim();
    s.candidate.headline = byId('candidateHeadline').value.trim();
    s.candidate.years_experience = Number(byId('candidateYears').value);
    s.candidate.achievements = lines('candidateAchievements');
    s.search.queries = byId('queries').value.split('\n').map(x => x.trim()).filter(Boolean);
    s.policy.profession_mode = byId('professionMode').value;
  s.policy.stop_companies = byId('stopCompanies').value.split('\n').map(x => x.trim()).filter(Boolean);
    s.ai.model = byId('model').value.trim();
    s.ai.enabled = byId('aiEnabled').checked;
    s.ai.auto_draft_letters = byId('autoDraftLetters').checked;
    s.ai.timeout_seconds = Number(byId('aiTimeout').value);
    s.submit.resume_id = byId('resumeId').value.trim();
    s.search.schedule_local = byId('schedule').value;
    s.search.days = Number(byId('searchDays').value);
    s.search.per_query = Number(byId('searchPerQuery').value);
    s.search.resume_recommendations = byId('resumeRecommendations').checked;
    s.search.resume_recommendation_pages = Number(byId('resumeRecommendationPages').value);
    ['profession_prompt','fit_prompt','letter_prompt','critic_prompt'].forEach((key, i) => { s.ai[key] = byId(['promptA','promptB','promptC','promptD'][i]).value; });
    s.search.regions = Array.from(document.querySelectorAll('.region')).map(row => ({name:row.querySelector('.rName').value,area_id:row.querySelector('.rId').value,priority:Number(row.querySelector('.rPriority').value),relocation:row.querySelector('.rRel').value,enabled:row.querySelector('.rEnabled').checked}));
    await post('/api/settings', s);
    settingsDirty = false;
    settingsInitialized = false;
    await refreshAfterAction(); notice('settingsNotice','Настройки сохранены.',true);
  } catch (error) { notice('settingsNotice',error.message,false); }
};
document.querySelectorAll('nav button').forEach(button => {
  button.onclick = () => {
    document.querySelectorAll('nav button,.tab').forEach(node => node.classList.remove('active'));
    button.classList.add('active'); byId(button.dataset.tab).classList.add('active');
    updateBackToTop();
    load().catch(error => notice('notice',error.message,false));
  };
});
byId('searchNow').onclick = async () => {
  try { const result = await post('/api/search'); notice('notice', result.message, true); await refreshAfterAction(); }
  catch (error) { notice('notice',error.message,false); }
};
byId('downloadLog').onclick = () => { location.href = '/api/export/log'; };
byId('downloadDiag').onclick = () => { location.href = '/api/export/diagnostics'; };
byId('cancelSend').onclick = () => { pendingSend = null; byId('sendDialog').close(); };
byId('sendDialog').addEventListener('cancel', () => { pendingSend = null; });
byId('cancelOverride').onclick = () => { pendingOverride = null; byId('overrideDialog').close(); };
byId('overrideDialog').addEventListener('cancel', () => { pendingOverride = null; });
byId('confirmOverride').onclick = async () => {
  if (!pendingOverride) return;
  const target = pendingOverride; pendingOverride = null; byId('overrideDialog').close();
  try {
    const current = itemById(target.id);
    if (!current || current.content_hash !== target.contentHash) throw new Error('Вакансия изменилась. Проверьте карточку заново.');
    const result = await post('/api/vacancies/' + target.id + '/override-block', {
      content_hash:target.contentHash,
      acknowledgement:'Я проверил вакансию и хочу рассмотреть её вручную'
    });
    cardNotice(target.id, result.message, true);
    await refreshAfterAction();
  } catch (error) { cardNotice(target.id, error.message, false); }
};
byId('confirmSend').onclick = async () => {
  if (!pendingSend) return;
  const target = pendingSend; pendingSend = null; byId('sendDialog').close();
  try {
    const current = itemById(target.id);
    if (edits.has(target.id) || !current || current.current_hash !== target.letterHash || current.content_hash !== target.contentHash) throw new Error('Вакансия или письмо изменились. Проверьте карточку заново.');
    const block = sendBlockReason(current);
    if (block) throw new Error(block);
    await post('/api/vacancies/' + target.id + '/send', {letter_sha256:target.letterHash, content_hash:target.contentHash});
    notice('notice','Отправка запущена. Дождитесь подтверждения результата в карточке.',true);
    await refreshAfterAction();
  } catch (error) { notice('notice',error.message,false); }
};
window.addEventListener('beforeunload', event => {
  if (edits.size || noteEdits.size) { event.preventDefault(); event.returnValue = ''; }
});
load().catch(error => notice('notice',error.message,false));
setInterval(() => {
  if (document.visibilityState === 'visible') load().catch(() => {});
}, 3000);


// Resume previews have their own revision; polling never overwrites edited fields.
const resumePromptKeys = ['profession_prompt','fit_prompt','letter_prompt','critic_prompt'];
const lines = id => byId(id).value.split('\n').map(x => x.trim()).filter(Boolean);
byId('settings').addEventListener('input', event => {
  if (!event.target.closest('.resume-panel')) settingsDirty = true;
});
function renderResumeStatus() {
  const r = state?.resume_workspace || {};
  const phases = {uploaded:'Резюме загружено. Нажмите «Генерировать».',running:'Анализ через Ollama: ',ready:r.applied ? 'Выбранные настройки применены.' : 'Результат готов к проверке.',error:'Анализ не завершён.',interrupted:'Анализ прерван.'};
  byId('resumeStatus').textContent = (r.phase ? phases[r.phase] || r.phase : 'Резюме ещё не загружено.') +
    (r.phase === 'running' ? (r.progress?.total ? 'часть '+r.progress.part+' из '+r.progress.total+'. ' : 'ожидание модели. ') : ' ') + (r.error || '');
  byId('generateResume').disabled = !r.characters || r.phase === 'running' || resumeLoading;
  byId('clearResume').disabled = !r.characters || resumeLoading;
  if (r.revision && !resumeLoading && (resumeDetail?.revision !== r.revision || (r.phase === 'ready' && !resumeDetail?.result))) {
    fetchResumeDetail().catch(error => notice('resumeNotice',error.message,false));
  }
}
async function fetchResumeDetail() {
  if (resumeLoading) return;
  resumeLoading = true;
  const generation = resumeFetchGeneration;
  try {
    const result = await api('/api/resume');
    if (generation !== resumeFetchGeneration) return;
    resumeDetail = result;
    byId('resumeSourceBox').hidden = !result.text;
    byId('resumeSource').value = result.text || '';
    byId('resumeResult').hidden = !result.result;
    if (result.result) {
      const r = result.result;
      const values = {resumeName:r.candidate.full_name,resumeHeadline:r.candidate.headline,resumeYears:r.candidate.years_experience,
        resumeProfile:r.candidate.profile,resumeFacts:r.candidate.achievements.join('\n'),resumeQueries:r.queries.join('\n'),resumeImproved:r.improved_resume};
      resumePromptKeys.forEach((key,i) => { values[['resumePromptA','resumePromptB','resumePromptC','resumePromptD'][i]] = r.prompts[key]; });
      Object.entries(values).forEach(([id,value]) => { byId(id).value = value; });
      ['resumeUseProfile','resumeUseQueries','resumeUsePrompts'].forEach(id => { byId(id).checked = true; });
      byId('resumeCriteria').innerHTML = '<ul>'+r.criteria.map(x => '<li>'+esc(x)+'</li>').join('')+'</ul>';
      byId('resumeChanges').innerHTML = r.edits.length ? r.edits.map(e => '<p><b>Было:</b> '+esc(e.before)+'<br><b>Предложено:</b> '+esc(e.after)+'<br><span class="muted">'+esc(e.reason)+'</span></p>').join('') : '<p>Точечные правки не предложены. Исходный текст сохранён.</p>';
      byId('resumeQuestions').innerHTML = '<h4>Что уточнить</h4><ul>'+r.questions.map(x => '<li>'+esc(x)+'</li>').join('')+'</ul>'+(r.discarded_unverified ? '<p>Неподтверждённых фрагментов ИИ исключено: '+r.discarded_unverified+'.</p>' : '');
      byId('resumeSample').textContent = r.sample_letter;
    }
    byId('applyResume').disabled = result.applied === true;
  } finally { resumeLoading = false; }
}
async function uploadResume(body, extension) {
  try {
    if (body.size > 5*1024*1024) throw new Error('Максимальный размер — 5 МБ.');
    resumeFetchGeneration++;
    await api('/api/resume/upload?filename=resume.'+encodeURIComponent(extension), {method:'POST',headers:{'Content-Type':'application/octet-stream'},body});
    resumeDetail = null;
    await refreshAfterAction();
    notice('resumeNotice','Текст прочитан. Проверьте его и нажмите «Генерировать».',true);
  } catch (error) { notice('resumeNotice',error.message,false); }
}
byId('resumeFile').onchange = async event => {
  const file = event.target.files?.[0];
  if (file) await uploadResume(file,file.name.split('.').pop().toLowerCase());
  event.target.value = '';
};
byId('uploadResumeText').onclick = () => uploadResume(new Blob([byId('resumePaste').value],{type:'text/plain'}),'txt');
byId('generateResume').onclick = async () => {
  try {
    if (settingsDirty) throw new Error('Сначала сохраните изменённые настройки внизу страницы.');
    resumeFetchGeneration++;
    await post('/api/resume/generate');
    resumeDetail = null;
    byId('resumeResult').hidden = true;
    await refreshAfterAction();
    notice('resumeNotice','Анализ запущен. Большое резюме обрабатывается частями. Можно продолжать работу с вакансиями.',true);
  } catch (error) { notice('resumeNotice',error.message,false); }
};
byId('clearResume').onclick = async () => {
  try {
    resumeFetchGeneration++;
    await post('/api/resume/clear');
    resumeDetail = null; byId('resumeResult').hidden = true; byId('resumeSourceBox').hidden = true;
    byId('resumeSource').value = ''; byId('resumePaste').value = '';
    await refreshAfterAction(); notice('resumeNotice','Загруженный текст и анализ удалены. Применённые настройки сохранены.',true);
  } catch (error) { notice('resumeNotice',error.message,false); }
};
byId('applyResume').onclick = async () => {
  try {
    if (settingsDirty) throw new Error('Сначала сохраните изменённые настройки. Затем повторите генерацию.');
    if (!resumeDetail?.result) throw new Error('Дождитесь результата анализа.');
    const prompts = {};
    resumePromptKeys.forEach((key,i) => { prompts[key] = byId(['resumePromptA','resumePromptB','resumePromptC','resumePromptD'][i]).value; });
    await post('/api/resume/apply',{revision:resumeDetail.revision,
      use_profile:byId('resumeUseProfile').checked,use_queries:byId('resumeUseQueries').checked,use_prompts:byId('resumeUsePrompts').checked,
      candidate:{full_name:byId('resumeName').value.trim(),headline:byId('resumeHeadline').value.trim(),years_experience:Number(byId('resumeYears').value),profile:byId('resumeProfile').value,achievements:lines('resumeFacts')},
      queries:lines('resumeQueries'),prompts});
    settingsInitialized = false;
    byId('applyResume').disabled = true;
    await refreshAfterAction();
    notice('resumeNotice','Применено. Запустите поиск для новой оценки; в карточках можно сгенерировать письма из обновлённого профиля.',true);
  } catch (error) { notice('resumeNotice',error.message,false); }
};
byId('downloadResume').onclick = () => {
  const url = URL.createObjectURL(new Blob([byId('resumeImproved').value],{type:'text/plain;charset=utf-8'}));
  const link = document.createElement('a');link.href=url;link.download='resume-reviewed-draft.txt';link.click();
  setTimeout(() => URL.revokeObjectURL(url),1000);
};

function renderBatchStatus() {
  const b = state?.batch || {};
  byId('previewBatch').textContent = 'Отправить выбранные ('+batchSelection.size+')';
  byId('previewBatch').disabled = !batchSelection.size || !!b.running || !!state?.browser?.busy;
  byId('stopBatch').disabled = !b.running;
  byId('batchStatus').textContent = (b.running ? (b.stopping ? 'Группа останавливается. ' : 'Группа выполняется. ') : '') + (b.error || '') +
    (b.items || []).map(x => x.id+': '+({queued:'в очереди',running:'в работе',confirmed:'отправлено',unknown:'нужна проверка',failed:'ошибка',blocked:'остановлено',cancelled:'отменено'}[x.state] || 'ожидание')).join(' · ');
  const license = state?.license || {};
  byId('licensePanel').hidden = license.edition !== 'commercial';
  byId('licenseDevice').value = license.device || '';
  byId('licenseState').textContent = license.active ? 'Лицензия активна'+(license.expires ? ' до '+new Date(license.expires*1000).toLocaleDateString('ru-RU') : '') : (license.message || 'Нужна активация');
}
byId('clearBatchSelection').onclick = () => {batchSelection.clear();renderVacancies();renderBatchStatus();};
byId('previewBatch').onclick = async () => {
  try {
    const result = await post('/api/batch/preview',{items:Array.from(batchSelection.values())});
    pendingBatch = result.items;
    byId('batchPreview').innerHTML = result.items.map(x => '<h3>'+esc(x.title)+'</h3><pre style="white-space:pre-wrap">'+esc(x.letter)+'</pre>').join('<hr>');
    byId('batchDialog').showModal();
  } catch (e) {notice('notice',e.message,false);}
};
byId('cancelBatch').onclick = () => {pendingBatch=null;byId('batchDialog').close();};
byId('confirmBatch').onclick = async () => {
  if (!pendingBatch) return;
  byId('confirmBatch').disabled = true;
  try {
    await post('/api/batch/send',{items:pendingBatch,workers:Number(byId('batchWorkers').value)});
    pendingBatch=null;batchSelection.clear();byId('batchDialog').close();await refreshAfterAction();
  } catch (e) {notice('notice',e.message,false);byId('batchDialog').close();}
  finally {byId('confirmBatch').disabled=false;}
};
byId('stopBatch').onclick = async () => {try {await post('/api/batch/stop');await refreshAfterAction();}catch(e){notice('notice',e.message,false);}};
byId('activateLicense').onclick = async () => {
  try {await post('/api/license/activate',{token:byId('licenseToken').value.trim()});byId('licenseToken').value='';await refreshAfterAction();notice('licenseNotice','Лицензия активирована.',true);}
  catch(e){notice('licenseNotice',e.message,false);}
};
