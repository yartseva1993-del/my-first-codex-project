from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .paths import AUDIT_FILE, DB_FILE, ensure_directories
from .letters import LetterPolicyError, validate_cover_letter, validate_no_placeholders
from .ranking import VACANCY_ORDER, city_priority


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def letter_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def vacancy_content_hash(vacancy: dict[str, Any]) -> str:
    employer = vacancy.get("employer") or {}
    area = vacancy.get("area") or {}
    skills = vacancy.get("key_skills") or []
    content_basis = {
        "id": str(vacancy.get("id") or ""),
        "name": vacancy.get("name"),
        "description": vacancy.get("description"),
        "employer": {"id": employer.get("id"), "name": employer.get("name")},
        "area": {"id": area.get("id"), "name": area.get("name")},
        "salary": vacancy.get("salary"),
        "key_skills": [{"name": item.get("name")} for item in skills if isinstance(item, dict)],
        "alternate_url": vacancy.get("alternate_url"),
        "apply_alternate_url": vacancy.get("apply_alternate_url"),
        "archived": vacancy.get("archived"),
        "has_test": vacancy.get("has_test"),
    }
    return hashlib.sha256(json.dumps(content_basis, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def manual_override_active(row: Any) -> bool:
    """Whether the user override still belongs to this exact vacancy text."""
    try:
        return bool(
            row["manual_override_at"]
            and row["manual_override_hash"]
            and row["manual_override_hash"] == row["content_hash"]
        )
    except (KeyError, IndexError, TypeError):
        return False


def vacancy_actions_allowed(row: Any) -> bool:
    """Apply immutable rules unless the user made an audited one-card exception."""
    try:
        allowed_by_rules = row["policy_decision"] != "BLOCK" and row["profession_decision"] == "ALLOW"
    except (KeyError, IndexError, TypeError):
        return False
    return allowed_by_rules or manual_override_active(row)


class StateError(RuntimeError):
    pass


class _ClosingConnection(sqlite3.Connection):
    """A SQLite connection whose context manager also closes the file handle.

    ``sqlite3.Connection.__exit__`` commits or rolls back, but it does not close
    the connection.  That difference is easy to miss and prevents temporary
    database files from being removed on Windows (WinError 32).  Keep the
    familiar ``with db.connect()`` API while making its lifetime unambiguous.
    """

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> bool | None:
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


class Database:
    def __init__(self, path: Path = DB_FILE, audit_file: Path = AUDIT_FILE):
        self.path = Path(path)
        self.audit_file = Path(audit_file)
        if self.path == DB_FILE or self.audit_file == AUDIT_FILE:
            ensure_directories()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.audit_file.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.init_schema()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self.path,
            timeout=30,
            isolation_level=None,
            check_same_thread=False,
            factory=_ClosingConnection,
        )
        try:
            conn.row_factory = sqlite3.Row
            conn.create_function("hh_city_priority", 1, city_priority, deterministic=True)
            conn.create_function("hh_casefold", 1, lambda x: str(x or "").casefold(), deterministic=True)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=30000")
        except Exception:
            conn.close()
            raise
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                yield conn
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            finally:
                conn.close()

    def init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS vacancies (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    employer TEXT NOT NULL DEFAULT '',
                    area TEXT NOT NULL DEFAULT '',
                    url TEXT NOT NULL DEFAULT '',
                    apply_url TEXT NOT NULL DEFAULT '',
                    raw_json TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    policy_decision TEXT NOT NULL,
                    profession_decision TEXT NOT NULL,
                    fit INTEGER NOT NULL DEFAULT 0,
                    coverage INTEGER NOT NULL DEFAULT 0,
                    reasons TEXT NOT NULL DEFAULT '[]',
                    ai_decision TEXT NOT NULL DEFAULT 'NOT_RUN',
                    ai_summary TEXT NOT NULL DEFAULT '',
                    discovered_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    vacancy_approved_at TEXT,
                    vacancy_approval_version INTEGER NOT NULL DEFAULT 0,
                    manual_override_at TEXT,
                    manual_override_hash TEXT NOT NULL DEFAULT '',
                    manual_override_version INTEGER NOT NULL DEFAULT 0,
                    approval_reset_attempt_id TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'review'
                );
                CREATE TABLE IF NOT EXISTS letters (
                    vacancy_id TEXT PRIMARY KEY REFERENCES vacancies(id) ON DELETE CASCADE,
                    text TEXT NOT NULL,
                    current_hash TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    approved_at TEXT,
                    approved_hash TEXT,
                    approval_version INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS submissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    attempt_id TEXT NOT NULL UNIQUE,
                    vacancy_id TEXT NOT NULL REFERENCES vacancies(id),
                    letter_hash TEXT NOT NULL,
                    vacancy_approval_version INTEGER NOT NULL,
                    letter_approval_version INTEGER NOT NULL,
                    state TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    result TEXT NOT NULL DEFAULT '',
                    error TEXT NOT NULL DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS audit (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    at TEXT NOT NULL,
                    event TEXT NOT NULL,
                    vacancy_id TEXT,
                    attempt_id TEXT,
                    details TEXT NOT NULL DEFAULT '{}'
                );
                CREATE TABLE IF NOT EXISTS letter_drafts (
                    vacancy_id TEXT PRIMARY KEY REFERENCES vacancies(id) ON DELETE CASCADE,
                    state TEXT NOT NULL,
                    claim_id TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    expected_letter_hash TEXT,
                    automatic INTEGER NOT NULL DEFAULT 1,
                    requested_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    error TEXT NOT NULL DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS resume_identity (
                    resume_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    checked_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_vacancies_status ON vacancies(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_submissions_vacancy ON submissions(vacancy_id, created_at DESC);
                CREATE UNIQUE INDEX IF NOT EXISTS idx_one_live_submission
                    ON submissions(vacancy_id)
                    WHERE state IN ('queued','running','confirmed','unknown');
                """
            )
        # Additive, idempotent upgrade of the existing state-v3 database.
        with self.transaction() as conn:
            columns = {row['name'] for row in conn.execute('PRAGMA table_info(vacancies)')}
            for name, definition in {
                'rejected_at': 'TEXT',
                'favorite': 'INTEGER NOT NULL DEFAULT 0',
                'ai_requirements': "TEXT NOT NULL DEFAULT '[]'",
                'user_note': "TEXT NOT NULL DEFAULT ''",
                'score_source': "TEXT NOT NULL DEFAULT 'legacy'",
                'manual_override_at': 'TEXT',
                'manual_override_hash': "TEXT NOT NULL DEFAULT ''",
                'manual_override_version': 'INTEGER NOT NULL DEFAULT 0',
                'approval_reset_attempt_id': "TEXT NOT NULL DEFAULT ''",
            }.items():
                if name not in columns:
                    conn.execute(f'ALTER TABLE vacancies ADD COLUMN {name} {definition}')
            columns = {row['name'] for row in conn.execute('PRAGMA table_info(letters)')}
            for name, definition in {
                'source': "TEXT NOT NULL DEFAULT 'manual'",
                'note': "TEXT NOT NULL DEFAULT ''",
                'name_resume_id': "TEXT NOT NULL DEFAULT ''",
                'name_pending': 'INTEGER NOT NULL DEFAULT 0',
            }.items():
                if name not in columns:
                    conn.execute(f'ALTER TABLE letters ADD COLUMN {name} {definition}')
            columns = {row['name'] for row in conn.execute('PRAGMA table_info(resume_identity)')}
            if 'source' not in columns:
                conn.execute("ALTER TABLE resume_identity ADD COLUMN source TEXT NOT NULL DEFAULT 'resume'")

    def _audit_in_conn(self, conn: sqlite3.Connection, event: str, vacancy_id: str | None, attempt_id: str | None, details: dict[str, Any] | None = None) -> None:
        at = utc_now()
        payload = json.dumps(details or {}, ensure_ascii=False, sort_keys=True)
        conn.execute(
            "INSERT INTO audit(at,event,vacancy_id,attempt_id,details) VALUES(?,?,?,?,?)",
            (at, event, vacancy_id, attempt_id, payload),
        )
        record = {"at": at, "event": event, "vacancy_id": vacancy_id, "attempt_id": attempt_id, "details": details or {}}
        with self.audit_file.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    def audit(self, event: str, vacancy_id: str | None = None, attempt_id: str | None = None, details: dict[str, Any] | None = None) -> None:
        with self.transaction() as conn:
            self._audit_in_conn(conn, event, vacancy_id, attempt_id, details)

    def revoke_placeholder_approvals(self) -> int:
        """Keep legacy text, but require correction before it can be sent."""
        count = 0
        with self.transaction() as conn:
            rows = conn.execute("SELECT l.vacancy_id,l.text,l.source FROM letters l JOIN vacancies v ON v.id=l.vacancy_id WHERE l.approved_at IS NOT NULL AND NOT EXISTS(SELECT 1 FROM submissions s WHERE s.vacancy_id=v.id AND s.state IN ('queued','running','confirmed','unknown'))").fetchall()
            for row in rows:
                event = ''
                try:
                    validate_no_placeholders(row["text"])
                except LetterPolicyError:
                    event = "placeholder_letter_approval_revoked"
                # A pending name never revokes an approval the user already gave.
                if event:
                    conn.execute("UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?", (row["vacancy_id"],))
                    conn.execute("UPDATE vacancies SET status=CASE WHEN vacancy_approved_at IS NOT NULL THEN 'vacancy_approved' ELSE 'review' END WHERE id=? AND status='ready_for_final_click'", (row["vacancy_id"],))
                    self._audit_in_conn(conn, event, row["vacancy_id"], None)
                    count += 1
        return count

    def upsert_vacancy(self, vacancy: dict[str, Any], policy: dict[str, Any], ai: dict[str, Any] | None = None) -> None:
        vacancy_id = str(vacancy["id"])
        now = utc_now()
        employer = (vacancy.get("employer") or {}).get("name") or ""
        area = (vacancy.get("area") or {}).get("name") or ""
        ai = dict(ai or {})
        ai_scores = (
            ai.get("decision") in {"ALLOW", "REVIEW", "BLOCK"}
            and type(ai.get("fit")) is int and 0 <= ai["fit"] <= 100
            and type(ai.get("coverage")) is int and 0 <= ai["coverage"] <= 100
        )
        if not ai_scores and ai.get("decision") in {"ALLOW", "REVIEW", "BLOCK"}:
            ai = {"decision": "ERROR", "summary": "Ollama не вернула проверенные значения Fit и Coverage."}
        score_source = "ai" if ai_scores else ("unavailable" if policy["decision"] == "BLOCK" else "rules")
        decision = policy["decision"]
        content_hash = vacancy_content_hash(vacancy)
        with self.transaction() as conn:
            previous = conn.execute(
                """SELECT v.content_hash,v.manual_override_at,v.manual_override_hash,
                          v.vacancy_approved_at,l.approved_at AS letter_approved_at
                   FROM vacancies v LEFT JOIN letters l ON l.vacancy_id=v.id WHERE v.id=?""",
                (vacancy_id,),
            ).fetchone()
            content_changed = bool(previous and previous["content_hash"] != content_hash)
            override_kept = bool(previous and not content_changed and manual_override_active(previous))
            allowed_by_rules = decision != "BLOCK" and policy["profession_decision"] == "ALLOW"
            effective_allowed = allowed_by_rules or override_kept
            status = "review" if effective_allowed else "blocked"
            had_approval = bool(previous and (previous["vacancy_approved_at"] or previous["letter_approved_at"]))
            invalidate_approvals = bool(previous and (content_changed or (not effective_allowed and had_approval)))
            conn.execute(
                """
                INSERT INTO vacancies(id,name,employer,area,url,apply_url,raw_json,content_hash,policy_decision,
                    profession_decision,fit,coverage,reasons,ai_decision,ai_summary,discovered_at,updated_at,status,score_source)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, employer=excluded.employer, area=excluded.area,
                    url=excluded.url, apply_url=excluded.apply_url, raw_json=excluded.raw_json, content_hash=excluded.content_hash,
                    policy_decision=excluded.policy_decision,
                    profession_decision=excluded.profession_decision,
                    fit=excluded.fit, coverage=excluded.coverage, reasons=excluded.reasons,
                    ai_decision=excluded.ai_decision, ai_summary=excluded.ai_summary,
                    score_source=excluded.score_source,
                    updated_at=excluded.updated_at,
                    manual_override_at=CASE WHEN vacancies.content_hash=excluded.content_hash THEN vacancies.manual_override_at ELSE NULL END,
                    manual_override_hash=CASE WHEN vacancies.content_hash=excluded.content_hash THEN vacancies.manual_override_hash ELSE '' END,
                    manual_override_version=CASE WHEN vacancies.content_hash=excluded.content_hash THEN vacancies.manual_override_version ELSE vacancies.manual_override_version+1 END,
                    vacancy_approved_at=CASE WHEN vacancies.content_hash=excluded.content_hash AND
                        ((excluded.profession_decision='ALLOW' AND excluded.policy_decision!='BLOCK') OR
                         (vacancies.manual_override_at IS NOT NULL AND vacancies.manual_override_hash=excluded.content_hash))
                        THEN vacancies.vacancy_approved_at ELSE NULL END,
                    status=CASE
                        WHEN vacancies.rejected_at IS NOT NULL THEN 'rejected'
                        WHEN vacancies.status IN ('send_queued','sending','sent','verify_on_hh') THEN vacancies.status
                        WHEN vacancies.content_hash=excluded.content_hash AND vacancies.vacancy_approved_at IS NOT NULL AND
                            ((excluded.profession_decision='ALLOW' AND excluded.policy_decision!='BLOCK') OR
                             (vacancies.manual_override_at IS NOT NULL AND vacancies.manual_override_hash=excluded.content_hash))
                            THEN vacancies.status
                        ELSE excluded.status END
                """,
                (
                    vacancy_id, str(vacancy.get("name") or ""), employer, area,
                    str(vacancy.get("alternate_url") or ""), str(vacancy.get("apply_alternate_url") or ""),
                    json.dumps(vacancy, ensure_ascii=False), content_hash, decision, policy["profession_decision"],
                    int(ai["fit"] if ai_scores else policy["fit"]), int(ai["coverage"] if ai_scores else policy["coverage"]),
                    json.dumps(policy.get("reasons", []), ensure_ascii=False), str(ai.get("decision", "NOT_RUN")),
                    str(ai.get("summary", "")), now, now, status, score_source,
                ),
            )
            conn.execute('UPDATE vacancies SET ai_requirements=? WHERE id=?',
                         (json.dumps(ai.get('requirements', []) if ai_scores else [], ensure_ascii=False), vacancy_id))
            if invalidate_approvals:
                conn.execute("UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?", (vacancy_id,))
            if previous and (content_changed or not effective_allowed):
                self._cancel_draft_in_conn(conn, vacancy_id)
            if content_changed:
                self._audit_in_conn(conn, "approvals_revoked_after_vacancy_change", vacancy_id, None)
                if previous and previous["manual_override_at"]:
                    self._audit_in_conn(conn, "manual_override_revoked_after_vacancy_change", vacancy_id, None)
            elif invalidate_approvals:
                self._audit_in_conn(conn, "approvals_revoked_after_policy_block", vacancy_id, None)
            self._audit_in_conn(conn, "vacancy_scored", vacancy_id, None, {
                "policy": decision, "ai": ai.get("decision", "NOT_RUN"), "score_source": score_source,
                "fit": ai["fit"] if ai_scores else None, "coverage": ai["coverage"] if ai_scores else None,
            })

    def _assert_mutable(self, conn: sqlite3.Connection, vacancy_id: str, *, profession: bool = True, allow_rejected: bool = False) -> sqlite3.Row:
        row = conn.execute("SELECT * FROM vacancies WHERE id=?", (vacancy_id,)).fetchone()
        if not row:
            raise StateError("Вакансия не найдена.")
        if row["rejected_at"] and not allow_rejected:
            raise StateError("Вакансия отклонена. Сначала верните её к рассмотрению.")
        active = conn.execute(
            "SELECT state FROM submissions WHERE vacancy_id=? AND state IN ('queued','running','confirmed','unknown') LIMIT 1",
            (vacancy_id,),
        ).fetchone()
        if active:
            raise StateError("Отклик уже запущен, отправлен или требует проверки на hh.ru. Изменить это решение здесь нельзя.")
        if profession and not vacancy_actions_allowed(row):
            raise StateError(
                "Действие недоступно: вакансия заблокирована. "
                "Если вы проверили её вручную, используйте отдельное исключение для этой версии вакансии."
            )
        return row

    def _cancel_draft_in_conn(self, conn: sqlite3.Connection, vacancy_id: str) -> None:
        conn.execute(
            "UPDATE letter_drafts SET state='cancelled',claim_id='',error='',updated_at=? WHERE vacancy_id=? AND state IN ('queued','running','error')",
            (utc_now(), vacancy_id),
        )

    def reject_vacancy(self, vacancy_id: str) -> None:
        with self.transaction() as conn:
            self._assert_mutable(conn, vacancy_id, profession=False, allow_rejected=True)
            now = utc_now()
            conn.execute(
                "UPDATE vacancies SET rejected_at=COALESCE(rejected_at,?),status='rejected',vacancy_approved_at=NULL,vacancy_approval_version=vacancy_approval_version+1,updated_at=? WHERE id=?",
                (now, now, vacancy_id),
            )
            conn.execute("UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?", (vacancy_id,))
            self._cancel_draft_in_conn(conn, vacancy_id)
            self._audit_in_conn(conn, "vacancy_rejected", vacancy_id, None)

    def restore_vacancy(self, vacancy_id: str) -> None:
        with self.transaction() as conn:
            row = self._assert_mutable(conn, vacancy_id, profession=False, allow_rejected=True)
            if not row["rejected_at"]:
                return
            status = "review" if vacancy_actions_allowed(row) else "blocked"
            conn.execute(
                "UPDATE vacancies SET rejected_at=NULL,status=?,updated_at=? WHERE id=?",
                (status, utc_now(), vacancy_id),
            )
            self._audit_in_conn(conn, "vacancy_restored", vacancy_id, None)

    def override_blocked_vacancy(self, vacancy_id: str, expected_content_hash: str) -> None:
        """Create an explicit, auditable exception for one exact vacancy body."""
        with self.transaction() as conn:
            row = self._assert_mutable(conn, vacancy_id, profession=False)
            if row["content_hash"] != expected_content_hash:
                raise StateError("Вакансия изменилась. Обновите карточку и проверьте её заново.")
            if row["policy_decision"] != "BLOCK" and row["profession_decision"] == "ALLOW":
                raise StateError("Эта вакансия не заблокирована; отдельное исключение не требуется.")
            if manual_override_active(row):
                return
            now = utc_now()
            conn.execute(
                """UPDATE vacancies SET manual_override_at=?,manual_override_hash=content_hash,
                       manual_override_version=manual_override_version+1,
                       vacancy_approved_at=NULL,vacancy_approval_version=vacancy_approval_version+1,
                       status='review',updated_at=? WHERE id=?""",
                (now, now, vacancy_id),
            )
            conn.execute(
                "UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?",
                (vacancy_id,),
            )
            self._cancel_draft_in_conn(conn, vacancy_id)
            self._audit_in_conn(conn, "vacancy_block_overridden_by_user", vacancy_id, None, {
                "policy_decision": row["policy_decision"],
                "profession_decision": row["profession_decision"],
                "content_sha256": row["content_hash"],
            })

    def restart_approval(self, vacancy_id: str) -> None:
        """Re-open approvals only after a terminal attempt known to precede a click."""
        with self.transaction() as conn:
            row = self._assert_mutable(conn, vacancy_id, profession=False)
            attempt = conn.execute(
                "SELECT attempt_id,state FROM submissions WHERE vacancy_id=? ORDER BY id DESC LIMIT 1",
                (vacancy_id,),
            ).fetchone()
            if not attempt or attempt["state"] not in {"blocked", "failed", "cancelled"}:
                raise StateError(
                    "Повторное согласование доступно только после попытки, остановленной до клика. "
                    "Неизвестный или подтверждённый результат сначала проверьте на hh.ru."
                )
            if row["approval_reset_attempt_id"] == attempt["attempt_id"]:
                raise StateError("Для этой остановленной попытки согласование уже начато заново.")
            now = utc_now()
            status = "review" if vacancy_actions_allowed(row) else "blocked"
            conn.execute(
                """UPDATE vacancies SET vacancy_approved_at=NULL,
                       vacancy_approval_version=vacancy_approval_version+1,
                       approval_reset_attempt_id=?,status=?,updated_at=? WHERE id=?""",
                (attempt["attempt_id"], status, now, vacancy_id),
            )
            conn.execute(
                "UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?",
                (vacancy_id,),
            )
            self._cancel_draft_in_conn(conn, vacancy_id)
            self._audit_in_conn(
                conn, "approval_flow_restarted_after_safe_failure", vacancy_id, attempt["attempt_id"],
                {"previous_state": attempt["state"]},
            )

    def is_rejected(self, vacancy_id: str) -> bool:
        with self.connect() as conn:
            row = conn.execute("SELECT rejected_at FROM vacancies WHERE id=?", (vacancy_id,)).fetchone()
            return bool(row and row["rejected_at"])

    def _queue_draft_in_conn(self, conn: sqlite3.Connection, vacancy_id: str, *, automatic: bool) -> bool:
        row = self._assert_mutable(conn, vacancy_id)
        letter = conn.execute("SELECT current_hash FROM letters WHERE vacancy_id=?", (vacancy_id,)).fetchone()
        job = conn.execute("SELECT state,automatic FROM letter_drafts WHERE vacancy_id=?", (vacancy_id,)).fetchone()
        if job and job["state"] in {"queued", "running"}:
            if job['state'] == 'queued' and not automatic:
                conn.execute("UPDATE letter_drafts SET automatic=0,requested_at=?,updated_at=? WHERE vacancy_id=?", (utc_now(), utc_now(), vacancy_id))
                self._audit_in_conn(conn, 'letter_draft_prioritized', vacancy_id, None)
                return True
            return False
        if automatic and (letter or (job and job["state"] == "error")):
            return False
        now = utc_now()
        conn.execute(
            """
            INSERT INTO letter_drafts(vacancy_id,state,claim_id,content_hash,expected_letter_hash,automatic,requested_at,updated_at,error)
            VALUES(?,'queued',?,?,?,?,?,?,'')
            ON CONFLICT(vacancy_id) DO UPDATE SET state='queued',claim_id=excluded.claim_id,
                content_hash=excluded.content_hash,expected_letter_hash=excluded.expected_letter_hash,
                automatic=excluded.automatic,requested_at=excluded.requested_at,updated_at=excluded.updated_at,error=''
            """,
            (vacancy_id, uuid.uuid4().hex, row["content_hash"], letter["current_hash"] if letter else None, int(automatic), now, now),
        )
        # Asking to replace a letter revokes approval before background work starts.
        conn.execute("UPDATE letters SET approved_at=NULL,approved_hash=NULL,approval_version=approval_version+1 WHERE vacancy_id=?", (vacancy_id,))
        conn.execute("UPDATE vacancies SET status=CASE WHEN vacancy_approved_at IS NOT NULL THEN 'vacancy_approved' ELSE 'review' END,updated_at=? WHERE id=?", (now, vacancy_id))
        self._audit_in_conn(conn, "letter_draft_queued", vacancy_id, None, {"automatic": automatic})
        return True

    def queue_letter_draft(self, vacancy_id: str, *, expected_content_hash: str | None = None, expected_letter_hash: str | None = None) -> bool:
        """Explicit regeneration may replace a letter only if it stays unchanged."""
        with self.transaction() as conn:
            if expected_content_hash is not None:
                self._check_editor_snapshot(conn, vacancy_id, expected_content_hash, expected_letter_hash)
            return self._queue_draft_in_conn(conn, vacancy_id, automatic=False)

    def queue_missing_drafts(self, limit: int = 100) -> int:
        with self.transaction() as conn:
            rows = conn.execute(
                f"""
                SELECT v.id FROM vacancies v
                LEFT JOIN letters l ON l.vacancy_id=v.id
                LEFT JOIN letter_drafts d ON d.vacancy_id=v.id
                WHERE v.rejected_at IS NULL AND (
                    (v.policy_decision!='BLOCK' AND v.profession_decision='ALLOW') OR
                    (v.manual_override_at IS NOT NULL AND v.manual_override_hash=v.content_hash)
                )
                  AND l.vacancy_id IS NULL AND (d.vacancy_id IS NULL OR d.state='cancelled')
                  AND NOT EXISTS(SELECT 1 FROM submissions s WHERE s.vacancy_id=v.id AND s.state IN ('queued','running','confirmed','unknown'))
                ORDER BY {VACANCY_ORDER} LIMIT ?
                """,
                (max(1, min(1000, int(limit))),),
            ).fetchall()
            return sum(self._queue_draft_in_conn(conn, row["id"], automatic=True) for row in rows)

    def recover_draft_work(self) -> int:
        """Drafts can resume after restart; this never touches submission permits."""
        with self.transaction() as conn:
            rows = conn.execute("SELECT vacancy_id FROM letter_drafts WHERE state='running'").fetchall()
            for row in rows:
                conn.execute("UPDATE letter_drafts SET state='queued',claim_id=?,updated_at=? WHERE vacancy_id=?", (uuid.uuid4().hex, utc_now(), row["vacancy_id"]))
                self._audit_in_conn(conn, "letter_draft_recovered", row["vacancy_id"], None)
            return len(rows)

    def pause_draft_work(self, *, automatic_only: bool) -> None:
        with self.transaction() as conn:
            conn.execute(
                "UPDATE letter_drafts SET state='cancelled',claim_id='',error='',updated_at=? WHERE state IN ('queued','running') AND (?=0 OR automatic=1)",
                (utc_now(), int(automatic_only)),
            )

    def _draft_snapshot_in_conn(self, conn: sqlite3.Connection, job: sqlite3.Row) -> dict[str, Any]:
        row = self._assert_mutable(conn, job["vacancy_id"])
        letter = conn.execute("SELECT current_hash FROM letters WHERE vacancy_id=?", (job["vacancy_id"],)).fetchone()
        current_hash = letter["current_hash"] if letter else None
        if row["content_hash"] != job["content_hash"] or current_hash != job["expected_letter_hash"]:
            raise StateError("Вакансия или письмо изменились во время подготовки. Устаревший черновик отменён.")
        return {
            **dict(job),
            "policy_decision": row["policy_decision"],
            "profession_decision": row["profession_decision"],
            "manual_override_at": row["manual_override_at"],
            "manual_override_hash": row["manual_override_hash"],
            "raw": json.loads(row["raw_json"]),
        }

    def claim_letter_draft(self) -> dict[str, Any] | None:
        with self.transaction() as conn:
            rows = conn.execute(f"SELECT d.* FROM letter_drafts d JOIN vacancies v ON v.id=d.vacancy_id WHERE d.state='queued' ORDER BY d.automatic,CASE WHEN d.automatic=0 THEN d.requested_at END DESC,{VACANCY_ORDER},d.requested_at").fetchall()
            for job in rows:
                try:
                    snapshot = self._draft_snapshot_in_conn(conn, job)
                except StateError:
                    self._cancel_draft_in_conn(conn, job["vacancy_id"])
                    continue
                conn.execute("UPDATE letter_drafts SET state='running',updated_at=? WHERE vacancy_id=?", (utc_now(), job["vacancy_id"]))
                self._audit_in_conn(conn, "letter_draft_started", job["vacancy_id"], None)
                return snapshot
            return None

    def complete_letter_draft(self, vacancy_id: str, claim_id: str, text: str, *, source: str = 'ai', note: str = '', name_resume_id: str = '') -> str:
        with self.transaction() as conn:
            job = conn.execute("SELECT * FROM letter_drafts WHERE vacancy_id=? AND claim_id=? AND state='running'", (vacancy_id, claim_id)).fetchone()
            if not job:
                raise StateError("Черновик отменён или уже изменён пользователем.")
            self._draft_snapshot_in_conn(conn, job)
            digest = self._write_letter_in_conn(conn, vacancy_id, text, event="letter_draft_ready", source=source, note=note, name_resume_id=name_resume_id)
            conn.execute("UPDATE letter_drafts SET state='ready',claim_id='',error='',updated_at=? WHERE vacancy_id=?", (utc_now(), vacancy_id))
            return digest

    def fail_letter_draft(self, vacancy_id: str, claim_id: str, error: str, *, cancelled: bool = False) -> None:
        with self.transaction() as conn:
            state = "cancelled" if cancelled else "error"
            changed = conn.execute(
                "UPDATE letter_drafts SET state=?,claim_id='',error=?,updated_at=? WHERE vacancy_id=? AND claim_id=? AND state='running'",
                (state, error[:500], utc_now(), vacancy_id, claim_id),
            ).rowcount
            if changed:
                self._audit_in_conn(conn, f"letter_draft_{state}", vacancy_id, None, {"error": error[:500]})

    def draft_counts(self) -> dict[str, int]:
        with self.connect() as conn:
            return {row["state"]: row["count"] for row in conn.execute(
                "SELECT d.state,COUNT(*) AS count FROM letter_drafts d JOIN vacancies v ON v.id=d.vacancy_id WHERE v.rejected_at IS NULL GROUP BY d.state"
            )}

    def _write_letter_in_conn(self, conn: sqlite3.Connection, vacancy_id: str, text: str, *, event: str, source: str = 'manual', note: str = '', name_resume_id: str = '') -> str:
        clean = text.strip()
        if not 80 <= len(clean) <= 4000:
            raise StateError("cover letter must contain between 80 and 4000 characters")
        digest = letter_hash(clean)
        now = utc_now()
        conn.execute(
            """
            INSERT INTO letters(vacancy_id,text,current_hash,updated_at,approved_at,approved_hash,approval_version)
            VALUES(?,?,?,?,NULL,NULL,0)
            ON CONFLICT(vacancy_id) DO UPDATE SET text=excluded.text,current_hash=excluded.current_hash,
                updated_at=excluded.updated_at,approved_at=NULL,approved_hash=NULL,approval_version=letters.approval_version+1
            """,
            (vacancy_id, clean, digest, now),
        )
        conn.execute("UPDATE vacancies SET status=CASE WHEN vacancy_approved_at IS NOT NULL THEN 'vacancy_approved' ELSE 'review' END,updated_at=? WHERE id=?", (now, vacancy_id))
        conn.execute("UPDATE letters SET source=?,note=?,name_resume_id=?,name_pending=0 WHERE vacancy_id=?", (source, note[:500], name_resume_id, vacancy_id))
        self._audit_in_conn(conn, event, vacancy_id, None, {"sha256": digest, "length": len(clean)})
        return digest

    def _check_editor_snapshot(self, conn: sqlite3.Connection, vacancy_id: str, content_hash: str, expected_letter_hash: str | None) -> None:
        row = self._assert_mutable(conn, vacancy_id)
        letter = conn.execute('SELECT current_hash FROM letters WHERE vacancy_id=?', (vacancy_id,)).fetchone()
        if row['content_hash'] != content_hash or (letter['current_hash'] if letter else None) != expected_letter_hash:
            raise StateError('Вакансия или письмо изменились. Обновите карточку перед генерацией.')

    def save_profile_draft(self, vacancy_id: str, text: str, *, expected_content_hash: str, expected_letter_hash: str | None, resume_id: str) -> str:
        with self.transaction() as conn:
            self._check_editor_snapshot(conn, vacancy_id, expected_content_hash, expected_letter_hash)
            self._cancel_draft_in_conn(conn, vacancy_id)
            digest = self._write_letter_in_conn(conn, vacancy_id, text, event='profile_letter_ready', source='profile', name_resume_id=resume_id)
            now = utc_now()
            conn.execute("""INSERT INTO letter_drafts(vacancy_id,state,claim_id,content_hash,expected_letter_hash,automatic,requested_at,updated_at,error)
                VALUES(?,'ready','',?,?,0,?,?,'') ON CONFLICT(vacancy_id) DO UPDATE SET state='ready',claim_id='',
                content_hash=excluded.content_hash,expected_letter_hash=excluded.expected_letter_hash,automatic=0,updated_at=excluded.updated_at,error=''""",
                (vacancy_id, expected_content_hash, digest, now, now))
            return digest

    def save_letter(self, vacancy_id: str, text: str) -> str:
        with self.transaction() as conn:
            self._assert_mutable(conn, vacancy_id)
            self._cancel_draft_in_conn(conn, vacancy_id)
            return self._write_letter_in_conn(conn, vacancy_id, text, event="letter_saved")

    def approve_vacancy(self, vacancy_id: str, expected_content_hash: str | None = None) -> None:
        now = utc_now()
        with self.transaction() as conn:
            row = self._assert_mutable(conn, vacancy_id)
            if expected_content_hash is not None and expected_content_hash != row["content_hash"]:
                raise StateError("Вакансия изменилась. Проверьте обновлённую карточку.")
            conn.execute(
                "UPDATE vacancies SET vacancy_approved_at=?, vacancy_approval_version=vacancy_approval_version+1, status='vacancy_approved', updated_at=? WHERE id=?",
                (now, now, vacancy_id),
            )
            conn.execute("UPDATE letters SET approved_at=NULL,approved_hash=NULL WHERE vacancy_id=?", (vacancy_id,))
            self._audit_in_conn(conn, "vacancy_approved", vacancy_id, None)

    def approve_letter(self, vacancy_id: str, expected_hash: str | None = None) -> str:
        now = utc_now()
        with self.transaction() as conn:
            vacancy = self._assert_mutable(conn, vacancy_id)
            letter = conn.execute("SELECT current_hash,text,source FROM letters WHERE vacancy_id=?", (vacancy_id,)).fetchone()
            if not vacancy or not vacancy["vacancy_approved_at"]:
                raise StateError("approve the vacancy first")
            if not vacancy_actions_allowed(vacancy):
                raise StateError("Вакансия заблокирована и для неё нет действующего ручного исключения.")
            if not letter:
                raise StateError("cover letter not found")
            # The name is optional: hh.ru attaches the resume to every response,
            # so the employer sees the name there. A missing name no longer
            # blocks approval - it only means the letter carries no signature.
            try:
                validate_no_placeholders(letter["text"])
            except LetterPolicyError as exc:
                raise StateError(str(exc)) from exc
            if expected_hash is not None and expected_hash != letter["current_hash"]:
                raise StateError("Текст изменился. Проверьте и одобрите актуальное письмо.")
            if conn.execute("SELECT 1 FROM letter_drafts WHERE vacancy_id=? AND state IN ('queued','running')", (vacancy_id,)).fetchone():
                raise StateError("Дождитесь подготовки письма или сохраните свой текст вручную.")
            conn.execute(
                "UPDATE letters SET approved_at=?, approved_hash=current_hash, approval_version=approval_version+1 WHERE vacancy_id=?",
                (now, vacancy_id),
            )
            conn.execute("UPDATE vacancies SET status='ready_for_final_click', updated_at=? WHERE id=?", (now, vacancy_id))
            self._audit_in_conn(conn, "letter_approved", vacancy_id, None, {"sha256": letter["current_hash"]})
            return str(letter["current_hash"])

    def get_submission_snapshot(self, vacancy_id: str) -> dict[str, Any]:
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT v.*,l.text AS letter_text,l.current_hash,l.approved_hash,l.approved_at AS letter_approved_at,
                    l.approval_version AS letter_approval_version,l.source AS letter_source
                FROM vacancies v LEFT JOIN letters l ON l.vacancy_id=v.id WHERE v.id=?
                """,
                (vacancy_id,),
            ).fetchone()
            if not row:
                raise StateError("vacancy not found")
            result = dict(row)
            result["raw"] = json.loads(result.pop("raw_json"))
            return result

    def prepare_submission(self, vacancy_id: str, attempt_id: str, daily_limit: int, *, expected_letter_hash: str | None = None, expected_content_hash: str | None = None) -> dict[str, Any]:
        with self.transaction() as conn:
            return self._prepare_submission(conn, vacancy_id, attempt_id, daily_limit, expected_letter_hash=expected_letter_hash, expected_content_hash=expected_content_hash)

    def prepare_batch(self, items, daily_limit):
        with self.transaction() as conn:
            return [self._prepare_submission(conn, item['id'], item['attempt_id'], daily_limit,
                    expected_letter_hash=item['letter_sha256'], expected_content_hash=item['content_hash']) for item in items]

    def _prepare_submission(self, conn, vacancy_id, attempt_id, daily_limit, *, expected_letter_hash=None, expected_content_hash=None):
        now = utc_now()
        today = now[:10]
        self._assert_mutable(conn, vacancy_id)
        row = conn.execute(
            """
            SELECT v.*,l.text AS letter_text,l.current_hash,l.approved_hash,l.approved_at AS letter_approved_at,
                l.approval_version AS letter_approval_version,l.source AS letter_source
            FROM vacancies v JOIN letters l ON l.vacancy_id=v.id WHERE v.id=?
            """,
            (vacancy_id,),
        ).fetchone()
        if not row:
            raise StateError("vacancy or letter not found")
        try:
            validate_no_placeholders(row["letter_text"])
        except LetterPolicyError as exc:
            raise StateError(str(exc)) from exc
        # No name gate here either - see approve_letter above.
        if expected_letter_hash is not None and row["current_hash"] != expected_letter_hash:
            raise StateError("Письмо изменилось после открытия подтверждения. Проверьте текст заново.")
        if expected_content_hash is not None and row["content_hash"] != expected_content_hash:
            raise StateError("Вакансия изменилась после открытия подтверждения. Проверьте карточку заново.")
        if not vacancy_actions_allowed(row):
            raise StateError("Текущие правила не разрешают отправку, а ручное исключение отсутствует или устарело.")
        if not row["vacancy_approved_at"] or not row["letter_approved_at"]:
            raise StateError("both vacancy and exact letter must be approved")
        if row["current_hash"] != row["approved_hash"] or letter_hash(row["letter_text"]) != row["approved_hash"]:
            raise StateError("letter changed after approval")
        active = conn.execute(
            "SELECT state FROM submissions WHERE vacancy_id=? AND state IN ('queued','running','confirmed','unknown') ORDER BY id DESC LIMIT 1",
            (vacancy_id,),
        ).fetchone()
        if active:
            raise StateError(f"submission already has terminal or active state: {active['state']}")
        latest = conn.execute(
            "SELECT attempt_id,state FROM submissions WHERE vacancy_id=? ORDER BY id DESC LIMIT 1",
            (vacancy_id,),
        ).fetchone()
        if (
            latest
            and latest["state"] in {"blocked", "failed", "cancelled"}
            and row["approval_reset_attempt_id"] != latest["attempt_id"]
        ):
            raise StateError("После остановленной попытки начните согласование заново и повторно одобрите вакансию и письмо.")
        sent_today = conn.execute(
            "SELECT COUNT(*) FROM submissions WHERE state IN ('queued','running') OR (state IN ('confirmed','unknown') AND substr(finished_at,1,10)=?)",
            (today,),
        ).fetchone()[0]
        if int(sent_today) >= int(daily_limit):
            raise StateError("daily submission limit reached")
        conn.execute(
            """
            INSERT INTO submissions(attempt_id,vacancy_id,letter_hash,vacancy_approval_version,
                letter_approval_version,state,created_at) VALUES(?,?,?,?,?,'queued',?)
            """,
            (attempt_id, vacancy_id, row["approved_hash"], row["vacancy_approval_version"], row["letter_approval_version"], now),
        )
        conn.execute("UPDATE vacancies SET status='send_queued',updated_at=? WHERE id=?", (now, vacancy_id))
        self._audit_in_conn(conn, "final_send_clicked", vacancy_id, attempt_id, {"letter_sha256": row["approved_hash"]})
        result = dict(row)
        result["raw"] = json.loads(result.pop("raw_json"))
        return result

    @contextmanager
    def submission_guard(self, expected: dict[str, Any]) -> Iterator[None]:
        """Recheck approvals and exclude writers through the physical click.

        Scout may finish an AI assessment while the form is opening. Its update
        must either precede this check or wait until the click has completed.
        This guard does not issue a permit and cannot launch a submission.
        """
        with self.transaction() as conn:
            row = conn.execute(
                """SELECT v.content_hash,v.profession_decision,v.policy_decision,v.rejected_at,v.status,
                    v.manual_override_at,v.manual_override_hash,v.manual_override_version,
                    v.vacancy_approved_at,v.vacancy_approval_version,l.text,l.current_hash,l.approved_hash,
                    l.approved_at AS letter_approved_at,l.approval_version AS letter_approval_version,
                    l.source AS letter_source
                    FROM vacancies v JOIN letters l ON l.vacancy_id=v.id WHERE v.id=?""", (expected["id"],),
            ).fetchone()
            if not row or row['rejected_at'] or row['status'] != 'sending' or not vacancy_actions_allowed(row):
                raise StateError("Перед отправкой изменилось состояние вакансии. Проверьте её и одобрите заново.")
            if not row['vacancy_approved_at'] or not row['letter_approved_at']:
                raise StateError("Одобрение было отозвано до отправки. Проверьте вакансию и письмо заново.")
            for key in ('content_hash', 'current_hash', 'approved_hash', 'vacancy_approval_version', 'letter_approval_version'):
                if row[key] != expected.get(key):
                    raise StateError("Вакансия или одобренный текст изменились перед отправкой. Требуется новое подтверждение.")
            if letter_hash(row['text']) != expected['approved_hash']:
                raise StateError("Одобренный текст изменился перед отправкой.")
            yield

    def set_submission_state(self, attempt_id: str, state: str, result: str = "", error: str = "") -> None:
        allowed = {"running", "confirmed", "blocked", "failed", "unknown", "cancelled"}
        if state not in allowed:
            raise StateError("invalid submission state")
        now = utc_now()
        with self.transaction() as conn:
            row = conn.execute("SELECT vacancy_id,state FROM submissions WHERE attempt_id=?", (attempt_id,)).fetchone()
            if not row:
                raise StateError("attempt not found")
            if row["state"] in {"confirmed", "unknown", "blocked", "failed", "cancelled"}:
                raise StateError("terminal submission state cannot be overwritten")
            started = now if state == "running" else None
            finished = now if state in {"confirmed", "blocked", "failed", "unknown", "cancelled"} else None
            conn.execute(
                "UPDATE submissions SET state=?,started_at=COALESCE(started_at,?),finished_at=?,result=?,error=? WHERE attempt_id=?",
                (state, started, finished, result, error[:4000], attempt_id),
            )
            vacancy_status = {
                "running": "sending", "confirmed": "sent", "blocked": "send_blocked",
                "failed": "send_failed", "unknown": "verify_on_hh", "cancelled": "review",
            }[state]
            conn.execute("UPDATE vacancies SET status=?,updated_at=? WHERE id=?", (vacancy_status, now, row["vacancy_id"]))
            self._audit_in_conn(conn, f"submission_{state}", row["vacancy_id"], attempt_id, {"result": result, "error": error[:500]})

    def cancel_stale_work(self) -> int:
        now = utc_now()
        with self.transaction() as conn:
            rows = conn.execute("SELECT attempt_id,vacancy_id,state FROM submissions WHERE state IN ('queued','running')").fetchall()
            for row in rows:
                # A running process may have died after the remote click. Do
                # not let a restart erase that uncertainty and enable duplicates.
                uncertain = row['state'] == 'running'
                state = 'unknown' if uncertain else 'cancelled'
                status = 'verify_on_hh' if uncertain else 'review'
                error = 'Агент перезапущен во время отправки. Проверьте результат на hh.ru.' if uncertain else 'Очередь отменена при перезапуске'
                conn.execute('UPDATE submissions SET state=?,finished_at=?,error=? WHERE attempt_id=?', (state, now, error, row['attempt_id']))
                conn.execute('UPDATE vacancies SET status=?,updated_at=? WHERE id=?', (status, now, row['vacancy_id']))
                self._audit_in_conn(conn, 'submission_' + state + '_on_restart', row['vacancy_id'], row['attempt_id'])
            return len(rows)

    def list_vacancies(self, limit: int = 200, *, view: Any = None) -> list[dict[str, Any]]:
        where, args, order = view.sql() if view else ('1=1', [], VACANCY_ORDER)
        size = view.page_size if view else max(1, min(1000, int(limit)))
        offset = (view.page - 1) * size if view else 0
        with self.connect() as conn:
            rows = conn.execute(
                f"""
                SELECT v.ai_requirements,v.favorite,v.user_note,v.raw_json,v.discovered_at,v.id,v.name,v.employer,v.area,v.url,v.policy_decision,v.profession_decision,
                    v.fit,v.coverage,v.score_source,v.reasons,v.ai_decision,v.ai_summary,v.status,v.updated_at,
                    v.rejected_at,v.content_hash,v.vacancy_approved_at,v.vacancy_approval_version,
                    v.manual_override_at,v.manual_override_hash,v.manual_override_version,v.approval_reset_attempt_id,
                    l.text AS letter_text,l.current_hash,l.approved_hash,l.approved_at AS letter_approved_at,
                    l.source AS letter_source,l.note AS letter_note,
                    d.state AS draft_state,d.error AS draft_error,d.automatic AS draft_automatic,d.updated_at AS draft_updated_at,
                    (SELECT s.attempt_id FROM submissions s WHERE s.vacancy_id=v.id ORDER BY s.id DESC LIMIT 1) AS submission_attempt_id,
                    (SELECT s.state FROM submissions s WHERE s.vacancy_id=v.id ORDER BY s.id DESC LIMIT 1) AS submission_state,
                    (SELECT s.error FROM submissions s WHERE s.vacancy_id=v.id ORDER BY s.id DESC LIMIT 1) AS submission_error,
                    (SELECT s.result FROM submissions s WHERE s.vacancy_id=v.id ORDER BY s.id DESC LIMIT 1) AS submission_result
                FROM vacancies v LEFT JOIN letters l ON l.vacancy_id=v.id
                LEFT JOIN letter_drafts d ON d.vacancy_id=v.id
                WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?
                """,
                (*args, size, offset),
            ).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                raw = json.loads(item.pop('raw_json'))
                item['ai_requirements'] = json.loads(item['ai_requirements'] or '[]')
                item['salary'] = raw.get('salary')
                item['published_at'] = raw.get('published_at')
                item['experience'] = (raw.get('experience') or {}).get('name', '')
                item['schedule'] = (raw.get('schedule') or {}).get('name', '')
                item['skills'] = [str(x.get('name', '')) for x in raw.get('key_skills', []) if isinstance(x, dict)][:30]
                item['source'] = raw.get('_source', 'public_api')
                from .vacancy_view import plain_description
                item['description'] = plain_description(str(raw.get('description') or ''))
                item["reasons"] = json.loads(item["reasons"] or "[]")
                item["manual_override_active"] = manual_override_active(item)
                item["actions_allowed"] = vacancy_actions_allowed(item)
                item["retry_approval_available"] = bool(
                    item.get("submission_state") in {"blocked", "failed", "cancelled"}
                    and item.get("submission_attempt_id")
                    and item.get("submission_attempt_id") != item.get("approval_reset_attempt_id")
                    and not item.get("rejected_at")
                )
                result.append(item)
            return result

    def view_metadata(self, view: Any) -> dict[str, Any]:
        where, args, _ = view.sql()
        with self.connect() as conn:
            filtered = conn.execute(f'SELECT count(*) FROM vacancies v WHERE {where}', args).fetchone()[0]
            total = conn.execute('SELECT count(*) FROM vacancies').fetchone()[0]
            counts = {row['status']: row['n'] for row in conn.execute('SELECT status,count(*) n FROM vacancies GROUP BY status')}
            cities = [row[0] for row in conn.execute("SELECT DISTINCT area FROM vacancies WHERE area!='' ORDER BY hh_city_priority(area),area")]
        return {'total': total, 'filtered': filtered, 'page': view.page,
                'pages': max(1, (filtered + view.page_size - 1) // view.page_size),
                'page_size': view.page_size, 'counts': counts, 'cities': cities}

    def annotate_vacancy(self, vacancy_id: str, *, favorite: bool | None = None, note: str | None = None) -> None:
        # Personal organization never revokes or grants approval, including sent items.
        if note is not None and (not isinstance(note, str) or len(note) > 2000):
            raise StateError('Заметка должна быть короче 2000 символов')
        if favorite is not None and not isinstance(favorite, bool):
            raise StateError('Некорректное значение избранного')
        with self.transaction() as conn:
            if not conn.execute('SELECT 1 FROM vacancies WHERE id=?', (vacancy_id,)).fetchone():
                raise StateError('Вакансия не найдена')
            if favorite is not None:
                conn.execute('UPDATE vacancies SET favorite=? WHERE id=?', (int(favorite), vacancy_id))
            if note is not None:
                conn.execute('UPDATE vacancies SET user_note=? WHERE id=?', (note, vacancy_id))

    def recent_audit(self, limit: int = 500) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM audit ORDER BY seq DESC LIMIT ?", (max(1, min(5000, int(limit))),)).fetchall()
            output = []
            for row in rows:
                item = dict(row)
                item["details"] = json.loads(item["details"] or "{}")
                output.append(item)
            return output

    def submission_status(self, vacancy_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM submissions WHERE vacancy_id=? ORDER BY id DESC LIMIT 1", (vacancy_id,)).fetchone()
            return dict(row) if row else None
