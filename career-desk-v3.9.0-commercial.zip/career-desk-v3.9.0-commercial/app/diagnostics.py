from __future__ import annotations

import io
import json
import platform
import sqlite3
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import __version__
from .ai import AIError, OllamaClient
from .db import Database
from .hh_api import HHApiError, HybridHHClient, validate_search_payload
from .paths import BROWSER_PROFILE, DIAGNOSTICS_DIR, LOG_DIR, LOG_FILE, PROJECT_ROOT, ensure_directories
from .settings import sanitized_settings


def _chromium_health() -> tuple[bool, str]:
    """Probe Playwright in a child process so its driver loop cannot leak here."""
    probe = (
        "from pathlib import Path\n"
        "from playwright.sync_api import sync_playwright\n"
        "with sync_playwright() as playwright:\n"
        "    executable = Path(playwright.chromium.executable_path)\n"
        "    print(executable)\n"
        "    raise SystemExit(0 if executable.exists() else 3)\n"
    )
    try:
        completed = subprocess.run(
            [sys.executable, "-c", probe],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Playwright Chromium probe failed: {exc}"
    output = completed.stdout.strip().splitlines()
    detail = output[-1] if output else completed.stderr.strip()[-1000:]
    if completed.returncode == 0 and detail:
        return True, detail
    return False, detail or f"Playwright Chromium probe exited with code {completed.returncode}"


def health_report(settings: dict[str, Any], db: Database, live_search: bool = False) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(name: str, status: str, detail: str) -> None:
        checks.append({"name": name, "status": status, "detail": detail})

    add("version", "PASS", __version__)
    py_ok = sys.version_info >= (3, 11)
    add("python", "PASS" if py_ok else "FAIL", platform.python_version())
    try:
        with db.connect() as conn:
            conn.execute("SELECT 1").fetchone()
        add("sqlite", "PASS", str(db.path))
    except (sqlite3.Error, OSError) as exc:
        add("sqlite", "FAIL", str(exc))

    chromium_ok, chromium_detail = _chromium_health()
    add("chromium", "PASS" if chromium_ok else "FAIL", chromium_detail)

    ai = settings["ai"]
    if ai.get("enabled"):
        try:
            status = OllamaClient(ai["base_url"], ai["model"], 30).health()
            add("ollama", "PASS" if status["model_available"] else "FAIL", f"model={ai['model']}; available={status['model_available']}")
        except AIError as exc:
            add("ollama", "FAIL", str(exc))
    else:
        add("ollama", "WARN", "AI disabled; every non-blocked vacancy stays on manual review")

    if live_search:
        first_query = next((str(value).strip() for value in settings["search"]["queries"] if str(value).strip()), "")
        regions = sorted((x for x in settings["search"]["regions"] if x.get("enabled")), key=lambda x: int(x.get("priority", 0)), reverse=True)
        client = HybridHHClient()
        try:
            client.api.timeout = 20
            client.api.retries = 1
            if not first_query or not regions:
                raise HHApiError("Для диагностики нужны поисковый запрос и включённый регион", kind="settings")
            region = regions[0]
            area_id = str(region.get("area_id") or "").strip()
            if not area_id:
                area_id = client.resolve_area_id(str(region.get("name") or ""))
            payload = validate_search_payload(client.search(first_query, area_id, days=int(settings["search"]["days"]), per_page=5))
            count = len(payload["items"])
            add(
                "hh_search",
                "PASS",
                f"confirmed search response; sample results={count}; source={client.last_source}" + ("; no matches for the selected filters" if not count else ""),
            )
            if count:
                sample = client.vacancy(str(payload["items"][0]["id"]))
                if str(sample.get("id")) != str(payload["items"][0]["id"]) or not sample.get("name") or len(str(sample.get("description") or "")) < 40:
                    raise HHApiError("Контрольная вакансия не содержит подтверждённого ID, названия и полного описания", kind="data")
                add("hh_vacancy", "PASS", f"sample detail readable; source={client.last_source}")
            else:
                add("hh_vacancy", "INFO", "no sample available; detail reading was not verified")
        except HHApiError as exc:
            name = "hh_vacancy" if any(item["name"] == "hh_search" and item["status"] == "PASS" for item in checks) else "hh_search"
            add(name, "FAIL", str(exc))
        finally:
            client.close()
    else:
        add("hh_search", "INFO", "live sample skipped; run full diagnostics to verify")

    resume_id = str(settings["submit"].get("resume_id") or "")
    add("resume", "PASS" if resume_id else "WARN", "configured" if resume_id else "not selected; multiple-resume forms will be blocked")
    add("browser_profile", "PASS" if BROWSER_PROFILE.exists() and any(BROWSER_PROFILE.iterdir()) else "WARN", str(BROWSER_PROFILE))
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    return {
        "version": __version__,
        "at": datetime.now(timezone.utc).isoformat(),
        "manual_only": settings["submit"].get("mode") == "manual_only",
        "auto_submit_codepath": False,
        "result": "PASS" if fail_count == 0 else "FAIL",
        "checks": checks,
    }


def build_diagnostics_zip(settings: dict[str, Any], db: Database, live_search: bool = False) -> bytes:
    report = health_report(settings, db, live_search=live_search)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("health.json", json.dumps(report, ensure_ascii=False, indent=2))
        archive.writestr("settings-sanitized.json", json.dumps(sanitized_settings(settings), ensure_ascii=False, indent=2))
        archive.writestr("audit-recent.json", json.dumps(db.recent_audit(1000), ensure_ascii=False, indent=2))
        vacancy_state = []
        for item in db.list_vacancies(500):
            vacancy_state.append({
                "id": item["id"], "name": item["name"], "employer": item["employer"],
                "policy_decision": item["policy_decision"], "profession_decision": item["profession_decision"],
                "fit": item["fit"], "coverage": item["coverage"], "status": item["status"],
                "score_source": item.get("score_source"), "rejected": bool(item.get("rejected_at")),
                "draft_state": item.get("draft_state"), "draft_error": item.get("draft_error"),
                "letter_present": bool(item.get("letter_text")), "letter_approved": bool(item.get("letter_approved_at")),
                "letter_source": item.get('letter_source'),
                "manual_override_active": bool(item.get("manual_override_active")),
                "retry_approval_available": bool(item.get("retry_approval_available")),
                "submission_state": item.get("submission_state"),
            })
        archive.writestr("vacancies-state.json", json.dumps(vacancy_state, ensure_ascii=False, indent=2))
        archive.writestr("letter-draft-counts.json", json.dumps(db.draft_counts(), ensure_ascii=False, indent=2))
        # The changelog travels with the bundle: when this archive is handed
        # to a person or another AI for diagnosis, the history of what was
        # already fixed and why goes with it.
        changelog = PROJECT_ROOT / 'CHANGELOG.md'
        if changelog.exists():
            archive.writestr('CHANGELOG.md', changelog.read_text(encoding='utf-8'))
        archive.writestr("privacy.txt", "No cookies, browser profile, API keys, resume id, resume text, or environment variables are included.\n")
        for log_path in sorted(LOG_DIR.glob("agent.log*")):
            if log_path.is_file() and log_path.stat().st_size <= 10_000_000:
                archive.write(log_path, f"logs/{log_path.name}")
        for report_path in sorted(DIAGNOSTICS_DIR.glob("form-*.json"))[-50:]:
            archive.write(report_path, f"forms/{report_path.name}")
        for report_path in sorted(DIAGNOSTICS_DIR.glob("web-layout-*.json")):
            archive.write(report_path, f"web/{report_path.name}")
    return buffer.getvalue()


def combined_log_text(db: Database) -> str:
    parts = [f"Career Desk {__version__}\n"]
    if LOG_FILE.exists():
        parts.append(LOG_FILE.read_text(encoding="utf-8", errors="replace")[-2_000_000:])
    parts.append("\n\n=== APPROVAL LEDGER ===\n")
    for item in reversed(db.recent_audit(2000)):
        parts.append(json.dumps(item, ensure_ascii=False, sort_keys=True))
    parts.append('\n=== RESPONSE FORM STRUCTURE (NO TEXT OR VALUES) ===\n')
    # A text log previously omitted the only report that could explain a
    # missing editor. Export structural fields, never input values or HTML.
    fields = {'vacancy_id', 'stage', 'http_status', 'cover_candidates', 'cover_hidden',
              'cover_expanders', 'cover_expansions', 'required_unanswered',
              'response_actions', 'response_action_clicks', 'blocked_writes', 'recoveries',
              'resume_options', 'resume_proof', 'submit_buttons', 'employer_questions',
              'success_markers', 'clicked', 'controls'}
    for path in sorted(DIAGNOSTICS_DIR.glob('form-*.json'), key=lambda item: item.stat().st_mtime)[-10:]:
        try:
            if path.stat().st_size > 100_000:
                continue
            report = json.loads(path.read_text(encoding='utf-8'))
            parts.append(json.dumps({key: value for key, value in report.items() if key in fields}, ensure_ascii=False, sort_keys=True))
        except (OSError, ValueError, AttributeError):
            continue
    return "\n".join(parts) + "\n"
