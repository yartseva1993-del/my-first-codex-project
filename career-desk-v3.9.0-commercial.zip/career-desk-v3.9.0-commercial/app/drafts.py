from __future__ import annotations

import copy
import logging
import threading
from typing import Any, Callable

from .ai import AIError, OllamaClient
from .db import Database, StateError, manual_override_active
from .letters import LetterPolicyError, profile_letter, validate_cover_letter
from .policy import evaluate_vacancy


LOGGER = logging.getLogger(__name__)


class DraftRunner:
    """Serial background preparation of local drafts. No send actions or permits."""

    def __init__(self, db: Database, settings: dict[str, Any], client_factory: Callable[..., Any] = OllamaClient):
        self.db = db
        self.settings = settings
        self.client_factory = client_factory
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._run_lock = threading.Lock()
        self.current_id: str | None = None
        self.last_error: str = ""
        self._client_key: tuple[Any, ...] | None = None
        self._client: Any = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self.db.recover_draft_work()
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="letter-drafts", daemon=True)
        self._thread.start()

    def wake(self) -> None:
        self._wake.set()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        # urlopen has a bounded timeout. Any in-flight result is discarded;
        # shutdown does not wait for a slow local model.

    def status(self) -> dict[str, Any]:
        ai = self.settings["ai"]
        return {
            "enabled": bool(ai.get("enabled")),
            "automatic": bool(ai.get("auto_draft_letters", True)),
            "current_id": self.current_id,
            "counts": self.db.draft_counts(),
            "last_error": self.last_error,
        }

    def run_next(self) -> bool:
        """One claimed job, also usable for deterministic lifecycle tests."""
        with self._run_lock:
            if self._stop.is_set():
                return False
            config = copy.deepcopy(self.settings)
            ai = config["ai"]
            if not ai.get("enabled"):
                self.db.pause_draft_work(automatic_only=False)
                return False
            if ai.get("auto_draft_letters", True):
                self.db.queue_missing_drafts()
            else:
                self.db.pause_draft_work(automatic_only=True)
            resume_id = str(config["submit"].get("resume_id") or "")
            job = self.db.claim_letter_draft()
            if not job:
                return False
            vacancy_id, claim_id = job["vacancy_id"], job["claim_id"]
            self.current_id = vacancy_id
            try:
                policy = evaluate_vacancy(job["raw"], config)
                if (policy.decision == "BLOCK" or policy.profession_decision != "ALLOW") and not manual_override_active(job):
                    raise StateError("Текущие правила не разрешают подготовку письма для этой вакансии.")
                note = ''
                source = 'profile'
                # Automatic drafts are available immediately from saved facts.
                # Only an explicit "Rewrite with AI" request waits for Ollama.
                if job['automatic']:
                    text = profile_letter(job['raw'], config)
                else:
                    client_key = (ai['base_url'], ai['model'], int(ai['timeout_seconds']))
                    if self._client_key != client_key:
                        self._client = self.client_factory(*client_key)
                        self._client_key = client_key
                    letter_config = copy.deepcopy(config)
                    try:
                        text = self._client.draft_and_critique_letter(job['raw'], letter_config)
                        source = 'ai'
                    except (AIError, LetterPolicyError) as exc:
                        # Existing user text always survives a failed rewrite.
                        if job['expected_letter_hash']:
                            raise
                        text = profile_letter(job['raw'], config)
                        note = 'ИИ не подготовил проверенный текст; создан черновик из профиля. ' + str(exc)
                text = validate_cover_letter(text, config)
                if self._stop.is_set():
                    self.db.fail_letter_draft(vacancy_id, claim_id, "Подготовка прервана при закрытии агента.", cancelled=True)
                    return True
                if any(config[key] != self.settings[key] for key in ("ai", "candidate", "policy", "search", "submit")):
                    self.db.fail_letter_draft(vacancy_id, claim_id, "Настройки изменились во время подготовки.", cancelled=True)
                    return True
                self.db.complete_letter_draft(vacancy_id, claim_id, text, source=source, note=note, name_resume_id=resume_id)
                self.last_error = ""
            except (AIError, LetterPolicyError) as exc:
                self.last_error = str(exc)
                LOGGER.warning("Letter preparation failed for vacancy %s: %s", vacancy_id, exc)
                self.db.fail_letter_draft(vacancy_id, claim_id, str(exc))
            except StateError as exc:
                # A decision/edit made while Ollama was busy always wins.
                self.db.fail_letter_draft(vacancy_id, claim_id, str(exc))
            except Exception as exc:
                # Never put a draft, model output or candidate profile in logs.
                self.last_error = f"Не удалось подготовить письмо ({type(exc).__name__}). Повторите создание."
                LOGGER.error("Letter preparation failed for vacancy %s (%s)", vacancy_id, type(exc).__name__)
                self.db.fail_letter_draft(vacancy_id, claim_id, self.last_error)
            finally:
                self.current_id = None
            return True

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._wake.clear()
            try:
                if self.run_next():
                    continue
            except Exception as exc:
                self.last_error = f"Очередь писем недоступна ({type(exc).__name__})."
                LOGGER.error("Letter queue failed (%s)", type(exc).__name__)
            self._wake.wait(3)
