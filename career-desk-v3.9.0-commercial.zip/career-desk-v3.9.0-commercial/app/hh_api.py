from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable


API_ROOT = "https://api.hh.ru"
USER_AGENT = "hh-ai-recruiter/3.9.0 (local human-controlled job search assistant)"
LOGGER = logging.getLogger(__name__)


class HHApiError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None, *, kind: str = "http", stop_search: bool = False):
        super().__init__(message)
        self.status_code = status_code
        self.kind = kind
        self.stop_search = stop_search or status_code == 429

    @property
    def browser_fallback_allowed(self) -> bool:
        if self.stop_search:
            return False
        return self.kind == "network" or self.status_code in {403, 500, 502, 503, 504}


def validate_search_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise HHApiError("HH returned an unrecognized search response", kind="data", stop_search=True)
    if any(not isinstance(item, dict) or not str(item.get("id", "")).isdigit() for item in payload["items"]):
        raise HHApiError("HH search contains an invalid vacancy ID", kind="data", stop_search=True)
    found = payload.get("found")
    if found is not None and (type(found) is not int or found < 0 or found < len(payload["items"])):
        raise HHApiError("HH search contains an inconsistent result count", kind="data", stop_search=True)
    return payload


def _http_error(status: int, body: str) -> HHApiError:
    # Do not print arbitrary response bodies: they can contain session-bound URLs.
    if any(marker in body.casefold() for marker in ("verify you are human", "подтвердите, что вы не робот", "подтвердите что вы не робот", "checking your browser")):
        return HHApiError("HH API requests a manual access check", status, kind="captcha", stop_search=True)
    try:
        payload = json.loads(body)
    except (ValueError, TypeError):
        payload = {}
    errors = payload.get("errors", []) if isinstance(payload, dict) else []
    types = {str(item.get("type", "")) for item in errors if isinstance(item, dict)} if isinstance(errors, list) else set()
    request_id = str(payload.get("request_id", "")) if isinstance(payload, dict) else ""
    request_id = "".join(c for c in request_id if c.isalnum() or c in "-_")[:100]
    suffix = f"; request_id={request_id}" if request_id else ""
    if "captcha_required" in types:
        return HHApiError("HH API requests a manual CAPTCHA/access check" + suffix, status, kind="captcha", stop_search=True)
    if types & {"oauth", "api_access_payment", "manager_accounts"}:
        return HHApiError("HH API authorization or account access was denied; check the official API access" + suffix, status, kind="authorization", stop_search=True)
    if status == 429:
        return HHApiError("HH API rate limit reached (429); this cycle is stopped. Retry later" + suffix, status, kind="rate_limit", stop_search=True)
    if status == 403 and types - {"forbidden"}:
        return HHApiError("HH API denied this operation" + suffix, status, kind="authorization", stop_search=True)
    if status == 403 and isinstance(errors, list) and any(isinstance(item, dict) and (item.get("value") or item.get("description")) for item in errors):
        return HHApiError("HH API returned a specific access restriction" + suffix, status, kind="authorization", stop_search=True)
    return HHApiError(f"HH API HTTP {status}" + suffix, status)


@dataclass
class HHApiClient:
    timeout: int = 30
    retries: int = 2

    def _request(self, path: str, params: dict[str, Any] | None = None) -> Any:
        query = urllib.parse.urlencode({k: v for k, v in (params or {}).items() if v not in (None, "")}, doseq=True)
        url = API_ROOT + path + ("?" + query if query else "")
        request = urllib.request.Request(
            url,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json", "Accept-Language": "ru-RU,ru;q=0.9"},
            method="GET",
        )
        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    if response.status != 200:
                        raise HHApiError(f"HH API returned HTTP {response.status}", status_code=int(response.status))
                    payload = json.loads(response.read().decode("utf-8"))
                    return payload
            except urllib.error.HTTPError as exc:
                try:
                    body = exc.read(65536).decode("utf-8", errors="replace")
                finally:
                    exc.close()
                last_error = _http_error(exc.code, body)
                if exc.code not in {500, 502, 503, 504} or last_error.stop_search:
                    break
            except json.JSONDecodeError as exc:
                raise HHApiError("HH API returned non-JSON content", kind="data", stop_search=True) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = exc
            if attempt < self.retries:
                time.sleep(min(2 ** attempt, 4))
        if isinstance(last_error, HHApiError):
            raise last_error
        raise HHApiError(str(last_error or "unknown HH API error"), kind="network")

    def search(self, text: str, area_id: str, days: int = 1, per_page: int = 20, page: int = 0) -> dict[str, Any]:
        payload = self._request(
            "/vacancies",
            {
                "text": text,
                "search_field": "name",
                "area": area_id or None,
                "period": max(1, min(30, int(days))),
                "per_page": max(1, min(100, int(per_page))),
                "page": max(0, int(page)),
                "order_by": "publication_time",
            },
        )
        return validate_search_payload(payload)

    def vacancy(self, vacancy_id: str) -> dict[str, Any]:
        if not str(vacancy_id).isdigit():
            raise HHApiError("invalid vacancy id")
        payload = self._request(f"/vacancies/{vacancy_id}")
        if not isinstance(payload, dict):
            raise HHApiError("unexpected vacancy payload")
        if str(payload.get("id")) != str(vacancy_id):
            raise HHApiError("HH API returned a different vacancy ID", kind="data")
        payload["_source"] = "public_api"
        return payload

    def suggest_areas(self, text: str) -> list[dict[str, Any]]:
        payload = self._request("/suggests/areas", {"text": text})
        if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
            raise HHApiError("unexpected area suggestions payload")
        return [item for item in payload["items"] if isinstance(item, dict)]

    def resolve_area_id(self, name: str) -> str:
        wanted = " ".join(str(name).lower().replace("ё", "е").split())
        items = self.suggest_areas(name)
        exact: list[str] = []
        for item in items:
            label = " ".join(str(item.get("text") or item.get("name") or "").lower().replace("ё", "е").split())
            if label == wanted and item.get("id"):
                exact.append(str(item["id"]))
        if len(set(exact)) == 1:
            return exact[0]
        if len(items) == 1 and items[0].get("id"):
            return str(items[0]["id"])
        raise HHApiError(f"area name is ambiguous or unknown: {name}")

    def areas(self) -> list[dict[str, Any]]:
        payload = self._request("/areas")
        if isinstance(payload, list):
            return payload
        raise HHApiError("unexpected areas payload")


class HybridHHClient:
    """Read public API data, or ordinary HH web pages in the dedicated profile.

    A site login is not API OAuth authorization. Never repeat a denied API URL
    in Chromium. CAPTCHA, account restrictions and rate limits stop the cycle.
    """

    def __init__(
        self,
        api: HHApiClient | None = None,
        browser_factory: Callable[[], Any] | None = None,
    ):
        self.api = api or HHApiClient()
        self.browser_factory = browser_factory
        self._browser: Any | None = None
        self._fallback_active = False
        self.last_source = "public_api"
        self.last_api_error = ""
        self._terminal_error: HHApiError | None = None

    def _browser_client(self) -> Any:
        if self._browser is None:
            if self.browser_factory is not None:
                self._browser = self.browser_factory()
            else:
                from .hh_web import BrowserHHWebClient

                self._browser = BrowserHHWebClient(timeout=max(30, int(self.api.timeout)))
        return self._browser

    def _call(self, method: str, *args: Any, **kwargs: Any) -> Any:
        if self._terminal_error is not None:
            raise self._terminal_error
        if not self._fallback_active:
            try:
                value = getattr(self.api, method)(*args, **kwargs)
                self.last_source = "public_api"
                return value
            except HHApiError as exc:
                if not exc.browser_fallback_allowed:
                    if exc.stop_search:
                        self._terminal_error = exc
                    raise
                self.last_api_error = str(exc)
                self._fallback_active = True
                LOGGER.warning(
                    "Public HH API is unavailable (%s). Reading ordinary hh.ru pages in the dedicated Chromium profile.",
                    exc,
                )
        self.last_source = "authorized_browser_web"
        try:
            return getattr(self._browser_client(), method)(*args, **kwargs)
        except HHApiError as exc:
            if exc.stop_search:
                self._terminal_error = exc
            raise

    def search(self, text: str, area_id: str, days: int = 1, per_page: int = 20, page: int = 0) -> dict[str, Any]:
        return self._call("search", text, area_id, days, per_page, page)

    def vacancy(self, vacancy_id: str, *, source: str | None = None) -> dict[str, Any]:
        if source == "authorized_browser_web":
            self._fallback_active = True
        return self._call("vacancy", vacancy_id)

    def resume_recommendations(self, resume_id: str, per_page: int = 20, page: int = 0) -> dict[str, Any]:
        """Read the authenticated recommendation page; no public API analogue is assumed."""
        if self._terminal_error is not None:
            raise self._terminal_error
        self.last_source = "authorized_browser_resume_recommendations"
        try:
            return self._browser_client().resume_recommendations(resume_id, per_page, page)
        except HHApiError as exc:
            if exc.stop_search:
                self._terminal_error = exc
            raise

    def suggest_areas(self, text: str) -> list[dict[str, Any]]:
        # Dictionaries are separate from vacancy search. Never send these API
        # URLs through a logged-in browser or silently drop an unresolved area.
        return self.api.suggest_areas(text)

    def resolve_area_id(self, name: str) -> str:
        try:
            return self.api.resolve_area_id(name)
        except HHApiError as exc:
            raise HHApiError(
                f"Не удалось определить HH area_id региона «{name}». Укажите числовой area_id в настройках или отключите этот регион. {exc}",
                exc.status_code, kind=exc.kind, stop_search=exc.stop_search,
            ) from exc

    def areas(self) -> list[dict[str, Any]]:
        return self.api.areas()

    def close(self) -> None:
        if self._browser is not None:
            close = getattr(self._browser, "close", None)
            if callable(close):
                close()
            self._browser = None
        self._terminal_error = None
        self._fallback_active = False
