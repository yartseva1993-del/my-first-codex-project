from __future__ import annotations

import json
import time
from typing import Any, Callable
from urllib.parse import urlencode, urlsplit

from .browser_access import BrowserBusyError, PROFILE_ACCESS
from .hh_api import HHApiError
from .hh_web_parser import HHMarkupError, is_hh_web_url, layout_signature, parse_resume_recommendations_page, parse_search_page, parse_vacancy_page, vacancy_id_from_url
from .resume_refs import RESUME_TOKEN
from .paths import BROWSER_PROFILE, DIAGNOSTICS_DIR, ensure_directories


def search_page_url(text: str, area_id: str, days: int = 1, per_page: int = 20, page: int = 0) -> str:
    if not str(text).strip() or not str(area_id).isdigit():
        raise HHApiError("Для поиска hh.ru нужны непустой запрос и числовой area_id; глобальный поиск не выполняется", kind="filters", stop_search=True)
    days, per_page, page = max(1, min(30, int(days))), max(1, min(100, int(per_page))), max(0, int(page))
    page_size = next(size for size in (20, 50, 100) if size >= per_page)
    return "https://hh.ru/search/vacancy?" + urlencode({
        "text": str(text), "search_field": "name", "area": str(area_id),
        "search_period": days, "items_on_page": page_size, "page": page, "order_by": "publication_time",
    })


def resume_recommendations_page_url(resume_id: str, per_page: int = 20, page: int = 0) -> str:
    if not RESUME_TOKEN.fullmatch(str(resume_id or "")):
        raise HHApiError("Для подборки HH требуется корректный Resume ID", kind="filters", stop_search=True)
    per_page, page = max(1, min(100, int(per_page))), max(0, int(page))
    page_size = next(size for size in (20, 50, 100) if size >= per_page)
    return "https://hh.ru/search/vacancy?" + urlencode({
        "resume": str(resume_id), "from": "resumelist", "hhtmFrom": "applicant_profile",
        "items_on_page": page_size, "page": page,
    })


def allowed_document_url(url: str) -> bool:
    if not is_hh_web_url(url):
        return False
    path = urlsplit(url).path.rstrip("/")
    # Access screens may be displayed so the user can see the actual problem.
    # This reader never interacts with them.
    return bool(vacancy_id_from_url(url)) or path == "/search/vacancy" or any(
        path.startswith(prefix) for prefix in ("/captcha", "/account/captcha", "/account/login", "/account/signup", "/account/connect", "/vpncheeck")
    )


class BrowserHHWebClient:
    """Read ordinary pages using GET; no API calls, input, or form actions."""

    def __init__(self, timeout: int = 45, min_interval: float = 1.0):
        self.timeout = max(10, int(timeout))
        self.min_interval = max(0.0, float(min_interval))
        self._last_navigation = 0.0
        self._playwright: Any | None = None
        self._context: Any | None = None
        self._page: Any | None = None
        self._profile_acquired = False

    @staticmethod
    def _save_layout(source: str, kind: str) -> None:
        ensure_directories()
        report = {"page_kind": kind, **layout_signature(source)}
        (DIAGNOSTICS_DIR / f"web-layout-{kind}.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def _read_only_route(route: Any) -> None:
        request = route.request
        if request.method.upper() not in {"GET", "HEAD"}:
            route.abort()
            return
        if (urlsplit(request.url).hostname or "").lower() == "api.hh.ru":
            route.abort()
            return
        if request.is_navigation_request() and not allowed_document_url(request.url):
            route.abort()
            return
        route.continue_()

    def _ensure_page(self) -> Any:
        if self._context is not None:
            try:
                pages = [page for page in self._context.pages if not page.is_closed()]
                self._page = pages[-1] if pages else self._context.new_page()
                return self._page
            except Exception:
                self.close()
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise HHApiError("Playwright is unavailable; run SETUP_WINDOWS.cmd", kind="browser", stop_search=True) from exc
        ensure_directories()
        try:
            PROFILE_ACCESS.acquire("чтение вакансий")
            self._profile_acquired = True
            self._playwright = sync_playwright().start()
            self._context = self._playwright.chromium.launch_persistent_context(
                user_data_dir=str(BROWSER_PROFILE), headless=False, locale="ru-RU",
                viewport={"width": 1360, "height": 900}, accept_downloads=False,
                service_workers="block",
            )
            self._context.route("**/*", self._read_only_route)
            pages = [page for page in self._context.pages if not page.is_closed()]
            self._page = pages[-1] if pages else self._context.new_page()
            return self._page
        except Exception as exc:
            self.close()
            if isinstance(exc, BrowserBusyError):
                raise HHApiError(str(exc), kind="browser_busy", stop_search=True) from exc
            raise HHApiError(
                "Не удалось открыть отдельный Chromium для поиска. Закройте его другие окна и повторите диагностику. "
                f"Browser error: {type(exc).__name__}", kind="browser", stop_search=True,
            ) from exc

    def _read(self, url: str, parser: Callable[..., dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        if not allowed_document_url(url):
            raise HHApiError("Unsupported HH read-only page URL", kind="url", stop_search=True)
        page = self._ensure_page()
        delay = self.min_interval - (time.monotonic() - self._last_navigation)
        if delay > 0:
            time.sleep(delay)
        self._last_navigation = time.monotonic()
        try:
            response = page.goto(url, wait_until="domcontentloaded", timeout=self.timeout * 1000)
            if response is None:
                raise HHApiError("HH page navigation returned no HTTP response", kind="network", stop_search=True)
            status = int(response.status)
            try:
                return parser(page.content(), page.url, status=status, **kwargs)
            except HHMarkupError:
                # A React page may still be rendering. Wait once for content,
                # without another request or a reload of an access screen.
                try:
                    page.wait_for_function(
                        """() => !!document.querySelector('[data-qa="serp-item__title"], [data-qa="vacancy-serp__vacancy-title"], [data-qa="vacancy-description"]')
                        || /ничего не найдено|вакансии не найдены|подходящих вакансий не найдено/i.test(document.body?.innerText || '')""",
                        timeout=min(self.timeout * 1000, 10000),
                    )
                except Exception:
                    pass
                return parser(page.content(), page.url, status=status, **kwargs)
        except HHApiError as exc:
            if isinstance(exc, HHMarkupError):
                exc.stop_search = parser in {parse_search_page, parse_resume_recommendations_page}
                try:
                    kind = "recommendations" if parser is parse_resume_recommendations_page else ("search" if parser is parse_search_page else "vacancy")
                    self._save_layout(page.content(), kind)
                except Exception:
                    pass
            raise
        except Exception as exc:
            raise HHApiError(
                f"Не удалось прочитать страницу hh.ru ({type(exc).__name__}). Поиск остановлен; проверьте доступ в отдельном Chromium.",
                kind="browser", stop_search=True,
            ) from exc

    def search(self, text: str, area_id: str, days: int = 1, per_page: int = 20, page: int = 0) -> dict[str, Any]:
        url = search_page_url(text, area_id, days, per_page, page)
        days, per_page, page = max(1, min(30, int(days))), max(1, min(100, int(per_page))), max(0, int(page))
        return self._read(
            url, parse_search_page,
            text=str(text), area_id=str(area_id), days=days, per_page=per_page, page=page,
        )

    def vacancy(self, vacancy_id: str) -> dict[str, Any]:
        if not str(vacancy_id).isdigit():
            raise HHApiError("Invalid vacancy ID", kind="data")
        return self._read(f"https://hh.ru/vacancy/{vacancy_id}", parse_vacancy_page, vacancy_id=str(vacancy_id))

    def resume_recommendations(self, resume_id: str, per_page: int = 20, page: int = 0) -> dict[str, Any]:
        url = resume_recommendations_page_url(resume_id, per_page, page)
        return self._read(
            url,
            parse_resume_recommendations_page,
            resume_id=str(resume_id),
            per_page=max(1, min(100, int(per_page))),
            page=max(0, int(page)),
        )

    def close(self) -> None:
        context, playwright = self._context, self._playwright
        self._page = self._context = self._playwright = None
        if context is not None:
            try:
                context.close()
            except Exception:
                pass
        if playwright is not None:
            try:
                playwright.stop()
            except Exception:
                pass
        if self._profile_acquired:
            self._profile_acquired = False
            PROFILE_ACCESS.release()
