"""Parse public HH page content without calling undocumented web APIs.

Only complete, identified vacancy pages are accepted. Missing or unfamiliar
markup is an error, never a made-up vacancy or a successful empty search.
"""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any, Iterator
from urllib.parse import parse_qs, urljoin, urlsplit, urlunsplit

from .hh_api import HHApiError


WEB_SOURCE = "authorized_browser_web"
RECOMMENDATION_SOURCE = "authorized_browser_resume_recommendations"
_VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


class HHMarkupError(HHApiError):
    def __init__(self, message: str):
        super().__init__(message, kind="markup")


def compact(value: Any) -> str:
    return " ".join(str(value or "").split())


@dataclass
class Node:
    tag: str
    attrs: dict[str, str] = field(default_factory=dict)
    children: list[Any] = field(default_factory=list)

    def walk(self) -> Iterator[Node]:
        yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.walk()

    def text(self, *, raw: bool = False) -> str:
        if not raw and (self.tag in {"script", "style", "noscript", "template"} or "hidden" in self.attrs or self.attrs.get("aria-hidden") == "true"):
            return ""
        parts = [child.text(raw=raw) if isinstance(child, Node) else child for child in self.children]
        return ("" if raw else " ").join(parts)


class _Document(HTMLParser):
    def __init__(self, source: str):
        super().__init__(convert_charrefs=True)
        self.root = Node("document")
        self.stack = [self.root]
        self.feed(source)
        self.close()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        node = Node(tag, {key: value or "" for key, value in attrs})
        self.stack[-1].children.append(node)
        if tag not in _VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag not in _VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        self.stack[-1].children.append(data)


def _qa(root: Node, *names: str) -> Node | None:
    for name in names:
        for node in root.walk():
            if node.attrs.get("data-qa") == name and compact(node.text()):
                return node
    return None


def _qa_text(root: Node, *names: str) -> str:
    node = _qa(root, *names)
    return compact(node.text()) if node else ""


def is_hh_web_url(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        host = (parsed.hostname or "").lower()
        return (
            parsed.scheme == "https" and parsed.port in {None, 443}
            and not parsed.username and not parsed.password
            and host != "api.hh.ru" and (host == "hh.ru" or host.endswith(".hh.ru"))
        )
    except ValueError:
        return False


def vacancy_id_from_url(url: str, base: str = "https://hh.ru") -> str | None:
    absolute = urljoin(base, url)
    if not is_hh_web_url(absolute):
        return None
    match = re.fullmatch(r"/vacancy/([0-9]+)/?", urlsplit(absolute).path)
    return match.group(1) if match else None


def guard_page(root: Node, url: str, status: int) -> None:
    if not is_hh_web_url(url):
        # Name the offending address. Without it the message says only that
        # the page "left hh.ru", which is not diagnosable: the cause could be
        # a blocked redirect, an unnavigated about:blank tab, or a genuine
        # redirect off-site, and they need different fixes.
        parsed = urlsplit(url or "")
        where = urlunsplit((parsed.scheme, parsed.hostname or "", parsed.path, "", "")) or "(адрес пуст)"
        raise HHApiError(
            f"Страница вышла за пределы https://hh.ru — фактический адрес: {where}",
            status, kind="access", stop_search=True,
        )
    path = urlsplit(url).path.lower()
    text = compact(root.text()).lower().replace("ё", "е")
    if "vpncheeck" in path or "vpn мешает работе сайта" in text:
        raise HHApiError(
            "hh.ru показывает «VPN мешает работе сайта». Поиск остановлен. "
            "Проверьте доступ к hh.ru в этой сети; если VPN не используется, обратитесь в поддержку hh.ru. "
            "Переустановка агента и повторный вход не устраняют это ограничение.",
            status, kind="vpn", stop_search=True,
        )
    captcha_controls = any(
        node.tag in {"input", "iframe"} and "captcha" in " ".join(node.attrs.get(key, "") for key in ("name", "id", "src")).lower()
        for node in root.walk()
    )
    if "captcha" in path or captcha_controls or any(marker in text for marker in (
        "подтвердите, что вы не робот", "подтвердите что вы не робот", "проверка, что вы не робот",
        "verify you are human", "checking your browser", "доступ временно ограничен",
    )):
        raise HHApiError("hh.ru требует ручную проверку доступа. Поиск остановлен; автоматического прохождения проверки нет.", status, kind="captcha", stop_search=True)
    if any(marker in path for marker in ("/account/login", "/account/signup", "/account/connect")):
        raise HHApiError("hh.ru требует вход. Запустите LOGIN_HH_WINDOWS.cmd, затем повторите диагностику.", status, kind="login", stop_search=True)
    if status == 429:
        raise HHApiError("hh.ru ограничил частоту запросов (429). Цикл остановлен; повторите позже.", status, kind="rate_limit", stop_search=True)
    if status != 200:
        raise HHApiError(f"Страница hh.ru вернула HTTP {status}. Доступ не подтверждён; поиск остановлен.", status, kind="access", stop_search=status not in {404, 410})


def _document(source: str, url: str, status: int) -> Node:
    if not isinstance(source, str) or len(source) > 12_000_000:
        raise HHMarkupError("HH page content is invalid or too large")
    root = _Document(source).root
    guard_page(root, url, status)
    return root


def layout_signature(source: str) -> dict[str, Any]:
    """Record schema clues, never HTML, text, links, form values or profile data."""
    root = _Document(source[:12_000_000]).root
    tags = {key: 0 for key in ("h1", "h2", "a", "iframe", "script", "form")}
    markers: dict[str, int] = {}
    for node in root.walk():
        if node.tag in tags:
            tags[node.tag] += 1
        marker = node.attrs.get("data-qa", "")
        if re.fullmatch(r"(?:vacancy|vacancies|serp|search|pager)[a-z_:.-]{0,70}", marker):
            markers[marker] = markers.get(marker, 0) + 1
    return {"tags": tags, "page_markers": dict(sorted(markers.items())[:100]), "job_posting_count": len(_json_jobs(root))}


def parse_search_page(source: str, url: str, *, text: str, area_id: str, days: int, per_page: int, page: int = 0, status: int = 200) -> dict[str, Any]:
    root = _document(source, url, status)
    parsed = urlsplit(url)
    if parsed.path.rstrip("/") != "/search/vacancy":
        raise HHMarkupError("HH did not open the requested vacancy search page")
    query = parse_qs(parsed.query)
    expected = {"text": str(text), "area": str(area_id), "search_field": "name", "search_period": str(days)}
    if any(query.get(key) != [value] for key, value in expected.items()) or query.get("page", ["0"]) != [str(page)]:
        raise HHApiError("HH search filters changed during navigation; title, region and period are not confirmed", kind="filters", stop_search=True)
    visible = compact(root.text()).lower()
    headings = " ".join(compact(node.text()).lower() for node in root.walk() if node.tag == "h1" or node.attrs.get("data-qa") == "vacancies-search-header")
    count_match = re.search(r"(?:найден[оаы]?\s+)?([0-9][0-9 ]*)\s+ваканси", headings)
    found = int(count_match.group(1).replace(" ", "")) if count_match else None
    empty = any(marker in visible for marker in (
        "по вашему запросу ничего не найдено", "ничего не найдено", "вакансии не найдены",
        "подходящих вакансий не найдено", "не нашли вакансий по вашему запросу",
    )) or found == 0
    # HH can show recommended cards below its explicit no-results message.
    if empty:
        return {"items": [], "found": 0, "pages": 0, "page": page, "per_page": per_page, "_source": WEB_SOURCE}
    items: dict[str, dict[str, Any]] = {}
    for node in root.walk():
        if node.tag != "a" or node.attrs.get("data-qa") not in {"serp-item__title", "vacancy-serp__vacancy-title"}:
            continue
        vacancy_id = vacancy_id_from_url(node.attrs.get("href", ""), url)
        title = compact(node.text())
        if vacancy_id and title:
            items.setdefault(vacancy_id, {"id": vacancy_id, "name": title, "alternate_url": f"https://hh.ru/vacancy/{vacancy_id}"})
    if not items:
        raise HHMarkupError("Не распознана выдача hh.ru: нет подтверждённых карточек или сообщения о пустом результате")
    if found is not None and found < len(items):
        raise HHMarkupError("HH search result count does not match its cards")
    count = found if found is not None else len(items)
    requested_size = max(1, min(100, int(per_page)))
    actual_size = next(size for size in (20, 50, 100) if size >= requested_size)
    return {
        "items": list(items.values())[:requested_size], "found": count,
        "pages": math.ceil(count / actual_size), "page": page, "per_page": actual_size,
        "_source": WEB_SOURCE, "_found_exact": found is not None,
    }


def parse_resume_recommendations_page(
    source: str,
    url: str,
    *,
    resume_id: str,
    per_page: int,
    page: int = 0,
    status: int = 200,
) -> dict[str, Any]:
    """Parse HH's own vacancy collection for one selected resume."""
    root = _document(source, url, status)
    parsed = urlsplit(url)
    if parsed.path.rstrip("/") != "/search/vacancy":
        raise HHMarkupError("HH did not open the selected-resume vacancy collection")
    query = parse_qs(parsed.query)
    if (
        query.get("resume") != [str(resume_id)]
        or query.get("page", ["0"]) != [str(page)]
        or query.get("from") != ["resumelist"]
    ):
        raise HHApiError(
            "HH changed the selected resume or recommendation page during navigation",
            kind="filters",
            stop_search=True,
        )
    visible = compact(root.text()).lower()
    headings = " ".join(
        compact(node.text()).lower()
        for node in root.walk()
        if node.tag == "h1" or node.attrs.get("data-qa") == "vacancies-search-header"
    )
    count_match = re.search(r"(?:найден[оаы]?\s+)?([0-9][0-9 ]*)\s+ваканси", headings)
    found = int(count_match.group(1).replace(" ", "")) if count_match else None
    empty = any(marker in visible for marker in (
        "подходящих вакансий не найдено", "вакансии не найдены", "ничего не найдено",
        "не нашли вакансий по вашему запросу",
    )) or found == 0
    if empty:
        return {
            "items": [], "found": 0, "pages": 0, "page": page,
            "per_page": per_page, "_source": RECOMMENDATION_SOURCE,
        }
    items: dict[str, dict[str, Any]] = {}
    for node in root.walk():
        if node.tag != "a" or node.attrs.get("data-qa") not in {"serp-item__title", "vacancy-serp__vacancy-title"}:
            continue
        vacancy_id = vacancy_id_from_url(node.attrs.get("href", ""), url)
        title = compact(node.text())
        if vacancy_id and title:
            items.setdefault(vacancy_id, {
                "id": vacancy_id,
                "name": title,
                "alternate_url": f"https://hh.ru/vacancy/{vacancy_id}",
            })
    if not items:
        raise HHMarkupError("Не распознана подборка вакансий HH для выбранного резюме")
    requested_size = max(1, min(100, int(per_page)))
    actual_size = next(size for size in (20, 50, 100) if size >= requested_size)
    count = found if found is not None else len(items)
    return {
        "items": list(items.values())[:requested_size], "found": count,
        "pages": math.ceil(count / actual_size) if found is not None else page + 2,
        "page": page, "per_page": actual_size,
        "_source": RECOMMENDATION_SOURCE, "_found_exact": found is not None,
    }


def _json_jobs(root: Node) -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []

    def collect(value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                collect(item)
        elif isinstance(value, dict):
            types = value.get("@type")
            if types == "JobPosting" or (isinstance(types, list) and "JobPosting" in types):
                jobs.append(value)
            if "@graph" in value:
                collect(value["@graph"])

    for node in root.walk():
        if node.tag == "script" and node.attrs.get("type", "").split(";", 1)[0].lower() == "application/ld+json":
            try:
                collect(json.loads(node.text(raw=True)))
            except (ValueError, RecursionError):
                continue
    return jobs


def _job_id(job: dict[str, Any]) -> str | None:
    value = job.get("identifier")
    if isinstance(value, dict):
        value = value.get("value")
    if isinstance(value, (str, int)) and str(value).isdigit():
        return str(value)
    for key in ("url", "@id"):
        result = vacancy_id_from_url(str(job.get(key, "")))
        if result:
            return result
    return None


def _plain_html(source: Any) -> str:
    return compact(_Document(str(source or "")).root.text())


def parse_salary(text: str, structured: Any = None) -> dict[str, Any] | None:
    """Preserve unknown taxes and units. Never compare shift/hour pay to monthly pay."""
    label = compact(text).lower()
    if label and any(marker in label for marker in ("за смен", "за час", "в час", "за вахт", "за год", "за неделю", "за услуг")):
        return None
    monthly = "месяц" in label
    currency = None
    for marker, code in (("₽", "RUR"), ("руб", "RUR"), ("rub", "RUR"), ("rur", "RUR"), ("$", "USD"), ("usd", "USD"), ("€", "EUR"), ("eur", "EUR"), ("₸", "KZT")):
        if marker in label:
            currency = code
            break
    values = [int(value.replace(" ", "")) for value in re.findall(r"[0-9]+(?: [0-9]{3})*", label)]
    low: int | float | None = None
    high: int | float | None = None
    if monthly and currency and 1 <= len(values) <= 2:
        if len(values) == 2:
            low, high = values
        elif label.startswith("до "):
            high = values[0]
        elif label.startswith("от "):
            low = values[0]
        else:
            low = high = values[0]
    elif isinstance(structured, dict):
        value = structured.get("value")
        if not isinstance(value, dict) or str(value.get("unitText", "")).upper() not in {"MONTH", "MONTHLY"}:
            return None
        currency = str(structured.get("currency") or "").upper()
        currency = "RUR" if currency == "RUB" else currency
        low, high = value.get("minValue"), value.get("maxValue")
        if low is None and high is None:
            low = high = value.get("value")
    else:
        return None
    if not currency or all(value is None for value in (low, high)):
        return None
    if any(value is not None and (type(value) not in {int, float} or not math.isfinite(value) or value < 0) for value in (low, high)):
        return None
    if low is not None and high is not None and low > high:
        return None
    gross = True if "до вычета налогов" in label else False if "на руки" in label else None
    return {"from": low, "to": high, "currency": currency, "gross": gross}


def parse_vacancy_page(source: str, url: str, vacancy_id: str, *, status: int = 200) -> dict[str, Any]:
    root = _document(source, url, status)
    vacancy_id = str(vacancy_id)
    if vacancy_id_from_url(url) != vacancy_id:
        raise HHMarkupError("HH page does not belong to the requested vacancy ID")
    for node in root.walk():
        if node.tag == "link" and node.attrs.get("rel") == "canonical":
            if vacancy_id_from_url(node.attrs.get("href", ""), url) != vacancy_id:
                raise HHMarkupError("HH canonical URL identifies a different vacancy")
    title = _qa_text(root, "vacancy-title")
    if not title:
        headings = [compact(node.text()) for node in root.walk() if node.tag == "h1" and compact(node.text())]
        if len(headings) == 1:
            title = headings[0]
    if not title:
        raise HHMarkupError("HH vacancy title is missing or ambiguous")
    jobs = _json_jobs(root)
    matches = [job for job in jobs if _job_id(job) == vacancy_id]
    if not matches:
        matches = [job for job in jobs if _job_id(job) is None and compact(job.get("title")).casefold() == title.casefold()]
    if jobs and len(matches) != 1:
        raise HHMarkupError("HH JobPosting metadata cannot be bound to this vacancy")
    job = matches[0] if matches else {}
    # A JobPosting whose title disagrees with the page heading is untrustworthy
    # metadata, not a broken page: hh.ru normalises or suffixes the title in
    # its JSON-LD often enough that aborting the whole vacancy is wrong. The
    # canonical-URL check above already guarantees this is the right vacancy,
    # so the safe response is to drop the metadata and read the visible markup,
    # which carries employer, description, area and salary anyway.
    if job.get("title") and compact(job["title"]).casefold() != title.casefold():
        job = {}
    employer_node = _qa(root, "vacancy-company-name", "vacancy-company-name-wrapper")
    employer_name = compact(employer_node.text()) if employer_node else ""
    organization = job.get("hiringOrganization") or {}
    if not employer_name and isinstance(organization, dict):
        employer_name = compact(organization.get("name"))
    employer_id = ""
    if employer_node:
        for node in employer_node.walk():
            parsed = urlsplit(urljoin(url, node.attrs.get("href", "")))
            match = re.fullmatch(r"/employer/([0-9]+)/?", parsed.path)
            if node.tag == "a" and match and is_hh_web_url(urljoin(url, node.attrs.get("href", ""))):
                employer_id = match.group(1)
                break
    description = _qa_text(root, "vacancy-description") or _plain_html(job.get("description"))
    locations = job.get("jobLocation") or []
    if isinstance(locations, dict):
        locations = [locations]
    localities = []
    if isinstance(locations, list):
        for location in locations:
            address = location.get("address") if isinstance(location, dict) else None
            if isinstance(address, dict) and address.get("addressLocality"):
                localities.append(compact(address["addressLocality"]))
    area = " / ".join(dict.fromkeys(localities)) or _qa_text(root, "vacancy-view-location", "vacancy-view-raw-address", "vacancy-view-location-text")
    if not employer_name or len(description) < 40 or not area:
        raise HHMarkupError("Неполная карточка hh.ru: требуется работодатель, полное описание и место работы. Вакансия не добавлена")
    salary_label = _qa_text(root, "vacancy-salary", "vacancy-salary-compensation-type-net", "vacancy-salary-compensation-type-gross", "vacancy-salary-amount")
    salary = parse_salary(salary_label, job.get("baseSalary"))
    if salary_label:
        description += "\nУсловия оплаты на странице: " + salary_label
    text = compact(root.text()).lower()
    archived = any(marker in text for marker in ("вакансия в архиве", "вакансия закрыта", "вакансия перенесена в архив"))
    test_required = any(marker in text for marker in ("для отклика необходимо пройти тест", "чтобы откликнуться, пройдите тест", "откликнуться с прохождением теста"))
    skills = sorted({compact(node.text()) for node in root.walk() if node.attrs.get("data-qa") == "skills-element" and compact(node.text())})
    return {
        "id": vacancy_id, "name": title, "description": description,
        "employer": {"id": employer_id or None, "name": employer_name},
        "area": {"id": None, "name": area}, "salary": salary,
        "published_at": job.get("datePosted") or None,
        "key_skills": [{"name": skill} for skill in skills],
        "alternate_url": f"https://hh.ru/vacancy/{vacancy_id}",
        "apply_alternate_url": f"https://hh.ru/applicant/vacancy_response?vacancyId={vacancy_id}",
        "archived": archived, "has_test": True if test_required else None,
        "_source": WEB_SOURCE,
    }
