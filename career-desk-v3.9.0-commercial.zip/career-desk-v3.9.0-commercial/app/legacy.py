from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path

from .paths import DATA_ROOT, PROJECT_ROOT


@dataclass
class LegacyProcess:
    pid: int
    command: str


def find_legacy_processes() -> list[LegacyProcess]:
    try:
        import psutil
    except ImportError:
        return []
    current = os.getpid()
    current_root = str(PROJECT_ROOT).lower()
    found: list[LegacyProcess] = []
    for process in psutil.process_iter(["pid", "cmdline"]):
        try:
            pid = int(process.info["pid"])
            command = " ".join(process.info.get("cmdline") or [])
            lower = command.lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
            continue
        if pid == current or current_root in lower:
            continue
        if ("hh-ai-agent" in lower or "hh-ai-recruiter" in lower) and ("python" in lower or "uvicorn" in lower):
            found.append(LegacyProcess(pid, command[:500]))
    return found


def stop_legacy_processes(processes: list[LegacyProcess]) -> list[int]:
    import psutil
    stopped: list[int] = []
    for item in processes:
        try:
            process = psutil.Process(item.pid)
            process.terminate()
            process.wait(timeout=8)
            stopped.append(item.pid)
        except psutil.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            stopped.append(item.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return stopped


def _candidate_legacy_roots() -> list[Path]:
    roots: list[Path] = []
    home = Path.home()
    for parent in (home / "Downloads", home / "Desktop"):
        if not parent.exists():
            continue
        for pattern in ("hh-ai-agent*", "hh-ai-recruiter*"):
            roots.extend(path for path in parent.glob(pattern) if path.is_dir())
            for outer in parent.glob(pattern):
                if outer.is_dir():
                    roots.extend(path for path in outer.glob(pattern) if path.is_dir())
    unique = []
    seen = set()
    for root in roots:
        resolved = root.resolve()
        if resolved == PROJECT_ROOT.resolve() or resolved == DATA_ROOT.resolve() or resolved in seen:
            continue
        seen.add(resolved)
        unique.append(resolved)
    return unique


def disable_legacy_auth_artifacts() -> list[tuple[str, str]]:
    moved: list[tuple[str, str]] = []
    stamp = time.strftime("%Y%m%d-%H%M%S")
    relative_targets = (
        Path("browser-profile"), Path("data/browser-profile"),
        Path("storage_state.json"), Path("data/storage_state.json"),
        Path(".setup-complete"), Path("data/.setup-complete"),
    )
    for root in _candidate_legacy_roots():
        for relative in relative_targets:
            source = root / relative
            if not source.exists():
                continue
            target = source.with_name(source.name + f".disabled-by-v3-{stamp}")
            try:
                source.rename(target)
                moved.append((str(source), str(target)))
            except OSError:
                continue
    return moved


def interactive_legacy_guard() -> None:
    processes = find_legacy_processes()
    if processes:
        print("Legacy agent processes were detected. They can still use old browser sessions:")
        for item in processes:
            print(f"  PID {item.pid}: {item.command}")
        answer = input("Stop only these verified legacy agent processes? [y/N]: ").strip().lower()
        if answer == "y":
            print("Stopped PIDs:", stop_legacy_processes(processes))
        else:
            raise RuntimeError("setup stopped: legacy agents must be closed before v3 starts")
    answer = input("Recoverably disable hh.ru auth artifacts in old agent folders? [Y/n]: ").strip().lower()
    if answer in {"", "y"}:
        moved = disable_legacy_auth_artifacts()
        print(f"Disabled {len(moved)} legacy auth artifact(s). Renamed copies can be restored manually.")

