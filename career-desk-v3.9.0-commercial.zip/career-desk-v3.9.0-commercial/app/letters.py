from __future__ import annotations

import html
import re
from typing import Any


class LetterPolicyError(ValueError):
    pass


NAME_PLACEHOLDER = re.compile(
    r"(?:\[|\{\{?|<)\s*(?:(?:ваш[еи]?|your)\s+)?(?:имя(?:\s+и\s+фамилия)?|ф\.?и\.?о\.?|name|full[_ ]?name)\s*(?:\]|\}\}?|>)",
    re.IGNORECASE,
)
OTHER_PLACEHOLDER = re.compile(r"\[(?:ваш|укаж|встав|название|фамили|отчеств|должност|телефон|email)[^\]\n]{0,80}\]|\{\{[^{}\n]{1,80}\}\}", re.IGNORECASE)


def validate_no_placeholders(text: str) -> None:
    if NAME_PLACEHOLDER.search(text) or OTHER_PLACEHOLDER.search(text):
        raise LetterPolicyError("В письме остался незаполненный шаблон. Обновите имя из резюме и создайте письмо заново либо исправьте текст вручную.")


def strip_name_placeholders(text: str) -> str:
    """Remove name placeholders a model may leave in a generated letter.

    The agent no longer reads, stores or inserts the applicant's name.
    hh.ru attaches the selected resume to every response, so the employer
    sees the name there; carrying it in the letter added nothing and the
    machinery around it blocked sending for a week.
    """
    text = NAME_PLACEHOLDER.sub("", text.strip())
    # An empty signature is worse than no signature.
    text = re.sub(r"\n*\s*с\s+уважением[,!\s]*$", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    validate_no_placeholders(text)
    return text


def add_profile_signature(text: str, settings: dict[str, Any]) -> str:
    name = str(settings['candidate'].get('full_name') or '').strip()
    if name and name not in text:
        text = text.rstrip() + '\n\nС уважением,\n' + name
    return text


def profile_letter(vacancy: dict[str, Any], settings: dict[str, Any]) -> str:
    """A usable local draft, made only from the user's stored profile facts.

    This is deliberately identified as a profile draft in the UI. It does not
    impersonate an Ollama result, infer employment history, or invent a name.
    """
    def plain(value: Any) -> str:
        return " ".join(html.unescape(re.sub(r'<[^>]*>', ' ', str(value or ''))).split())

    candidate = settings['candidate']
    from .edition import EDITION
    if EDITION == 'commercial' and not candidate.get('profile', '').strip():
        raise LetterPolicyError('Сначала загрузите резюме в настройках и примените проверенный профиль.')
    title = plain(vacancy.get('name'))[:240]
    employer = plain((vacancy.get('employer') or {}).get('name'))[:180]
    headline = plain(candidate.get('headline'))[:240].rstrip('.')
    profile = plain(candidate.get('profile'))
    # Keep complete sentences/facts. Never cut a number or qualification in half.
    if len(profile) > 1300:
        sentences = re.split(r'(?<=[.!?])\s+', profile)
        kept = []
        for sentence in sentences:
            if len(' '.join(kept + [sentence])) > 1300:
                break
            kept.append(sentence)
        profile = ' '.join(kept)
    company = f' в компании «{employer}»' if employer else ''
    parts = ['Добрый день.', f'Прошу рассмотреть мою кандидатуру на вакансию «{title}»{company}.']
    if profile:
        parts.append(profile)
    elif headline:
        parts.append('Мой профессиональный профиль — ' + headline + '.')
    facts = []
    for fact in candidate.get('achievements') or []:
        clean = plain(fact).rstrip('.;')
        if clean and len(clean) <= 420:
            facts.append(clean)
        if len(facts) == 3:
            break
    if facts:
        parts.append('Из моего опыта: ' + '; '.join(facts) + '.')
    parts.append('Буду рад обсудить задачи вакансии, ожидаемые результаты и то, чем мой опыт может быть полезен вашей команде.')
    text = '\n\n'.join(parts)
    text = add_profile_signature(strip_name_placeholders(text), settings)
    return validate_cover_letter(text, settings)


def _compact_number(value: int) -> tuple[str, ...]:
    thousands = value // 1000
    return (
        str(value),
        f"{value:,}".replace(",", " "),
        f"{thousands} тыс",
        f"{thousands} 000",
    )


def validate_cover_letter(text: str, settings: dict[str, Any]) -> str:
    clean = text.strip()
    validate_no_placeholders(clean)
    if not 80 <= len(clean) <= 4000:
        raise LetterPolicyError("Письмо должно содержать от 80 до 4000 символов.")
    normalized = clean.lower().replace("ё", "е").replace("\u00a0", " ")
    if not normalized.startswith("добрый день"):
        raise LetterPolicyError("Письмо должно начинаться с «Добрый день.».")
    for banned in ("конфиденциальный объект", "секретный объект"):
        if banned in normalized:
            raise LetterPolicyError("В письме обнаружена конфиденциальная или запрещённая информация.")
    internal_target = int(settings["candidate"]["internal_salary_target"])
    salary_context = re.compile(r"(зарплат|компенсац|на руки|ожидани|ориентир).{0,50}", re.IGNORECASE | re.DOTALL)
    for representation in _compact_number(internal_target):
        if representation in normalized:
            position = normalized.find(representation)
            nearby = normalized[max(0, position - 60):position + len(representation) + 60]
            if salary_context.search(nearby):
                raise LetterPolicyError("В письме нельзя раскрывать внутренний зарплатный ориентир.")
    return clean
