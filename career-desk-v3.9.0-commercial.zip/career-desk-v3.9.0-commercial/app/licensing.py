"""Offline device-bound Ed25519 licenses. Private issuer key is never distributed."""
import base64
import hashlib
import json
import os
import platform
import tempfile
import time
from pathlib import Path
from .edition import EDITION, PUBLIC_KEY
from .paths import DATA_ROOT

class LicenseError(ValueError):
    pass

def device_code():
    if os.name == 'nt':
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography',0,winreg.KEY_READ|winreg.KEY_WOW64_64KEY) as key:
            raw = str(winreg.QueryValueEx(key,'MachineGuid')[0])
    else:
        p=Path('/etc/machine-id')
        raw=p.read_text().strip() if p.exists() else platform.node()
    return hashlib.sha256(('career-desk-v1:'+raw).encode()).hexdigest()[:32]

def decode_license(token, public_key=PUBLIC_KEY, device=None, now=None):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        if not isinstance(token,str) or len(token)>12000: raise ValueError()
        body,sig=token.strip().split('.')
        raw=base64.urlsafe_b64decode(body+'='*(-len(body)%4))
        signature=base64.urlsafe_b64decode(sig+'='*(-len(sig)%4))
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key)).verify(signature,raw)
        data=json.loads(raw)
        current=int(time.time() if now is None else now)
        if (data['product']!='career-desk-construction' or data['device']!=(device or device_code())
            or type(data['expires']) is not int or type(data['issued']) is not int
            or not data['issued'] <= current < data['expires'] or not isinstance(data['license_id'],str)):
            raise ValueError()
        return data
    except Exception as exc:
        raise LicenseError('Лицензия недействительна, истекла или выдана для другого компьютера.') from exc

def status():
    if EDITION=='personal': return {'edition':EDITION,'active':True,'message':'Личная редакция'}
    try:
        data=decode_license((DATA_ROOT/'license.key').read_text(encoding='ascii'))
        return {'edition':EDITION,'active':True,'expires':data['expires'],'license_id':data['license_id'],'device':device_code()}
    except (LicenseError,OSError):
        return {'edition':EDITION,'active':False,'device':device_code(),'message':'Введите лицензию для этого компьютера в настройках.'}

def require_license():
    if not status()['active']: raise LicenseError('Для этого действия нужна действующая лицензия.')

def activate(token):
    if EDITION=='personal': return status()
    decode_license(token)
    DATA_ROOT.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(dir=DATA_ROOT,prefix='license-',suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='ascii') as f:f.write(token.strip())
        os.replace(temp,DATA_ROOT/'license.key')
    finally:
        if os.path.exists(temp):os.unlink(temp)
    return status()
