from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from .paths import LOG_FILE, ensure_directories


def configure_logging() -> None:
    ensure_directories()
    root = logging.getLogger()
    if getattr(root, "_hh_v3_configured", False):
        return
    root.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    file_handler = RotatingFileHandler(LOG_FILE, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    file_handler.setFormatter(formatter)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(file_handler)
    root.addHandler(console)
    root._hh_v3_configured = True  # type: ignore[attr-defined]

