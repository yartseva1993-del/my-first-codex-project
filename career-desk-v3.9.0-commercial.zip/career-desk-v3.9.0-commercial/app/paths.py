from __future__ import annotations

import os
from pathlib import Path
from .edition import EDITION


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _local_app_data() -> Path:
    override = os.environ.get("HH_AGENT_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    folder = "career-desk-construction" if EDITION == "commercial" else "hh-ai-recruiter"
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / folder
    return Path.home() / ("." + folder)


DATA_ROOT = _local_app_data()
STATE_ROOT = DATA_ROOT / "state-v3"
SETTINGS_FILE = DATA_ROOT / "agent_settings.json"
DB_FILE = STATE_ROOT / "agent-v3.sqlite3"
LOG_DIR = STATE_ROOT / "logs"
LOG_FILE = LOG_DIR / "agent.log"
AUDIT_FILE = LOG_DIR / "approval-ledger.jsonl"
BROWSER_PROFILE = STATE_ROOT / "browser-profile-v3"
DIAGNOSTICS_DIR = STATE_ROOT / "diagnostics"
LOCK_FILE = STATE_ROOT / "agent-v3.lock"


def ensure_directories() -> None:
    for path in (DATA_ROOT, STATE_ROOT, LOG_DIR, BROWSER_PROFILE, DIAGNOSTICS_DIR):
        path.mkdir(parents=True, exist_ok=True)

