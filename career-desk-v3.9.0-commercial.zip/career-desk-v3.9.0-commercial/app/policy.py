from __future__ import annotations

import html
import re
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class PolicyDecision:
    decision: str
    profession_decision: str
    fit: int
    coverage: int
    reasons: tuple[str, ...]
    evidence: tuple[str, ...]
    salary_status: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["reasons"] = list(self.reasons)
        data["evidence"] = list(self.evidence)
        return data


def normalize(value: Any) -> str:
    text = html.unescape(str(value or "")).lower().replace("ё", "е")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"[^a-zа-я0-9+#]+", " ", text).strip()


ABSOLUTE_ROLE_BLOCKS = (
    "финансов", "экономик", "бухгалтер", "налог", "казначейств", "cfo",
    "юрист", "юрисконсульт", "правовой", "адвокат", "hr ", "рекрутер",
    "директор по персоналу", "продаж", "маркетинг", "программист", "разработчик",
    "data scientist", "системный аналитик", "главный специалист архитектор",
    "архитектор по интерьер", "дизайнер интерьер", "инженер проектировщик",
    "инженер конструктор", "конструктор км", "конструктор кж", "асу тп",
    "пожаротуш", "овик", "электроснабжен", "инженер электрик",
)

DESIGN_TITLE_MARKERS = (
    "проектировщик", "инженер проектировщик", "инженер конструктор", "архитектор",
    "главный инженер проекта", "гип", "главный специалист",
)

DESIGN_FUNCTION_MARKERS = (
    "разработка проектной документации", "разработка рабочей документации",
    "выпуск проектной документации", "выпуск рабочей документации", "пир",
    "стадия п", "стадия р", "стадии п и р", "пд рд", "проектный институт",
    "авторский надзор проектировщика", "раздел км", "раздел кж", "расчеты конструкций",
)

# Job titles that mean "designer" in Russian practice, not "runs the build".
# Narrower than DESIGN_TITLE_MARKERS on purpose: these carry the meaning on
# their own, so they need no second confirmation from the description.
STRONG_DESIGN_TITLES = (
    "гип", "главный инженер проекта", "проектировщик",
    "инженер конструктор", "конструктор",
)

# Design work named in the title itself. Paired with STRONG_DESIGN_TITLES
# only - "строительство и проектирование" in a director's title is a normal
# EPC client-side role and must stay eligible.
DESIGN_WORK_IN_TITLE = (
    "проектирование", "проектирован", "проектно", "пд рд", "пир",
)

NON_CONSTRUCTION_PRODUCTION = (
    "начальник производства", "директор производства", "производственный директор",
    "технолог производства", "пищевое производство", "мебельное производство",
    "машиностроительное производство", "деревянная балка",
)

TARGET_MARKERS = (
    "руководитель строительного проекта", "руководитель строительных проектов",
    "директор проекта", "руководитель проекта",
    "главный инженер", "технический директор", "директор по строительству",
    "капитальное строительство", "инвестиционно строитель", "строительно монтаж",
    "смр", "capex", "epc", "construction manager", "project manager",
    "технический заказчик", "генеральный подряд", "генподряд", "стройконтроль",
    "ввод в эксплуатацию", "строительная площадка", "управление подрядчиками",
)

CONSTRUCTION_FUNCTION_MARKERS = (
    "организация строительства", "строительное производство", "смр", "стройплощадк",
    "генподряд", "технический заказчик", "подрядчик", "капитальное строительство",
    "строительный контроль", "исполнительная документация", "ввод в эксплуатацию",
    "сроки и бюджет", "hse", "qa qc", "epc", "capex",
)

STRONG_CONSTRUCTION_MARKERS = (
    "организация строительства", "строительное производство", "строительно монтаж",
    "смр", "стройплощадк", "генподряд", "технический заказчик",
    "капитальное строительство", "строительный контроль", "исполнительная документация",
    "ввод в эксплуатацию", "epc", "capex",
)

STRONG_CONSTRUCTION_TITLES = (
    "строитель", "капитальн", "construction", "capex", "epc",
    "директор по строительству", "руководитель строительного проекта",
)

NON_CONSTRUCTION_FUNCTION_MARKERS = (
    "разработка программного обеспечения", "внедрение информационных систем",
    "it проект", "цифровой продукт", "agile", "scrum", "банковский продукт",
    "финансовый продукт", "эксплуатация оборудования", "техническое обслуживание оборудования",
    "серийное производство", "производственная линия", "управление продуктом",
)


def _contains_any(text: str, markers: tuple[str, ...] | list[str]) -> list[str]:
    return [marker for marker in markers if normalize(marker) in text]


def _salary_status(salary: dict[str, Any] | None, minimum: int) -> tuple[str, str | None]:
    if not salary:
        return "review_missing", "зарплата не опубликована"
    currency = str(salary.get("currency") or "").upper()
    if currency and currency not in {"RUR", "RUB"}:
        return "review_currency", "зарплата указана не в рублях"
    low = salary.get("from")
    high = salary.get("to")
    gross = salary.get("gross")
    if isinstance(high, (int, float)) and high < minimum:
        return "block_below", f"верхняя граница {int(high)} ниже {minimum}"
    if gross is True:
        return "review_gross", "зарплата указана до вычета налогов"
    if isinstance(low, (int, float)) and low >= minimum and gross is False:
        return "allow_net", None
    if isinstance(low, (int, float)) and low < minimum:
        return "review_low", f"нижняя граница {int(low)} ниже ориентира {minimum}"
    if low is None:
        return "review_no_lower", "нет опубликованной нижней границы"
    return "review_ambiguous", "условия зарплаты неоднозначны"


def _construction_vacancy(vacancy: dict[str, Any], settings: dict[str, Any]) -> PolicyDecision:
    title = normalize(vacancy.get("name"))
    description = normalize(vacancy.get("description"))
    employer = normalize((vacancy.get("employer") or {}).get("name"))
    combined = f"{title} {description}"
    reasons: list[str] = []
    evidence: list[str] = []

    stop_companies = [normalize(x) for x in settings["policy"].get("stop_companies", [])]
    company_hits = [x for x in stop_companies if x and x in employer]
    if company_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("работодатель в стоп-листе",), tuple(company_hits), "not_checked")

    role_hits = _contains_any(title, ABSOLUTE_ROLE_BLOCKS)
    extra_hits = _contains_any(combined, settings["policy"].get("additional_block_terms", []))
    if role_hits or extra_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("чужая или запрещенная профессиональная функция",), tuple(role_hits + extra_hits), "not_checked")

    production_hits = _contains_any(title, NON_CONSTRUCTION_PRODUCTION)
    construction_hits = _contains_any(combined, CONSTRUCTION_FUNCTION_MARKERS)
    if production_hits and not construction_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("производство вне строительной площадки",), tuple(production_hits), "not_checked")

    design_title = _contains_any(title, DESIGN_TITLE_MARKERS)
    design_function = _contains_any(combined, DESIGN_FUNCTION_MARKERS)
    if design_title and design_function:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("проектирование или выпуск ПД/РД",), tuple(design_title + design_function), "not_checked")

    # A designer job title that also names design work in the SAME title is
    # the employer's own summary of the role; requiring a second confirmation
    # from the description let "Главный инженер проекта/ГИП (Комплексный,
    # проектирование...)" through with fit 95 on 04.09.
    strong_design_title = _contains_any(title, STRONG_DESIGN_TITLES)
    if strong_design_title and _contains_any(title, DESIGN_WORK_IN_TITLE):
        return PolicyDecision(
            "BLOCK", "BLOCK", 0, 0,
            ("проектная должность с проектированием в названии",),
            tuple(strong_design_title), "not_checked",
        )

    target_hits = _contains_any(combined, TARGET_MARKERS)
    if not target_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("нет подтвержденной строительной управленческой функции",), (), "not_checked")

    strong_title_hits = _contains_any(title, STRONG_CONSTRUCTION_TITLES)
    strong_function_hits = _contains_any(combined, STRONG_CONSTRUCTION_MARKERS)
    non_construction_hits = _contains_any(combined, NON_CONSTRUCTION_FUNCTION_MARKERS)
    if non_construction_hits and not strong_function_hits and not strong_title_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("функция проекта не относится к строительству",), tuple(non_construction_hits), "not_checked")
    if not strong_title_hits and not strong_function_hits:
        return PolicyDecision("BLOCK", "BLOCK", 0, 0, ("строительная функция не доказана",), tuple(target_hits), "not_checked")

    if design_title and not construction_hits:
        return PolicyDecision("REVIEW", "REVIEW", 45, 40, ("неоднозначная инженерная функция",), tuple(target_hits), "not_checked")

    profession = "ALLOW"
    evidence.extend(target_hits[:8])
    base_fit = min(94, 55 + len(set(target_hits)) * 5 + len(set(construction_hits)) * 3)
    coverage = min(95, 50 + len(set(construction_hits)) * 6)

    minimum = int(settings["candidate"]["public_salary_min"])
    salary_status, salary_reason = _salary_status(vacancy.get("salary"), minimum)
    if salary_status == "block_below":
        return PolicyDecision("BLOCK", profession, 0, 0, (salary_reason or "зарплата ниже минимума",), tuple(evidence), salary_status)
    if salary_reason:
        reasons.append(salary_reason)

    area = normalize((vacancy.get("area") or {}).get("name"))
    region_configs = [x for x in settings["search"]["regions"] if x.get("enabled")]
    # A search page can contain suggestions outside its selected region.
    # Only the vacancy's own location can waive relocation requirements.
    matched_region = next((x for x in region_configs if area and normalize(x.get("name")) and (normalize(x.get("name")) in area or area in normalize(x.get("name")))), None)
    region_known = matched_region is not None
    if area and not region_known:
        reasons.append("регион отсутствует в активной географии поиска")
    if matched_region:
        relocation = str(matched_region.get("relocation") or "review")
        relocation_markers = _contains_any(combined, ("релокац", "компенсация переезда", "предоставление жилья", "предоставляет жилье", "оплата проживания", "relocation package"))
        full_package_markers = _contains_any(combined, ("полный релокационный пакет", "виза и перелет", "жилье и перелет", "full relocation package"))
        if relocation == "package_or_housing" and not relocation_markers:
            reasons.append("для региона требуется подтвержденный пакет релокации или жилье")
        if relocation == "full_package" and not full_package_markers:
            reasons.append("для региона требуется явно подтвержденный полный релокационный пакет")

    fit_threshold = int(settings["search"]["fit_threshold"])
    coverage_threshold = int(settings["search"]["coverage_threshold"])
    relocation_review = any("релокац" in reason for reason in reasons)
    if salary_status != "allow_net" or (area and not region_known) or relocation_review or base_fit < fit_threshold or coverage < coverage_threshold:
        decision = "REVIEW"
    else:
        decision = "ALLOW"
    if not reasons:
        reasons.append("программные профессиональные, зарплатные и географические проверки пройдены")
    return PolicyDecision(decision, profession, base_fit, coverage, tuple(reasons), tuple(evidence), salary_status)


def live_profession_guard(vacancy: dict[str, Any], settings: dict[str, Any]) -> PolicyDecision:
    decision = evaluate_vacancy(vacancy, settings)
    if decision.profession_decision != "ALLOW":
        return decision
    return decision


def evaluate_vacancy(vacancy: dict[str, Any], settings: dict[str, Any]) -> PolicyDecision:
    """General mode has no industry bans; construction is an explicit preset."""
    if settings.get('policy', {}).get('profession_mode', 'general') == 'construction':
        return _construction_vacancy(vacancy, settings)
    policy=settings.get('policy', {})
    employer=normalize((vacancy.get('employer') or {}).get('name'))
    combined=normalize(str(vacancy.get('name') or '')+' '+str(vacancy.get('description') or ''))
    stops=[normalize(x) for x in policy.get('stop_companies', []) if normalize(x)]
    excluded=[normalize(x) for x in policy.get('additional_block_terms', []) if normalize(x)]
    hits=[x for x in stops if x in employer]+[x for x in excluded if x in combined]
    if hits:
        return PolicyDecision('BLOCK','BLOCK',0,0,('Совпадение с вашим стоп-листом или исключёнными словами.',),tuple(hits),'not_checked')
    salary_status, reason=_salary_status(vacancy.get('salary'),int(settings['candidate']['public_salary_min']))
    if salary_status=='block_below':
        return PolicyDecision('BLOCK','ALLOW',0,0,(reason,),(),salary_status)
    reasons=[reason] if reason else []
    # An unknown profession is not a prohibited one. Do not invent a numeric
    # skill match from keyword overlap; requirement evidence is evaluated by AI.
    reasons.append('Все направления: соответствие резюме проверяется по требованиям вакансии; программная оценка навыков не выполнена.')
    area=normalize((vacancy.get('area') or {}).get('name'))
    regions=[x for x in settings['search']['regions'] if x.get('enabled')]
    match=next((x for x in regions if area and normalize(x.get('name')) and
        (normalize(x['name']) in area or area in normalize(x['name']))),None)
    if area and not match:reasons.append('Регион отсутствует в активной географии поиска.')
    if match:
        relocation=match.get('relocation')
        if relocation=='package_or_housing' and not _contains_any(combined,('релокац','компенсация переезда','предоставление жилья','предоставляет жилье','оплата проживания','relocation package')):
            reasons.append('Для региона требуется подтвержденный пакет релокации или жилье.')
        if relocation=='full_package' and not _contains_any(combined,('полный релокационный пакет','виза и перелет','жилье и перелет','full relocation package')):
            reasons.append('Для региона требуется явно подтвержденный полный релокационный пакет.')
    return PolicyDecision('REVIEW','ALLOW',0,0,tuple(reasons),(),salary_status)
