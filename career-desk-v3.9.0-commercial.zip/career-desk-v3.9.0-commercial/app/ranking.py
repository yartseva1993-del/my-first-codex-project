"""One ordering for the dashboard and automatic letter preparation."""
from __future__ import annotations

import re
from typing import Any


def city_priority(area: Any) -> int:
    # The vacancy's actual location, never the region used for its search query.
    value = re.sub(r"[\s.\-–—]+", "", str(area or "").casefold())
    return 0 if value in {"санктпетербург", "спб", "saintpetersburg", "stpetersburg"} else 1


# All consumers alias vacancies as v. Sort before applying a page limit.
VACANCY_ORDER = """
    CASE WHEN v.rejected_at IS NOT NULL OR v.status IN ('sent','verify_on_hh') THEN 2
         WHEN (v.policy_decision='BLOCK' OR v.profession_decision!='ALLOW')
              AND NOT (v.manual_override_at IS NOT NULL AND v.manual_override_hash=v.content_hash)
              THEN 1 ELSE 0 END,
    hh_city_priority(v.area),
    CASE WHEN v.score_source IN ('ai','rules') THEN v.fit ELSE -1 END DESC,
    CASE WHEN v.score_source IN ('ai','rules') THEN v.coverage ELSE -1 END DESC,
    CASE WHEN v.policy_decision='ALLOW' THEN 0 ELSE 1 END,
    v.discovered_at DESC,v.id DESC
"""
