"""Local resume text extraction. No external URLs, macros or embedded scripts."""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

MAX_BYTES = 5 * 1024 * 1024
MAX_TEXT = 30000


class ResumeError(ValueError):
    pass


def clean_text(text: str) -> str:
    text = text.replace('\r\n', '\n').replace('\r', '\n').replace('\u00a0', ' ')
    text = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in text.split('\n'))
    text = re.sub(r'\n{3,}', '\n\n', text).strip()
    if len(text) < 80:
        raise ResumeError('В файле недостаточно текста. Для скана используйте распознанный PDF или вставьте текст резюме.')
    if len(text) > MAX_TEXT:
        raise ResumeError('Резюме длиннее 30 000 символов. Загрузите сокращённую копию: текст не обрезается автоматически.')
    if any(ord(c) < 32 and c not in '\n\t' for c in text):
        raise ResumeError('Вместо текста обнаружены двоичные данные. Поддерживаются PDF, DOCX, TXT и MD.')
    return text


def extract_resume(data: bytes, filename: str) -> tuple[str, str]:
    if not data or len(data) > MAX_BYTES:
        raise ResumeError('Выберите непустой файл размером до 5 МБ.')
    extension = Path(filename.replace('\\', '/')).suffix.lower()
    try:
        if extension in {'.txt', '.md'}:
            # Explicit Unicode BOMs first; legacy Windows text remains supported.
            encoding = 'utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
            try:
                text = data.decode(encoding)
            except UnicodeDecodeError:
                text = data.decode('cp1251')
        elif extension == '.docx':
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                entries = archive.infolist()
                if len(entries) > 500 or sum(i.file_size for i in entries) > 20 * 1024 * 1024:
                    raise ResumeError('DOCX содержит слишком много распакованных данных.')
                if any('vbaproject' in i.filename.lower() for i in entries):
                    raise ResumeError('Загрузите DOCX без макросов.')
                if sum(i.filename == 'word/document.xml' for i in entries) != 1:
                    raise ResumeError('Не найден основной текст DOCX.')
                xml = archive.read('word/document.xml')
                if b'<!DOCTYPE' in xml.upper() or b'<!ENTITY' in xml.upper():
                    raise ResumeError('Этот вариант DOCX не поддерживается. Сохраните резюме в PDF или TXT.')
                root = ElementTree.fromstring(xml)
                ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
                text = '\n'.join(''.join(n.text or '' for n in p.iter(ns+'t')) for p in root.iter(ns+'p'))
        elif extension == '.pdf':
            from pypdf import PdfReader
            if not data.startswith(b'%PDF-'):
                raise ResumeError('Файл не является PDF.')
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted:
                raise ResumeError('PDF защищён паролем. Загрузите незашифрованную копию.')
            if len(reader.pages) > 30:
                raise ResumeError('Поддерживается PDF до 30 страниц.')
            pages = []
            for page in reader.pages:
                contents = page.get_contents()
                if contents is not None and len(contents.get_data()) > 5 * 1024 * 1024:
                    raise ResumeError('Страница PDF слишком сложная. Сохраните текст в TXT или DOCX.')
                pages.append(page.extract_text() or '')
                if sum(map(len, pages)) > MAX_TEXT:
                    raise ResumeError('Резюме длиннее 30 000 символов.')
            text = '\n\n'.join(pages)
        else:
            raise ResumeError('Поддерживаются PDF, DOCX, TXT и MD. Для старого DOC выберите «Сохранить как DOCX».')
        return clean_text(text), extension[1:].upper()
    except ResumeError:
        raise
    except ImportError as exc:
        raise ResumeError('Для чтения PDF обновите зависимости через SETUP_WINDOWS.cmd.') from exc
    except Exception as exc:
        # Parser exceptions can contain user text or archive paths.
        raise ResumeError('Не удалось прочитать файл. Сохраните его заново или вставьте текст резюме.') from exc
