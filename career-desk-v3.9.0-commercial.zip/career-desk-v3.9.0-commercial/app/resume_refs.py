"""Recognize resume references used by current and legacy hh.ru layouts."""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import parse_qsl, urljoin, urlsplit

from .hh_web_parser import _Document, is_hh_web_url


RESUME_TOKEN = re.compile(r"[0-9a-fA-F-]{8,100}")
_JSON_ASSIGNMENT = re.compile(
    r"(?:window\.)?(?:__INITIAL_STATE__|initialState|__HH_STATE__)\s*=\s*(\{.*\})\s*;?",
    flags=re.DOTALL,
)
_JSON_ID_KEYS = {"hash", "resumehash", "resume_hash", "resumeid", "resume_id"}


def resume_ref(value: Any, base_url: str = "https://hh.ru") -> str:
    """Return a public resume hash without accepting lookalike domains.

    HH currently exposes an owned resume either as ``/resume/<hash>`` or in
    the ``resume=<hash>`` parameter of the recommendations link on the same
    resume card. Form controls can still use ``resume_<hash>`` values.
    """
    raw = str(value or "").strip()
    if not raw:
        return ""
    direct = re.fullmatch(r"(?:resume[_:])?([0-9a-fA-F-]{8,100})", raw)
    if direct:
        return direct.group(1)
    if raw.isdecimal():
        # Some forms use a short internal numeric id. It is never sufficient
        # alone, but callers may bind it to an exact public hash in its label.
        return raw
    try:
        absolute = urljoin(base_url, raw)
        parsed = urlsplit(absolute)
    except ValueError:
        return ""
    if not is_hh_web_url(absolute):
        return ""
    path_match = re.fullmatch(r"/resume/([0-9a-fA-F-]{8,100})/?", parsed.path)
    if path_match:
        return path_match.group(1)
    path = parsed.path.rstrip("/")
    if path not in {"/search/vacancy", "/applicant/resumes"}:
        return ""
    query = parse_qsl(parsed.query, keep_blank_values=False)
    if path == "/search/vacancy" and not any(
        key.casefold() == "from" and item.casefold() == "resumelist"
        for key, item in query
    ):
        # A generic search URL containing a resume-shaped value is not proof
        # that the resume belongs to the signed-in user.  HH's own link from
        # an owned resume card carries this provenance marker.
        return ""
    values = [item for key, item in query if key.casefold() == "resume"]
    return values[0] if len(values) == 1 and RESUME_TOKEN.fullmatch(values[0]) else ""


def document_resume_refs(source: str, page_url: str) -> set[str]:
    """Collect explicit resume hashes from an authenticated owner page."""
    root = _Document(str(source or "")[:12_000_000]).root
    references: set[str] = set()
    for node in root.walk():
        for key in ("href", "data-resume-id", "data-resume-hash", "data-hh-resume-hash"):
            reference = resume_ref(node.attrs.get(key, ""), page_url)
            if reference and not reference.isdecimal():
                references.add(reference)
        context = " ".join((node.attrs.get("name", ""), node.attrs.get("data-qa", ""))).casefold()
        if "resume" in context:
            reference = resume_ref(node.attrs.get("value", ""), page_url)
            if reference and not reference.isdecimal():
                references.add(reference)
        if node.tag != "script":
            continue
        raw = node.text(raw=True).strip()
        if not raw or len(raw) > 4_000_000:
            continue
        if node.attrs.get("type") not in {"application/json", "application/ld+json"}:
            match = _JSON_ASSIGNMENT.fullmatch(raw)
            if not match:
                continue
            raw = match.group(1)
        try:
            payload = json.loads(raw)
        except (ValueError, RecursionError):
            continue
        pending = [payload]
        for _ in range(20_000):
            if not pending:
                break
            item = pending.pop()
            if isinstance(item, list):
                pending.extend(item)
            elif isinstance(item, dict):
                for key, value in item.items():
                    if str(key).casefold() in _JSON_ID_KEYS:
                        reference = resume_ref(value, page_url)
                        if reference and not reference.isdecimal():
                            references.add(reference)
                    elif isinstance(value, (list, dict)):
                        pending.append(value)
    return references
