"""Settings-only resume endpoints. No HH browser or submission imports."""
import asyncio
import copy

from fastapi import Body, Header, HTTPException, Request

from .resume_import import MAX_BYTES, ResumeError, extract_resume
from .resume_workspace import PROMPT_KEYS, ResumeWorkspace
from .settings import SettingsError, save_settings


def register_resume_routes(app, settings, db, require_csrf, settings_lock, on_settings_changed):
    workspace = ResumeWorkspace(db.path.parent / 'resume-workspace.json')

    @app.get('/api/resume')
    def resume(x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        return workspace.status(True)

    @app.post('/api/resume/upload')
    async def upload(request: Request, filename: str = 'resume.txt', x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        data = bytearray()
        async for block in request.stream():
            data.extend(block)
            if len(data) > MAX_BYTES:
                raise HTTPException(413, 'Максимальный размер резюме — 5 МБ.')
        try:
            text, format = await asyncio.to_thread(extract_resume, bytes(data), filename)
            result = workspace.upload(text, format)
            db.audit('resume_uploaded', details={'characters':len(text), 'format':format})
            return result
        except ResumeError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post('/api/resume/generate')
    def generate(x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try:
            with settings_lock:
                return workspace.start(settings)
        except ResumeError as exc:
            raise HTTPException(409, str(exc)) from exc

    @app.post('/api/resume/clear')
    def clear(x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        workspace.clear()
        return {'cleared':True}

    @app.post('/api/resume/apply')
    def apply(payload: dict = Body(...), x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try:
            with settings_lock, workspace.lock:
                workspace.proposal(payload.get('revision'), settings)
                selected = [key for key in ('use_profile','use_queries','use_prompts') if payload.get(key) is True]
                if not selected:
                    raise ResumeError('Выберите, что применить: профиль, запросы или промпты.')
                proposed = copy.deepcopy(settings)
                if 'use_profile' in selected:
                    candidate = payload.get('candidate')
                    if not isinstance(candidate, dict):
                        raise ResumeError('Проверьте поля профиля.')
                    for key in ('full_name','headline','profile','achievements','years_experience'):
                        if key not in candidate:
                            raise ResumeError('Не все поля профиля переданы. Обновите результат.')
                        proposed['candidate'][key] = candidate[key]
                if 'use_queries' in selected:
                    queries = payload.get('queries')
                    if not isinstance(queries, list) or not 1 <= len(queries) <= 15 or any(not isinstance(q,str) or not 1 <= len(q.strip()) <= 200 for q in queries):
                        raise ResumeError('Укажите от 1 до 15 запросов, каждый до 200 символов.')
                    proposed['search']['queries'] = queries
                if 'use_prompts' in selected:
                    prompts = payload.get('prompts')
                    if not isinstance(prompts,dict) or any(not isinstance(prompts.get(k),str) or not 20 <= len(prompts[k]) <= 6000 for k in PROMPT_KEYS):
                        raise ResumeError('Проверьте четыре промпта: от 20 до 6000 символов каждый.')
                    for key in PROMPT_KEYS:
                        proposed['ai'][key] = prompts[key]
                validated = save_settings(proposed)
                settings.update(validated)
                workspace.data['applied'] = True
                # Committing settings is authoritative even if the optional resume
                # preview cannot be saved (e.g. disk error). Never re-send anything.
                workspace._save()
            on_settings_changed()
            db.audit('resume_settings_applied', details={'sections':selected})
            return {'applied':True, 'settings':settings}
        except (ResumeError,SettingsError) as exc:
            raise HTTPException(409 if isinstance(exc,ResumeError) else 400, str(exc)) from exc

    return workspace
