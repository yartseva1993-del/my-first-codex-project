from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Any, Callable

from .ai import AIError, OllamaClient
from .db import Database
from .hh_api import HHApiClient, HHApiError, HybridHHClient
from .policy import evaluate_vacancy
from .ranking import city_priority


LOGGER = logging.getLogger(__name__)


@dataclass
class ScoutResult:
    searches: int = 0
    found: int = 0
    unique: int = 0
    saved: int = 0
    blocked: int = 0
    reviewed: int = 0
    allowed: int = 0
    rejected: int = 0
    ai_errors: int = 0
    ai_skipped: int = 0
    errors: int = 0
    stopped: bool = False
    cancelled: bool = False
    error: str = ""
    source: str = ""
    recommendation_searches: int = 0
    recommendation_found: int = 0

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


class VacancyScout:
    """Search and analysis only. This module intentionally has no submission imports."""

    def __init__(self, db: Database, settings: dict[str, Any], hh: HHApiClient | HybridHHClient | None = None, *, on_progress: Callable[[str, dict[str, Any]], None] | None = None, stop_event: threading.Event | None = None):
        self.db = db
        self.settings = settings
        self.hh = hh or HybridHHClient()
        self.on_progress = on_progress or (lambda phase, progress: None)
        self.stop_event = stop_event or threading.Event()

    def _ai_client(self) -> OllamaClient | None:
        config = self.settings["ai"]
        if not config.get("enabled"):
            return None
        return OllamaClient(config["base_url"], config["model"], int(config["timeout_seconds"]))

    def run_once(self) -> ScoutResult:
        try:
            return self._run_once()
        finally:
            close = getattr(self.hh, "close", None)
            if callable(close):
                close()

    def _finish(self, result: ScoutResult) -> ScoutResult:
        result.source = str(getattr(self.hh, "last_source", "")) or result.source
        if self.stop_event.is_set():
            result.cancelled = result.stopped = True
        self.db.audit("scout_cycle_finished", details=result.to_dict())
        return result

    def _failed(self, result: ScoutResult, exc: HHApiError) -> None:
        result.errors += 1
        result.error = str(exc)
        result.stopped = exc.stop_search

    def _run_once(self) -> ScoutResult:
        result = ScoutResult()
        candidates: dict[str, dict[str, Any]] = {}
        search = self.settings["search"]
        regions = sorted((x for x in search["regions"] if x.get("enabled")), key=lambda x: int(x.get("priority", 0)), reverse=True)
        self.on_progress("searching", {"searches": 0})
        for region in regions:
            if self.stop_event.is_set():
                break
            area_id = str(region.get("area_id", "")).strip()
            if not area_id:
                try:
                    area_id = self.hh.resolve_area_id(str(region.get("name", "")))
                except HHApiError as exc:
                    LOGGER.error("Region resolution failed for %s: %s", region.get("name"), exc)
                    self._failed(result, exc)
                    if exc.stop_search:
                        return self._finish(result)
                    continue
            for query in search["queries"]:
                if self.stop_event.is_set():
                    break
                if not str(query).strip():
                    continue
                result.searches += 1
                try:
                    page = self.hh.search(str(query), area_id, int(search["days"]), int(search["per_query"]))
                except HHApiError as exc:
                    LOGGER.error("HH search failed for %s/%s: %s", region.get("name"), query, exc)
                    self._failed(result, exc)
                    if exc.stop_search:
                        return self._finish(result)
                    continue
                items = page.get("items") or []
                result.found += len(items)
                self.on_progress("searching", {"searches": result.searches, "found": result.found})
                for item in items:
                    if isinstance(item, dict) and item.get("id"):
                        candidate = dict(item)
                        candidate["_search_region"] = str(region.get("name", ""))
                        candidates.setdefault(str(item["id"]), candidate)
        if (
            not self.stop_event.is_set()
            and bool(search.get("resume_recommendations", True))
            and str(self.settings.get("submit", {}).get("resume_id") or "")
            and callable(getattr(self.hh, "resume_recommendations", None))
        ):
            resume_id = str(self.settings["submit"]["resume_id"])
            pages = max(1, min(10, int(search.get("resume_recommendation_pages", 3))))
            for page_number in range(pages):
                if self.stop_event.is_set():
                    break
                result.searches += 1
                result.recommendation_searches += 1
                try:
                    page = self.hh.resume_recommendations(resume_id, min(20, int(search["per_query"])), page_number)
                except HHApiError as exc:
                    LOGGER.error("HH selected-resume recommendations failed on page %s: %s", page_number + 1, exc)
                    self._failed(result, exc)
                    if exc.stop_search:
                        return self._finish(result)
                    break
                items = page.get("items") or []
                result.found += len(items)
                result.recommendation_found += len(items)
                self.on_progress("searching", {
                    "searches": result.searches,
                    "found": result.found,
                    "recommendation_found": result.recommendation_found,
                })
                for item in items:
                    if isinstance(item, dict) and item.get("id"):
                        candidate = dict(item)
                        candidate["_search_region"] = ""
                        candidate["_recommendation_source"] = True
                        candidates.setdefault(str(item["id"]), candidate)
                total_pages = page.get("pages")
                if isinstance(total_pages, int) and page_number + 1 >= total_pages:
                    break
        result.unique = len(candidates)
        records: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for vacancy_id in sorted(candidates, key=lambda key: city_priority((candidates[key].get("area") or {}).get("name"))):
            if self.stop_event.is_set():
                break
            if self.db.is_rejected(vacancy_id):
                result.rejected += 1
                continue
            try:
                vacancy = self.hh.vacancy(vacancy_id)
                vacancy["_search_region"] = candidates[vacancy_id].get("_search_region", "")
                policy = evaluate_vacancy(vacancy, self.settings).to_dict()
                records.append((vacancy, policy))
                self.on_progress("fetching", {"fetched": len(records), "total": result.unique})
            except (HHApiError, KeyError, ValueError, OSError) as exc:
                LOGGER.error("Vacancy processing failed for %s: %s", vacancy_id, exc)
                result.errors += 1
                result.error = str(exc)
                if isinstance(exc, HHApiError) and exc.stop_search:
                    result.stopped = True
                    break
        # Release Chromium before any slow model call. The profile coordinator
        # also prevents a new read from racing with a manual submission.
        result.source = str(getattr(self.hh, "last_source", ""))
        close = getattr(self.hh, "close", None)
        if callable(close):
            close()
        records.sort(key=lambda row: (city_priority((row[0].get("area") or {}).get("name")), -row[1]["fit"], -row[1]["coverage"]))
        self.on_progress("analyzing", {"done": 0, "total": len(records)})
        ai_client = self._ai_client()
        deep_used = 0
        consecutive_failures = 0
        for vacancy, policy in records:
            vacancy_id = str(vacancy["id"])
            if self.db.is_rejected(vacancy_id):
                result.rejected += 1
                continue
            try:
                ai_result: dict[str, Any] = {"decision": "NOT_RUN"}
                if not self.stop_event.is_set() and policy["decision"] != "BLOCK" and ai_client and deep_used < int(search["max_deep_analysis"]) and consecutive_failures < 2:
                    deep_used += 1
                    try:
                        ai_result = ai_client.analyze(vacancy, self.settings)
                        consecutive_failures = 0
                        if ai_result["decision"] == "BLOCK":
                            policy["decision"] = "BLOCK"
                            policy["reasons"].append("ИИ: " + ai_result["summary"])
                        elif ai_result["decision"] == "REVIEW" or policy["decision"] != "ALLOW":
                            policy["decision"] = "REVIEW"
                        elif ai_result["fit"] < int(search["fit_threshold"]) or ai_result["coverage"] < int(search["coverage_threshold"]):
                            policy["decision"] = "REVIEW"
                    except AIError as exc:
                        LOGGER.warning("AI analysis failed for vacancy %s: %s", vacancy_id, exc)
                        result.ai_errors += 1
                        consecutive_failures += 1
                        ai_result = {
                            "decision": "NOT_RUN",
                            "summary": "Ollama не завершила структурированную оценку. Показана предварительная оценка по программным правилам; создание письма доступно.",
                        }
                        policy["reasons"].append("Оценка ИИ недоступна; показана предварительная оценка по правилам.")
                        policy["decision"] = "REVIEW"
                elif consecutive_failures >= 2 and policy['decision'] != 'BLOCK':
                    result.ai_skipped += 1
                    ai_result = {'decision': 'NOT_RUN', 'summary': 'Оценка ИИ приостановлена до следующего поиска после двух сбоев. Показана предварительная оценка по правилам; подготовка письма доступна.'}
                    policy['decision'] = 'REVIEW'
                    policy['reasons'].append('Оценка по правилам; ИИ временно недоступен.')
                self.db.upsert_vacancy(vacancy, policy, ai_result)
                result.saved += 1
                if policy["decision"] == "BLOCK":
                    result.blocked += 1
                elif policy["decision"] == "ALLOW":
                    result.allowed += 1
                else:
                    result.reviewed += 1
                self.on_progress("analyzing", {"done": result.saved, "total": len(records)})
            except (HHApiError, KeyError, ValueError, OSError) as exc:
                LOGGER.error("Vacancy processing failed for %s: %s", vacancy_id, exc)
                result.errors += 1
                result.error = str(exc)
                if isinstance(exc, HHApiError) and exc.stop_search:
                    result.stopped = True
                    break
        return self._finish(result)
