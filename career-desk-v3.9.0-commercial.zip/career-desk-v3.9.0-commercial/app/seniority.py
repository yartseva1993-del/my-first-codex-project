"""Deterministic seniority and market-segment checks.

Why this module exists
----------------------
The 04.09 log shows 76 of 88 AI-scored vacancies received fit=95. A 4B model
asked for a free-form 0-100 number cannot discriminate, so it anchors on
"construction-ish -> 95". Everything then cleared the 75 threshold, the queue
filled with assistant and foreman roles, and ranking became meaningless.

Level and segment are decidable from the title with rules, without a model.
Rules do not drift, cannot be flattened by a small model, and are testable.
The LLM keeps its job (reading the requirements) but no longer decides
whether "Помощник руководителя проектов" belongs in a director-level queue.
"""
from __future__ import annotations

from dataclasses import dataclass

from .policy import normalize

# Roles reporting INTO the candidate's level. Not a wrong profession -
# a wrong rung. Sending a director-level CV to these wastes the slot.
BELOW_LEVEL_TITLES = (
    "помощник", "ассистент", "стажер", "младший",
    "прораб", "производитель работ", "мастер смр", "мастер участка",
    "бригадир", "десятник",
)

# Site-level supervision. Target only when the title also carries a
# project/director scope ("Руководитель проекта / Начальник участка" is
# a real posting shape and stays eligible).
SITE_LEVEL_TITLES = (
    "начальник участка", "начальник строительного участка",
    "старший прораб", "начальник смены",
)

# Titles that carry the candidate's actual scope. Stored as stem tuples:
# every stem must appear somewhere in the title, in any order and any case
# ending. Russian postings inflect freely ("руководителя проектов") and a
# fixed phrase list silently misses them - that is how "Заместитель
# руководителя проектов" was landing in the unknown bucket.
PROJECT_SCOPE_STEMS: tuple[tuple[str, ...], ...] = (
    ("руководител", "проект"),
    ("директор", "проект"),
    ("директор", "строительств"),
    ("технически", "директор"),
    ("генеральн", "директор"),
    ("исполнительн", "директор"),
    ("руководител", "направлени"),
    ("руководител", "департамент"),
    ("руководител", "строительств"),
    ("начальник", "управлени"),
    ("начальник", "отдел", "строительств"),
    ("технически", "заказчик"),
    ("главн", "инженер"),
    ("project", "manager"),
    ("construction", "manager"),
    ("capex",),
    ("epc",),
    ("ерс",),  # Cyrillic spelling of EPC, common in Russian postings
)

# Interior fit-out and finishing works. A different market from industrial
# CAPEX: smaller budgets, different contractors, different buyers. Not
# blocked (the skills transfer) but never auto-ranked next to a plant build.
FITOUT_SEGMENT_MARKERS = (
    "fit out", "fit-out", "fitout", "отделочн", "отделка помещений",
    "чистовая отделка", "премиальная отделка", "интерьерн",
    "ремонтно отделочн", "дизайнерский ремонт",
)

# The candidate's proven segment: industrial, energy, infrastructure, CAPEX.
INDUSTRIAL_SEGMENT_MARKERS = (
    "промышленн", "завод", "производственный комплекс", "нефтепереработк",
    "нефтегаз", "энергообъект", "электростанц", "капитальное строительство",
    "инфраструктур", "логистическ", "склад", "цод", "дата центр",
    "агропромышленн", "гок", "обогатительн", "терминал", "порт",
    "целлюлозн", "цбк", "epc", "capex",
)


@dataclass(frozen=True)
class SeniorityVerdict:
    """Outcome of the deterministic level/segment check.

    fit_cap limits what the downstream AI score is allowed to claim.
    A model that returns 95 for an assistant role gets capped, so a
    degenerate scorer can no longer flood the approval queue.
    """

    level: str          # "below" | "site" | "target" | "unknown"
    segment: str        # "fitout" | "industrial" | "unspecified"
    fit_cap: int        # upper bound on fit for this vacancy
    reasons: tuple[str, ...]

    @property
    def is_below_level(self) -> bool:
        return self.level == "below"


def _hits(text: str, markers: tuple[str, ...]) -> list[str]:
    return [marker for marker in markers if normalize(marker) in text]


def _stem_hits(text: str, groups: tuple[tuple[str, ...], ...]) -> list[str]:
    """Match stem groups regardless of Russian case endings or word order."""
    return [" ".join(group) for group in groups if all(stem in text for stem in group)]


def assess(title: str, description: str = "") -> SeniorityVerdict:
    """Classify a vacancy's rung and market segment from its text."""
    normalized_title = normalize(title)
    combined = f"{normalized_title} {normalize(description)}"
    reasons: list[str] = []

    project_scope = _stem_hits(normalized_title, PROJECT_SCOPE_STEMS)

    below = _hits(normalized_title, BELOW_LEVEL_TITLES)
    if below:
        # "Заместитель руководителя проекта" is a peer-level role, not a
        # junior one; only the explicit junior markers above demote.
        reasons.append("должность ниже уровня кандидата: " + ", ".join(below))
        return SeniorityVerdict("below", _segment(combined), 40, tuple(reasons))

    site = _hits(normalized_title, SITE_LEVEL_TITLES)
    if site and not project_scope:
        reasons.append("участковый уровень без проектного масштаба: " + ", ".join(site))
        return SeniorityVerdict("site", _segment(combined), 60, tuple(reasons))

    segment = _segment(combined)
    if project_scope:
        if segment == "fitout":
            reasons.append("отделочный сегмент вместо промышленного CAPEX")
            return SeniorityVerdict("target", segment, 75, tuple(reasons))
        return SeniorityVerdict("target", segment, 100, tuple(reasons))

    reasons.append("масштаб должности не подтвержден названием")
    return SeniorityVerdict("unknown", segment, 80, tuple(reasons))


def _segment(combined: str) -> str:
    fitout = _hits(combined, FITOUT_SEGMENT_MARKERS)
    industrial = _hits(combined, INDUSTRIAL_SEGMENT_MARKERS)
    # Industrial evidence wins: a plant build that mentions finishing works
    # in passing is still a plant build.
    if industrial:
        return "industrial"
    if fitout:
        return "fitout"
    return "unspecified"


def apply_cap(fit: int, coverage: int, verdict: SeniorityVerdict) -> tuple[int, int]:
    """Clamp a model-produced score to what the rules allow."""
    capped_fit = min(int(fit), verdict.fit_cap)
    # Coverage measures requirement overlap and is meaningful even at the
    # wrong rung, so it is only clamped for clearly below-level roles.
    capped_coverage = min(int(coverage), 60) if verdict.is_below_level else int(coverage)
    return capped_fit, capped_coverage
