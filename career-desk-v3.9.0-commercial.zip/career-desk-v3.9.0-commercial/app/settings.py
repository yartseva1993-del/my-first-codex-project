from __future__ import annotations

import copy
import json
import os
import tempfile
from pathlib import Path
from typing import Any

from .paths import DATA_ROOT, SETTINGS_FILE, ensure_directories


DEFAULT_SETTINGS: dict[str, Any] = {'schema_version': 3, 'candidate': {'full_name': '', 'headline': '', 'years_experience': 0, 'profile': '', 'public_salary_min': 0, 'internal_salary_target': 0, 'currency': 'RUR', 'salary_net_required_for_auto_allow': True, 'achievements': []}, 'search': {'queries': ['Специалист'], 'regions': [{'name': 'Россия', 'area_id': '113', 'enabled': False, 'priority': 50, 'relocation': 'review'}], 'days': 1, 'per_query': 20, 'max_deep_analysis': 30, 'schedule_local': '08:30', 'fit_threshold': 75, 'coverage_threshold': 70, 'resume_recommendations': True, 'resume_recommendation_pages': 3}, 'policy': {'profession_mode': 'general', 'stop_companies': [], 'additional_block_terms': []}, 'ai': {'enabled': True, 'auto_draft_letters': False, 'provider': 'ollama', 'base_url': 'http://127.0.0.1:11434', 'model': 'qwen3:4b', 'timeout_seconds': 180, 'profession_prompt': 'Оцени функцию и уровень вакансии любой профессии по резюме кандидата и целевым должностям. Не ограничивай отрасль строительством. Сравни навыки, обязанности, опыт и обязательную квалификацию. Не выдумывай соответствие; непроверенные требования отмечай как пробелы. При неоднозначности верни REVIEW. Учитывай явно заданные пользователем исключения.', 'fit_prompt': 'Сопоставь каждый must-have вакансии только с подтвержденным профилем кандидата. Не придумывай опыт. Верни Fit, Coverage, совпадения и критичные пробелы.', 'letter_prompt': 'Напиши формально-деловое сопроводительное: приветствие, мотивация, 2-3 подтвержденных достижения, связь с задачами вакансии, приглашение к разговору. Не раскрывай конфиденциальные объекты и не придумывай факты.', 'critic_prompt': 'Проверь письмо на выдуманные факты, чужую профессию, конфиденциальность, неверную зарплату, разговорный тон и соответствие вакансии.'}, 'submit': {'mode': 'manual_only', 'resume_id': '', 'require_cover_letter': True, 'final_confirmation_required': True, 'permit_ttl_seconds': 90, 'daily_limit': 10}, 'ui': {'host': '127.0.0.1', 'port': 8001}}


class SettingsError(ValueError):
    pass


def _merge(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if key not in result:
            continue
        if isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _validate(settings: dict[str, Any]) -> dict[str, Any]:
    mode=settings['policy'].get('profession_mode','general')
    if mode not in {'general','construction'}:
        raise SettingsError('Неизвестный режим профессиональных фильтров')
    settings['policy']['profession_mode']=mode
    old_prompt=settings['ai'].get('profession_prompt','')
    if mode=='general' and ('Разрешай только управление строительством' in old_prompt or
                           'Проверяй управление строительством, СМР, CAPEX/EPC' in old_prompt):
        settings['ai']['profession_prompt']=DEFAULT_SETTINGS['ai']['profession_prompt']
    settings["schema_version"] = 3
    settings["submit"]["mode"] = "manual_only"
    settings["submit"]["final_confirmation_required"] = True
    settings["submit"]["require_cover_letter"] = True

    candidate = settings["candidate"]
    for key, limit in (("full_name",120), ("headline",240), ("profile",6000)):
        if not isinstance(candidate.get(key), str) or len(candidate[key]) > limit:
            raise SettingsError(f"candidate.{key}: требуется текст до {limit} символов")
        candidate[key] = candidate[key].strip()
    if any(ord(c) < 32 for c in candidate['full_name']):
        raise SettingsError("Имя должно занимать одну строку")
    facts = candidate.get('achievements')
    if not isinstance(facts,list) or len(facts) > 36 or any(not isinstance(f,str) or len(f) > 900 for f in facts):
        raise SettingsError("Достижения: не более 36 текстовых фактов до 900 символов")
    if type(candidate.get('years_experience')) is not int or not 0 <= candidate['years_experience'] <= 80:
        raise SettingsError("Стаж: целое число от 0 до 80; 0 означает не указан")
    for field in ("public_salary_min", "internal_salary_target"):
        value = candidate.get(field)
        if not isinstance(value, int) or not 0 <= value <= 10_000_000:
            raise SettingsError(f"candidate.{field} must be an integer between 0 and 10000000")
    if candidate["internal_salary_target"] < candidate["public_salary_min"]:
        raise SettingsError("internal salary target cannot be lower than public minimum")

    search = settings["search"]
    if not isinstance(search.get("queries"), list) or not any(str(x).strip() for x in search["queries"]):
        raise SettingsError("at least one search query is required")
    regions = search.get("regions")
    if not isinstance(regions, list) or not regions:
        raise SettingsError("at least one search region is required")
    clean_regions: list[dict[str, Any]] = []
    for item in regions[:30]:
        if not isinstance(item, dict) or not str(item.get("name", "")).strip():
            continue
        clean_regions.append({
            "name": str(item["name"]).strip()[:100],
            "area_id": str(item.get("area_id", "")).strip()[:20],
            "enabled": bool(item.get("enabled", True)),
            "priority": max(0, min(100, int(item.get("priority", 50)))),
            "relocation": str(item.get("relocation", "review"))[:40],
        })
    if not clean_regions:
        raise SettingsError("no valid regions remain")
    search["regions"] = clean_regions
    search["days"] = max(1, min(30, int(search.get("days", 1))))
    search["per_query"] = max(1, min(100, int(search.get("per_query", 20))))
    search["max_deep_analysis"] = max(1, min(100, int(search.get("max_deep_analysis", 30))))
    search["fit_threshold"] = max(0, min(100, int(search.get("fit_threshold", 75))))
    search["coverage_threshold"] = max(0, min(100, int(search.get("coverage_threshold", 70))))
    if type(search.get("resume_recommendations")) is not bool:
        raise SettingsError("search.resume_recommendations must be true or false")
    search["resume_recommendation_pages"] = max(1, min(10, int(search.get("resume_recommendation_pages", 3))))

    policy = settings["policy"]
    policy["stop_companies"] = [str(x).strip()[:200] for x in policy.get("stop_companies", []) if str(x).strip()][:500]
    policy["additional_block_terms"] = [str(x).strip()[:100] for x in policy.get("additional_block_terms", []) if str(x).strip()][:200]

    ai = settings["ai"]
    for key in ("enabled", "auto_draft_letters"):
        if type(ai.get(key)) is not bool:
            raise SettingsError(f"ai.{key} must be true or false")
    if ai.get("provider") != "ollama":
        raise SettingsError("only the local Ollama provider is supported in this release")
    if not str(ai.get("base_url", "")).startswith(("http://127.0.0.1:", "http://localhost:")):
        raise SettingsError("Ollama base_url must be local")
    ai["timeout_seconds"] = max(30, min(600, int(ai.get("timeout_seconds", 180))))

    submit = settings["submit"]
    submit["permit_ttl_seconds"] = max(30, min(180, int(submit.get("permit_ttl_seconds", 90))))
    submit["daily_limit"] = max(1, min(50, int(submit.get("daily_limit", 10))))
    submit["resume_id"] = str(submit.get("resume_id", "")).strip()[:100]

    ui = settings["ui"]
    ui["host"] = "127.0.0.1"
    ui["port"] = max(1024, min(65535, int(ui.get("port", 8000))))
    return settings


def load_settings(path: Path = SETTINGS_FILE) -> dict[str, Any]:
    path = Path(path)
    if path == SETTINGS_FILE:
        ensure_directories()
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        settings = _validate(copy.deepcopy(DEFAULT_SETTINGS))
        save_settings(settings, path)
        return settings
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SettingsError(f"cannot read settings: {exc}") from exc
    if not isinstance(raw, dict):
        raise SettingsError("settings root must be an object")
    return _validate(_merge(DEFAULT_SETTINGS, raw))


def save_settings(settings: dict[str, Any], path: Path = SETTINGS_FILE) -> dict[str, Any]:
    path = Path(path)
    if path == SETTINGS_FILE:
        ensure_directories()
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
    validated = _validate(_merge(DEFAULT_SETTINGS, settings))
    payload = json.dumps(validated, ensure_ascii=False, indent=2) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    return validated


def sanitized_settings(settings: dict[str, Any]) -> dict[str, Any]:
    clean = copy.deepcopy(settings)
    clean.get("submit", {}).pop("resume_id", None)
    if "candidate" in clean:
        # Uploaded profile facts and optional signature are private.
        clean["candidate"].pop("resume_name", None)
        clean["candidate"].pop("full_name", None)
        clean["candidate"]["headline"] = "[redacted from diagnostics]"
        clean["candidate"]["profile"] = "[redacted from diagnostics]"
        clean["candidate"]["achievements"] = ["[redacted from diagnostics]"]
    for key in ("profession_prompt", "fit_prompt", "letter_prompt", "critic_prompt"):
        clean.get("ai", {})[key] = "[redacted from diagnostics]"
    return clean
