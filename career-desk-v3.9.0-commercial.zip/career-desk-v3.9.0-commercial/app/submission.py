from __future__ import annotations

import queue
import secrets
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

from .db import Database, StateError


@dataclass(frozen=True)
class SubmissionPermit:
    token: str
    attempt_id: str
    vacancy_id: str
    letter_hash: str
    vacancy_approval_version: int
    letter_approval_version: int
    expires_at: float
    resume_id: str = ""


class PermitVault:
    """In-memory one-shot capability store. Tokens are never persisted or sent to the UI."""

    def __init__(self):
        self._permits: dict[str, SubmissionPermit] = {}
        self._lock = threading.Lock()

    def issue(
        self,
        attempt_id: str,
        vacancy_id: str,
        digest: str,
        vacancy_approval_version: int,
        letter_approval_version: int,
        ttl_seconds: int,
        resume_id: str = "",
    ) -> SubmissionPermit:
        permit = SubmissionPermit(
            secrets.token_urlsafe(32), attempt_id, vacancy_id, digest,
            int(vacancy_approval_version), int(letter_approval_version), time.monotonic() + ttl_seconds, resume_id,
        )
        with self._lock:
            self._permits[permit.token] = permit
        return permit

    def consume(self, permit: SubmissionPermit) -> SubmissionPermit:
        with self._lock:
            stored = self._permits.pop(permit.token, None)
        if stored is None or stored != permit:
            raise StateError("submission permit is missing, reused, or forged")
        if time.monotonic() > stored.expires_at:
            raise StateError("submission permit expired")
        return stored

    def revoke_all(self) -> None:
        with self._lock:
            self._permits.clear()


class SubmissionController:
    def __init__(self, db: Database, settings: dict[str, Any], worker: Callable[[SubmissionPermit], None] | None = None):
        self.db = db
        self.settings = settings
        self.vault = PermitVault()
        self.queue: queue.Queue[SubmissionPermit] = queue.Queue()
        self.worker = worker

    def final_click(self, vacancy_id: str, *, expected_letter_hash: str | None = None, expected_content_hash: str | None = None) -> str:
        from .licensing import require_license
        require_license()
        if self.settings["submit"].get("mode") != "manual_only":
            raise StateError("unsafe submission mode refused")
        attempt_id = secrets.token_hex(16)
        snapshot = self.db.prepare_submission(
            vacancy_id, attempt_id, int(self.settings["submit"]["daily_limit"]),
            expected_letter_hash=expected_letter_hash, expected_content_hash=expected_content_hash,
        )
        permit = self.vault.issue(
            attempt_id,
            vacancy_id,
            str(snapshot["approved_hash"]),
            int(snapshot["vacancy_approval_version"]),
            int(snapshot["letter_approval_version"]),
            int(self.settings["submit"]["permit_ttl_seconds"]),
            resume_id=str(self.settings["submit"].get("resume_id") or ""),
        )
        self.db.audit("send_permit_issued_in_memory", vacancy_id, attempt_id, {"ttl": self.settings["submit"]["permit_ttl_seconds"]})
        if self.worker:
            thread = threading.Thread(target=self.worker, args=(permit,), name=f"submit-{vacancy_id}", daemon=True)
            thread.start()
        else:
            self.queue.put(permit)
        return attempt_id

    def consume_for_submitter(self, permit: SubmissionPermit) -> SubmissionPermit:
        consumed = self.vault.consume(permit)
        self.db.audit("send_permit_consumed", permit.vacancy_id, permit.attempt_id)
        return consumed
