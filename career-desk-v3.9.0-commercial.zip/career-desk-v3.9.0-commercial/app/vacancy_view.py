"""Parameterized filtering of saved vacancies. Never changes search/approval policy."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .ranking import VACANCY_ORDER

SALARY = "json_extract(v.raw_json, '$.salary')"
LOW = "json_extract(v.raw_json, '$.salary.from')"
HIGH = "json_extract(v.raw_json, '$.salary.to')"
CURRENCY = "json_extract(v.raw_json, '$.salary.currency')"
PUBLISHED = "julianday(json_extract(v.raw_json, '$.published_at'))"


@dataclass(frozen=True)
class VacancyView:
    query: str = ''
    city: str = ''
    status: str = 'active'
    policy: str = ''
    salary_min: int = 0
    salary_mode: str = 'any'
    days: int = 0
    fit_min: int = 0
    coverage_min: int = 0
    favorite: bool = False
    sort: str = 'recommended'
    page: int = 1
    page_size: int = 30

    @classmethod
    def parse(cls, data: Mapping[str, Any]) -> 'VacancyView':
        values: dict[str, Any] = {}
        for key, maximum in {'salary_min':100000000, 'days':3650, 'fit_min':100,
                             'coverage_min':100, 'page':100000, 'page_size':100}.items():
            raw = data.get(key, getattr(cls(), key))
            try:
                number = int(raw)
            except (ValueError, TypeError):
                raise ValueError(f'Некорректный фильтр: {key}') from None
            if not (1 if key in {'page', 'page_size'} else 0) <= number <= maximum:
                raise ValueError(f'Фильтр вне диапазона: {key}')
            values[key] = number
        for key, allowed in {
            'status':{'active','all','rejected','sent','ready','problems','review'},
            'policy':{'','ALLOW','REVIEW','BLOCK'},
            'salary_mode':{'any','published','net','gross','missing'},
            'sort':{'recommended','fit','newest','salary'},
        }.items():
            value = str(data.get(key, getattr(cls(), key)))
            if value not in allowed:
                raise ValueError(f'Неизвестный фильтр: {key}')
            values[key] = value
        values['query'] = str(data.get('query', '')).strip()[:200]
        values['city'] = str(data.get('city', '')).strip()[:200]
        values['favorite'] = str(data.get('favorite', '')).lower() in {'1','true'}
        return cls(**values)

    def sql(self) -> tuple[str, list[Any], str]:
        clauses, args = [], []
        states = {
            'active': "v.rejected_at IS NULL AND v.status NOT IN ('sent','verify_on_hh')",
            'rejected': 'v.rejected_at IS NOT NULL',
            'sent': "v.status='sent'",
            'ready': "v.status='ready_for_final_click' AND v.rejected_at IS NULL",
            'problems': "v.status IN ('send_blocked','send_failed','verify_on_hh')",
            'review': "v.rejected_at IS NULL AND v.status IN ('review','vacancy_approved')",
        }
        if self.status in states:
            clauses.append(states[self.status])
        if self.query:
            clauses.append("instr(hh_casefold(v.name || ' ' || v.employer), ?) > 0")
            args.append(self.query.casefold())
        if self.city:
            clauses.append('hh_city_priority(v.area)=0' if self.city == '@spb' else 'v.area=?')
            if self.city != '@spb': args.append(self.city)
        if self.policy:
            clauses.append('v.policy_decision=?'); args.append(self.policy)
        if self.favorite:
            clauses.append('v.favorite=1')
        known_salary = f'({LOW} IS NOT NULL OR {HIGH} IS NOT NULL)'
        if self.salary_mode == 'missing': clauses.append('NOT ' + known_salary)
        elif self.salary_mode != 'any':
            clauses.append(known_salary)
            if self.salary_mode in {'net','gross'}:
                clauses.append("json_extract(v.raw_json,'$.salary.gross')=?")
                args.append(1 if self.salary_mode == 'gross' else 0)
        if self.salary_min:
            # Compare a range's upper bound (or its open-ended lower bound).
            # No assumed exchange rate or tax conversion.
            clauses.extend([f"{CURRENCY} IN ('RUR','RUB')", f'coalesce({HIGH},{LOW}) >= ?'])
            args.append(self.salary_min)
        if self.days:
            clauses.append(f"{PUBLISHED} >= julianday('now') - ? AND {PUBLISHED} <= julianday('now') + 1")
            args.append(self.days)
        for key in ('fit', 'coverage'):
            minimum = getattr(self, key + '_min')
            if minimum:
                clauses.append(f"v.score_source IN ('ai','rules') AND v.{key} >= ?")
                args.append(minimum)
        orders = {
            'recommended': VACANCY_ORDER,
            'fit': "CASE WHEN v.score_source IN ('ai','rules') THEN v.fit ELSE -1 END DESC, v.coverage DESC,v.id DESC",
            'newest': f'{PUBLISHED} DESC,v.id DESC',
            'salary': f"CASE WHEN {CURRENCY} IN ('RUR','RUB') THEN coalesce({LOW},{HIGH}) END DESC,v.id DESC",
        }
        return ' AND '.join(clauses) or '1=1', args, orders[self.sort]


def plain_description(value: str) -> str:
    from html.parser import HTMLParser
    class Text(HTMLParser):
        def __init__(self):
            super().__init__(); self.parts = []; self.suppressed = 0
        def handle_starttag(self, tag, attrs):
            if tag in {'script','style'}: self.suppressed += 1
            if not self.suppressed and tag in {'p','li','br','h2','h3','div'}: self.parts.append('\n')
        def handle_endtag(self, tag):
            if tag in {'script','style'} and self.suppressed: self.suppressed -= 1
        def handle_data(self, data):
            if not self.suppressed: self.parts.append(data)
    parser = Text(); parser.feed(value)
    return '\n'.join(line.strip() for line in ''.join(parser.parts).splitlines() if line.strip())[:30000]
