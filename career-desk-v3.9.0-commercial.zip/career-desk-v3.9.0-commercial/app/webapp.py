from __future__ import annotations

import asyncio
import copy
import logging
import secrets
import threading
import time
from contextlib import asynccontextmanager, suppress
from datetime import datetime
from typing import Any
from fastapi import Request

from .browser_submitter import BrowserSubmitter
from .browser_access import PROFILE_ACCESS
from .db import Database, StateError, manual_override_active
from .diagnostics import build_diagnostics_zip, combined_log_text, health_report
from .drafts import DraftRunner
from .letters import LetterPolicyError, profile_letter, validate_cover_letter
from .scout import VacancyScout
from .settings import SettingsError, load_settings, save_settings, sanitized_settings
from .policy import evaluate_vacancy
from .submission import SubmissionController
from .ui import render_html
from .batch import BatchController
from . import licensing
from .resume_routes import register_resume_routes


LOGGER = logging.getLogger(__name__)
OVERRIDE_ACKNOWLEDGEMENT = "Я проверил вакансию и хочу рассмотреть её вручную"


class ScoutRunner:
    def __init__(self, db: Database, settings: dict[str, Any]):
        self.db = db
        self.settings = settings
        self._lock = threading.Lock()
        self.running = False
        self.last_result: dict[str, Any] | None = None
        self.last_error: str | None = None
        self.phase = "idle"
        self.progress: dict[str, Any] = {}
        self.stop_event = threading.Event()

    def start(self) -> bool:
        licensing.require_license()
        with self._lock:
            if self.running:
                return False
            if PROFILE_ACCESS.status()["busy"]:
                return False
            self.running = True
            self.stop_event.clear()
            self.phase, self.progress = "searching", {}
        threading.Thread(target=self._run, name="vacancy-scout", daemon=True).start()
        return True

    def _run(self) -> None:
        try:
            def progress(phase: str, data: dict[str, Any]) -> None:
                self.phase, self.progress = phase, data
            self.last_result = VacancyScout(self.db, copy.deepcopy(self.settings), on_progress=progress, stop_event=self.stop_event).run_once().to_dict()
            # A vacancy hh.ru served in a shape the parser could not read is a
            # skipped item, not a failed search. On 05.09 one such vacancy out
            # of 80 painted the whole cycle red while 72 saved normally, and
            # the banner showed the raw English parser message. Only a cycle
            # that saved nothing, or that stopped early, is an actual error.
            result = self.last_result
            failed_outright = result.get("stopped") or not result.get("saved")
            self.last_error = (result.get("error") or None) if failed_outright else None
            if result.get("error") and not failed_outright:
                LOGGER.info("Scout cycle finished with %s unreadable vacancy(ies): %s",
                            result.get("errors"), result.get("error"))
        except Exception as exc:
            LOGGER.exception("Scout cycle crashed")
            self.last_error = f"{type(exc).__name__}: {exc}"
        finally:
            with self._lock:
                self.running = False
                self.phase = "idle"

    def stop(self) -> None:
        self.stop_event.set()


async def scheduler_loop(runner: ScoutRunner, settings: dict[str, Any]) -> None:
    last_date = ""
    while True:
        try:
            now = datetime.now()
            target = str(settings["search"].get("schedule_local", "08:30"))
            date_key = now.strftime("%Y-%m-%d")
            if now.strftime("%H:%M") == target and last_date != date_key:
                if runner.start():
                    last_date = date_key
        except Exception:
            LOGGER.exception("Scheduler check failed")
        await asyncio.sleep(30)


def create_app(settings: dict[str, Any] | None = None, db: Database | None = None) -> Any:
    try:
        from fastapi import Body, FastAPI, Header, HTTPException
        from fastapi.responses import HTMLResponse, PlainTextResponse, Response
    except ImportError as exc:
        raise RuntimeError("FastAPI is not installed") from exc

    settings = settings or load_settings()
    db = db or Database()
    db.cancel_stale_work()
    db.revoke_placeholder_approvals()
    csrf_token = secrets.token_urlsafe(32)
    scout_runner = ScoutRunner(db, settings)
    draft_runner = DraftRunner(db, settings)
    controller = SubmissionController(db, settings)
    submitter = BrowserSubmitter(db, settings, controller)
    controller.worker = submitter
    batch = BatchController(db, settings, controller)

    health_cache: dict[str, Any] = {}
    health_lock = threading.Lock()
    settings_lock = threading.RLock()

    def dashboard_health() -> dict[str, Any]:
        # Draft progress polls must not launch Chromium probes every three seconds.
        with health_lock:
            if time.monotonic() >= health_cache.get("expires", 0):
                health_cache["report"] = health_report(settings, db, live_search=False)
                health_cache["expires"] = time.monotonic() + 60
            return health_cache["report"]

    @asynccontextmanager
    async def lifespan(_app: Any):
        scheduler_task = asyncio.create_task(scheduler_loop(scout_runner, settings))
        try:
            draft_runner.start()
            yield
        finally:
            batch.stop()
            resume_workspace.stop()
            draft_runner.stop()
            scout_runner.stop()
            controller.vault.revoke_all()
            scheduler_task.cancel()
            with suppress(asyncio.CancelledError):
                await scheduler_task

    app = FastAPI(title="Career Desk", version="3.9.0", docs_url=None, redoc_url=None, lifespan=lifespan)

    def require_csrf(value: str | None) -> None:
        if not value or not secrets.compare_digest(value, csrf_token):
            raise HTTPException(status_code=403, detail="stale or invalid dashboard session; reload the page")

    def as_http_error(exc: Exception) -> HTTPException:
        return HTTPException(status_code=409 if isinstance(exc, StateError) else 400, detail=str(exc))

    def resume_settings_changed():
        with health_lock:
            health_cache.clear()
        draft_runner.wake()

    resume_workspace = register_resume_routes(app, settings, db, require_csrf, settings_lock, resume_settings_changed)

    @app.middleware('http')
    async def commercial_gate(request, call_next):
        from fastapi.responses import JSONResponse
        if request.method == 'POST' and request.url.path not in {'/api/license/activate','/api/settings','/api/resume/upload','/api/resume/clear','/api/batch/stop'}:
            try: licensing.require_license()
            except licensing.LicenseError as exc:return JSONResponse({'detail':str(exc)},status_code=402)
        response = await call_next(request)
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.post('/api/license/activate')
    def activate_license(payload: dict = Body(...), x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try: return licensing.activate(payload.get('token',''))
        except licensing.LicenseError as exc: raise HTTPException(400,str(exc)) from exc

    @app.post('/api/batch/preview')
    def batch_preview(payload: dict = Body(...), x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try: return {'items':batch.preview(payload.get('items'))}
        except StateError as exc: raise as_http_error(exc) from exc

    @app.post('/api/batch/send')
    def batch_send(payload: dict = Body(...), x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try: return batch.start(payload.get('items'),payload.get('workers',2))
        except StateError as exc: raise as_http_error(exc) from exc

    @app.post('/api/batch/stop')
    def batch_stop(x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf);batch.stop()
        return {'stopping':True}

    @app.get("/", response_class=HTMLResponse)
    def index():
        return HTMLResponse(
            render_html(csrf_token),
            headers={
                "Cache-Control": "no-store",
                "X-Frame-Options": "DENY",
                "X-Content-Type-Options": "nosniff",
                "Content-Security-Policy": "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'",
            },
        )

    @app.get("/api/state")
    def state(request: Request) -> dict[str, Any]:
        from .vacancy_view import VacancyView
        try:
            view = VacancyView.parse(request.query_params)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        metadata = db.view_metadata(view)
        if view.page > metadata['pages']:
            from dataclasses import replace
            view = replace(view, page=metadata['pages'])
            metadata['page'] = view.page
        vacancies = db.list_vacancies(view=view)
        for item in vacancies:
            item["letter_error"] = ""
            if item.get("letter_text"):
                try:
                    validate_cover_letter(item["letter_text"], settings)
                except LetterPolicyError as exc:
                    item["letter_error"] = str(exc)
        return {
            "settings": settings,
            "vacancies": vacancies,
            "view": metadata,
            "health": dashboard_health(),
            "scout": {"running": scout_runner.running, "phase": scout_runner.phase, "progress": scout_runner.progress, "stopping": scout_runner.running and scout_runner.stop_event.is_set(), "last_result": scout_runner.last_result, "last_error": scout_runner.last_error},
            "browser": PROFILE_ACCESS.status(),
            "drafts": draft_runner.status(),
            "resume_workspace": resume_workspace.status(),
            "batch": batch.status(),
            "license": licensing.status(),
        }

    @app.post("/api/search")
    def search(x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        if not scout_runner.start():
            raise HTTPException(status_code=409, detail="Поиск уже выполняется или браузер занят другим действием. Статус показан на странице.")
        return {"accepted": True, "message": "Поиск запущен. Scout не имеет доступа к отправке откликов."}

    @app.post("/api/search/stop")
    def stop_search(x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        scout_runner.stop()
        return {"accepted": True, "message": "Поиск остановится после текущего запроса. Уже прочитанные вакансии сохранятся."}

    @app.post("/api/settings")
    def update_settings(payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            with settings_lock:
                validated = save_settings(payload)
                settings.update(validated)
        except SettingsError as exc:
            raise as_http_error(exc) from exc
        with health_lock:
            health_cache.clear()
        if not settings["ai"]["enabled"]:
            db.pause_draft_work(automatic_only=False)
        elif not settings["ai"]["auto_draft_letters"]:
            db.pause_draft_work(automatic_only=True)
        draft_runner.wake()
        db.audit("settings_saved", details={"schema_version": 3, "manual_only": True})
        return {"saved": True, "settings": settings}

    @app.post("/api/vacancies/{vacancy_id}/annotate")
    def annotate(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)):
        require_csrf(x_hh_csrf)
        try:
            db.annotate_vacancy(vacancy_id, favorite=payload.get('favorite'), note=payload.get('note'))
            return {'accepted': True}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/approve")
    def approve_vacancy(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            expected_hash = str(payload.get("content_hash") or "")
            if not expected_hash:
                raise StateError("Обновите карточку перед одобрением вакансии.")
            db.approve_vacancy(vacancy_id, expected_content_hash=expected_hash)
            return {"approved": True}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/letter")
    def save_letter(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            text = validate_cover_letter(str(payload.get("text") or ""), settings)
            digest = db.save_letter(vacancy_id, text)
            return {"saved": True, "sha256": digest}
        except (StateError, LetterPolicyError) as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/reject")
    def reject_vacancy(vacancy_id: str, x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            db.reject_vacancy(vacancy_id)
            return {"rejected": True}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/restore")
    def restore_vacancy(vacancy_id: str, x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            db.restore_vacancy(vacancy_id)
            draft_runner.wake()
            return {"restored": True}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/override-block")
    def override_block(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            if str(payload.get("acknowledgement") or "") != OVERRIDE_ACKNOWLEDGEMENT:
                raise StateError("Подтвердите ручную проверку вакансии в отдельном окне.")
            expected_hash = str(payload.get("content_hash") or "")
            if not expected_hash:
                raise StateError("Обновите карточку перед созданием исключения.")
            db.override_blocked_vacancy(vacancy_id, expected_hash)
            draft_runner.wake()
            return {"overridden": True, "message": "Создано ручное исключение только для этой версии вакансии. Теперь проверьте вакансию и письмо."}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/restart-approval")
    def restart_approval(vacancy_id: str, x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            db.restart_approval(vacancy_id)
            draft_runner.wake()
            return {"restarted": True, "message": "Согласование начато заново. Одобрите вакансию, затем точный текст письма."}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/generate-letter")
    def generate_letter(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            config = copy.deepcopy(settings)
            snapshot = db.get_submission_snapshot(vacancy_id)
            expected_content = str(payload.get('content_hash') or '')
            expected_letter = payload.get('letter_sha256') or None
            if not expected_content:
                raise StateError('Обновите карточку перед генерацией.')
            policy = evaluate_vacancy(snapshot['raw'], config)
            if (policy.decision == 'BLOCK' or policy.profession_decision != 'ALLOW') and not manual_override_active(snapshot):
                raise StateError('Текущие правила не разрешают письмо для этой вакансии.')
            resume_id = str(config['submit'].get('resume_id') or '')
            text = profile_letter(snapshot['raw'], config)
            if config != settings:
                raise StateError('Настройки изменились. Повторите генерацию.')
            digest = db.save_profile_draft(vacancy_id, text, expected_content_hash=expected_content, expected_letter_hash=expected_letter, resume_id=resume_id)
            return {'ready': True, 'sha256': digest, 'text': text, 'source': 'profile', 'message': 'Письмо создано из сохранённого профиля. Проверьте его и одобрите точный текст.'}
        except (StateError, LetterPolicyError) as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/generate-ai-letter", status_code=202)
    def generate_ai_letter(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            if not settings["ai"]["enabled"]:
                raise StateError("ИИ отключён. Доступна генерация из профиля.")
            content_hash = str(payload.get('content_hash') or '')
            if not content_hash:
                raise StateError('Обновите карточку перед генерацией.')
            queued = db.queue_letter_draft(vacancy_id, expected_content_hash=content_hash, expected_letter_hash=payload.get('letter_sha256') or None)
            draft_runner.wake()
            return {"queued": queued, "message": "Переработка через ИИ поставлена в начало очереди. Для немедленного результата доступна генерация из профиля."}
        except StateError as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/approve-letter")
    def approve_letter(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        try:
            expected_hash = str(payload.get("sha256") or "")
            if not expected_hash:
                raise StateError("Сохраните и проверьте письмо перед одобрением.")
            validate_cover_letter(str(db.get_submission_snapshot(vacancy_id).get("letter_text") or ""), settings)
            digest = db.approve_letter(vacancy_id, expected_hash=expected_hash)
            return {"approved": True, "sha256": digest}
        except (StateError, LetterPolicyError) as exc:
            raise as_http_error(exc) from exc

    @app.post("/api/vacancies/{vacancy_id}/send")
    def send(vacancy_id: str, payload: dict[str, Any] = Body(...), x_hh_csrf: str | None = Header(default=None)) -> dict[str, Any]:
        require_csrf(x_hh_csrf)
        browser = PROFILE_ACCESS.status()
        if browser["busy"]:
            raise HTTPException(status_code=409, detail="Браузер занят: " + browser["activity"] + ". Кнопка станет доступна после его освобождения.")
        try:
            letter_digest = str(payload.get("letter_sha256") or "")
            content_digest = str(payload.get("content_hash") or "")
            if not letter_digest or not content_digest:
                raise StateError("Обновите карточку и подтвердите отправку ещё раз.")
            validate_cover_letter(str(db.get_submission_snapshot(vacancy_id).get("letter_text") or ""), settings)
            attempt_id = controller.final_click(vacancy_id, expected_letter_hash=letter_digest, expected_content_hash=content_digest)
            return {"queued": True, "attempt_id": attempt_id}
        except (StateError, LetterPolicyError) as exc:
            raise as_http_error(exc) from exc

    @app.get("/api/vacancies/{vacancy_id}/submission")
    def submission_status(vacancy_id: str) -> dict[str, Any]:
        return db.submission_status(vacancy_id) or {"state": "none"}

    @app.get("/api/health")
    def health(live: bool = False) -> dict[str, Any]:
        return health_report(settings, db, live_search=live)

    @app.get("/api/export/log")
    def export_log():
        payload = combined_log_text(db).encode("utf-8")
        return Response(payload, media_type="text/plain; charset=utf-8", headers={"Content-Disposition": "attachment; filename=hh-ai-recruiter-log.txt"})

    @app.get("/api/export/diagnostics")
    def export_diagnostics():
        payload = build_diagnostics_zip(settings, db, live_search=True)
        return Response(payload, media_type="application/zip", headers={"Content-Disposition": "attachment; filename=hh-ai-recruiter-diagnostics.zip"})

    return app
