import unittest
from app.settings import DEFAULT_SETTINGS,_validate
from app.edition import EDITION,PUBLIC_KEY
from tools.build_release import verify_manifest
class CommercialTests(unittest.TestCase):
 def test_clean_defaults(self):
  self.assertEqual(EDITION,'commercial');self.assertEqual(len(PUBLIC_KEY),64)
  for k in ('full_name','headline','profile'):self.assertEqual(DEFAULT_SETTINGS['candidate'][k],'')
  self.assertEqual(DEFAULT_SETTINGS['candidate']['achievements'],[])
  self.assertEqual(DEFAULT_SETTINGS['policy']['stop_companies'],[])
  self.assertEqual(DEFAULT_SETTINGS['submit']['resume_id'],'')
  _validate(DEFAULT_SETTINGS)
 def test_manifest(self):verify_manifest()
