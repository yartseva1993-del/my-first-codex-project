from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
RELEASE_NAME = "career-desk-v3.9.0-commercial.zip"
MANIFEST = ROOT / "BUILD_MANIFEST.sha256"
EXCLUDED_DIRS = {".git", ".venv", "__pycache__", ".pytest_cache", ".mypy_cache"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".zip", ".sqlite3", ".db", ".log"}
FORBIDDEN_NAMES = {".env", "storage_state.json", "agent_settings.json", "resume-workspace.json"}


def included_files(include_manifest: bool = False) -> list[Path]:
    output: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if path.name in FORBIDDEN_NAMES:
            raise RuntimeError(f"forbidden runtime artifact in source tree: {relative}")
        if relative == Path("BUILD_MANIFEST.sha256") and not include_manifest:
            continue
        output.append(path)
    return sorted(output, key=lambda item: item.relative_to(ROOT).as_posix())


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def write_manifest() -> None:
    lines = [f"{digest(path)}  {path.relative_to(ROOT).as_posix()}" for path in included_files(False)]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def verify_manifest(root: Path = ROOT) -> None:
    manifest = root / "BUILD_MANIFEST.sha256"
    if not manifest.exists():
        raise RuntimeError("BUILD_MANIFEST.sha256 is missing")
    expected: dict[str, str] = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        checksum, relative = line.split("  ", 1)
        expected[relative] = checksum
    actual_files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_DIRS for part in relative.parts) or path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if relative == Path("BUILD_MANIFEST.sha256"):
            continue
        actual_files.append(relative.as_posix())
    if set(expected) != set(actual_files):
        missing = sorted(set(expected) - set(actual_files))
        extra = sorted(set(actual_files) - set(expected))
        raise RuntimeError(f"manifest file set mismatch; missing={missing}; extra={extra}")
    for relative, checksum in expected.items():
        if digest(root / relative) != checksum:
            raise RuntimeError(f"manifest checksum mismatch: {relative}")


def build(output: Path) -> Path:
    write_manifest()
    verify_manifest(ROOT)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    top = RELEASE_NAME.removesuffix(".zip")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in included_files(True):
            archive.write(path, f"{top}/{path.relative_to(ROOT).as_posix()}")
    sha_path = output.with_suffix(output.suffix + ".sha256")
    sha_path.write_text(f"{digest(output)}  {output.name}\n", encoding="ascii", newline="\n")
    return output


def verify_zip(path: Path, run_tests: bool) -> None:
    with tempfile.TemporaryDirectory(prefix="hh-v3-release-check-") as tmp:
        target = Path(tmp)
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                destination = (target / info.filename).resolve()
                if target.resolve() not in destination.parents and destination != target.resolve():
                    raise RuntimeError("unsafe ZIP path")
            archive.extractall(target)
        roots = [item for item in target.iterdir() if item.is_dir()]
        if len(roots) != 1:
            raise RuntimeError("release ZIP must contain exactly one top-level directory")
        extracted = roots[0]
        if extracted.name != RELEASE_NAME.removesuffix('.zip'):
            raise RuntimeError('release root/version mismatch')
        for required in ('requirements.txt','SETUP_WINDOWS.cmd','app/__main__.py','CHANGELOG.md'):
            if not (extracted / required).is_file(): raise RuntimeError('incomplete release: ' + required)
        verify_manifest(extracted)
        if run_tests:
            subprocess.run([sys.executable, "-m", "compileall", "-q", "app", "tests"], cwd=extracted, check=True)
            subprocess.run([sys.executable, "-m", "unittest", "discover", "-v"], cwd=extracted, check=True)
            node = os.environ.get("HH_RELEASE_NODE") or shutil.which("node")
            if node:
                subprocess.run([node, "--check", "app/dashboard.js"], cwd=extracted, check=True)
                if (extracted / "tests/test_dashboard.js").exists():
                    subprocess.run([node, "--test", "tests/test_dashboard.js"], cwd=extracted, check=True)
            else:
                print("JavaScript checks skipped: install Node.js for developer release verification.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT.parent / RELEASE_NAME)
    parser.add_argument("--verify-only", type=Path)
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    if args.verify_only:
        verify_zip(args.verify_only.resolve(), not args.skip_tests)
        print(f"VERIFIED {args.verify_only.resolve()}")
        return 0
    output = build(args.output.resolve())
    verify_zip(output, not args.skip_tests)
    print(f"BUILT {output}")
    print(f"SHA256 {digest(output)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
